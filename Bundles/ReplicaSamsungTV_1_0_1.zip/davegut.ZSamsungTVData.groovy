metadata {
	definition (name: "Z Samsung TV Data",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
	preferences {
	}
}

/*	DEVELOPMENT DATA
capabilities: [
	["id":"switch","version":1,"status":"live","name":"Switch","ephemeral":false,"attributes":["switch":["schema":["type":"object","properties":["value":["title":"SwitchState","type":"string","enum":["on","off"]]],"additionalProperties":false,"required":["value"]],"enumCommands":[["command":"on","value":"on"],["command":"off","value":"off"]]]],"commands":["off":["name":"off","arguments":[]],"on":["name":"on","arguments":[]]]]
	["id":"audioVolume","version":1,"status":"live","name":"Audio Volume","ephemeral":false,"attributes":["volume":["schema":["title":"IntegerPercent","type":"object","properties":["value":["type":"integer","minimum":0,"maximum":100],"unit":["type":"string","enum":["%"],"default":"%"]],"additionalProperties":false,"required":["value"]],"setter":"setVolume","enumCommands":[]]],"commands":["volumeDown":["name":"volumeDown","arguments":[]],"volumeUp":["name":"volumeUp","arguments":[]],"setVolume":["name":"setVolume","arguments":[["name":"volume","optional":false,"schema":["type":"integer","minimum":0,"maximum":100]]]]]]
	["id":"refresh","version":1,"status":"live","name":"Refresh","ephemeral":false,"attributes":[],"commands":["refresh":["name":"refresh","arguments":[]]]]
	["id":"samsungvd.mediaInputSource","version":1,"status":"proposed","name":"Media Input Source","ephemeral":false,"attributes":["supportedInputSourcesMap":["schema":["type":"object","properties":["value":["type":"array","items":["type":"object","properties":["id":["type":"string"],"name":["type":"string"]]],"required":[]]],"additionalProperties":false,"required":[]],"enumCommands":[]],"inputSource":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]]],"commands":["setInputSource":["name":"setInputSource","arguments":[["name":"id","optional":false,"schema":["type":"string"]]]]]]
	["id":"samsungvd.ambient","version":1,"status":"proposed","name":"Ambient","ephemeral":false,"attributes":[],"commands":["setAmbientOn":["name":"setAmbientOn","arguments":[]]]]
	["id":"samsungvd.remoteControl","version":1,"status":"proposed","name":"Remote Control","ephemeral":false,"attributes":[],"commands":["send":["name":"send","arguments":[["name":"keyValue","optional":false,"schema":["type":"string","enum":["UP","DOWN","LEFT","RIGHT","OK","BACK","MENU","HOME"]]],["name":"keyState","optional":true,"schema":["type":"string","enum":["PRESSED","RELEASED","PRESS_AND_RELEASED"]]]]]]]
	["id":"custom.tvsearch","version":1,"status":"proposed","name":"tvSearch","ephemeral":false,"attributes":[],"commands":["search":["name":"search","arguments":[["name":"query","optional":false,"schema":["type":"string"]],["name":"url","optional":false,"schema":["type":"string"]]]]]]

	[
		"id":"custom.launchapp","version":1,"status":"proposed","name":"launchApp","ephemeral":false,"attributes":[],
		"commands":["launchApp":["name":"launchApp","arguments":[
			["name":"appId","optional":true,"schema":["type":"string"]],
			["name":"appName","optional":true,"schema":["type":"string"]]]]]]

	["id":"custom.soundmode","version":1,"status":"proposed","name":"SoundMode","ephemeral":false,"attributes":["supportedSoundModesMap":["schema":["type":"object","properties":["value":["required":[],"items":["type":"object","properties":["id":["type":"string"],"name":["type":"string"]]],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]],"soundMode":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":[]],"enumCommands":[]],"supportedSoundModes":["schema":["type":"object","properties":["value":["items":["type":"string"],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]]],"commands":["setSoundMode":["name":"setSoundMode","arguments":[["name":"mode","optional":false,"schema":["type":"string"]]]]]]
	["id":"custom.picturemode","version":1,"status":"proposed","name":"PictureMode","ephemeral":false,"attributes":["pictureMode":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":[]],"enumCommands":[]],"supportedPictureModes":["schema":["type":"object","properties":["value":["type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]],"supportedPictureModesMap":["schema":["type":"object","properties":["value":["required":[],"items":["type":"object","properties":["id":["type":"string"],"name":["type":"string"]]],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]]],"commands":["setPictureMode":["name":"setPictureMode","arguments":[["name":"mode","optional":false,"schema":["type":"string"]]]]]]
	["id":"mediaTrackControl","version":1,"status":"live","name":"Media Track Control","ephemeral":false,"attributes":["supportedTrackControlCommands":["schema":["type":"object","properties":["value":["items":["title":"MediaTrackCommands","enum":["previousTrack","nextTrack"],"type":"string"],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]]],"commands":["previousTrack":["name":"previousTrack","arguments":[]],"nextTrack":["name":"nextTrack","arguments":[]]]]

	[
		"id":"mediaPlayback","version":1,"status":"live","name":"Media Playback","ephemeral":false,
		"attributes":["supportedPlaybackCommands":["schema":["type":"object","properties":["value":["items":["title":"MediaPlaybackCommands","enum":["pause","play","stop","fastForward","rewind"],"type":"string"],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]],"playbackStatus":["schema":["type":"object","properties":["value":["enum":["paused","playing","stopped","fast forwarding","rewinding","buffering"],"type":"string"]],"additionalProperties":false,"required":[]],"setter":"setPlaybackStatus","enumCommands":[["command":"play","value":"playing"],["command":"pause","value":"paused"],["command":"stop","value":"stopped"],["command":"fastForward","value":"fast forwarding"],["command":"rewind","value":"rewinding"]]]],
		"commands":[
			"play":["name":"play","arguments":[]],
			"stop":["name":"stop","arguments":[]],
			"rewind":["name":"rewind","arguments":[]],
			"fastForward":["name":"fastForward","arguments":[]],
			"setPlaybackStatus":["name":"setPlaybackStatus","arguments":[["name":"status","optional":false,"schema":["enum":["paused","playing","stopped","fast forwarding","rewinding"],"type":"string"]]]],"pause":["name":"pause","arguments":[]]]]

	["id":"mediaInputSource","version":1,"status":"live","name":"Media Input Source","ephemeral":false,"attributes":["supportedInputSources":["schema":["type":"object","properties":["value":["items":["title":"MediaSource","enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],"type":"string"],"type":"array"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]],"inputSource":["schema":["type":"object","properties":["value":["title":"MediaSource","enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],"type":"string"]],"additionalProperties":false,"required":["value"]],"setter":"setInputSource","enumCommands":[]]],"commands":["setInputSource":["name":"setInputSource","arguments":[["name":"mode","optional":false,"schema":["title":"MediaSource","enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],"type":"string"]]]]]]

	[
		"id":"samsungvd.remoteControl","version":1,"status":"proposed","name":"Remote Control","ephemeral":false,"attributes":[],
		"commands":["send":["name":"send","arguments":[
			["name":"keyValue","optional":false,"schema":[
				"type":"string",
				"enum":["UP","DOWN","LEFT","RIGHT","OK","BACK","MENU","HOME"]]],
			["name":"keyState","optional":true,
			 "schema":["type":"string","enum":["PRESSED","RELEASED","PRESS_AND_RELEASED"]]]]]]]

	[
		"id":"tvChannel","version":1,"status":"proposed","name":"Tv Channel","ephemeral":false,
		"attributes":["tvChannel":["schema":["type":"object","properties":["value":["title":"String","type":"string","maxLength":255]],"additionalProperties":false,"required":[]],"setter":"setTvChannel","enumCommands":[]],"tvChannelName":["schema":["type":"object","properties":["value":["title":"String","type":"string","maxLength":255]],"additionalProperties":false,"required":[]],"setter":"setTvChannelName","enumCommands":[]]],
		"commands":[
			"channelDown":["name":"channelDown","arguments":[]],
			"setTvChannel":["name":"setTvChannel","arguments":[["name":"tvChannel","optional":false,"schema":["title":"String","type":"string","maxLength":255]]]],
			"channelUp":["name":"channelUp","arguments":[]],"setTvChannelName":["name":"setTvChannelName","arguments":[["name":"tvChannelName","optional":true,"schema":["title":"String","type":"string","maxLength":255]]]]]]

	["id":"audioMute","version":1,"status":"live","name":"Audio Mute","ephemeral":false,"attributes":["mute":["schema":["type":"object","properties":["value":["title":"MuteState","type":"string","enum":["muted","unmuted"]]],"additionalProperties":false,"required":["value"]],"setter":"setMute","enumCommands":[["command":"mute","value":"muted"],["command":"unmute","value":"unmuted"]]]],"commands":["setMute":["name":"setMute","arguments":[["name":"state","optional":false,"schema":["title":"MuteState","type":"string","enum":["muted","unmuted"]]]]],"mute":["name":"mute","arguments":[]],"unmute":["name":"unmute","arguments":[]]]]
	]
deviceDescription: [
	deviceId:7e19491f-48f0-5e57-a973-8d63d28bd311,name:DenTV, label:DenTV, manufacturerName:Samsung Electronics,presentationId:VD-STV_2018_K, deviceManufacturerCode:Samsung Electronics, 
	locationId:3194e04d-4739-44dc-b21b-fa4094c7945c, ownerId:8e3c430a-9e98-4730-96e4-eb63f59720da,roomId:9ed45669-5439-4619-af16-19befaaa8049, deviceTypeName:Samsung OCF TV, 
	components:[
		[
			id:main, label:main, 
			capabilities:[
				[id:ocf, version:1], //	NOT IMPLEMENTED
				[id:switch, version:1],
				[id:audioVolume, version:1],
				[id:audioMute, version:1],
				[id:tvChannel, version:1],
				[id:mediaInputSource, version:1],
				[id:mediaPlayback, version:1],
				[id:mediaTrackControl, version:1], //	NOT IMPLEMENTED
				[id:custom.error, version:1], //	NOT IMPLEMENTED
				[id:custom.picturemode, version:1],
				[id:custom.soundmode, version:1],
				[id:custom.launchapp, version:1], //	USE LAN COMMAND INSTEAD
				[id:custom.tvsearch, version:1], //	NOT IMPLEMENTED
				[id:samsungvd.remoteControl, version:1], //	NOT IMPLEMENTED (This is a send websocket cmd
				[id:samsungvd.ambient, version:1], //	Uses Websocket Cmd
				[id:samsungvd.mediaInputSource, version:1], //	NOT IMPLEMENTED (use mediaInputSource
				[id:refresh, version:1],
				[id:execute, version:1], //	NOT IMPLEMENTED
				[id:samsungvd.firmwareVersion, version:1], //	NOT IMPLEMENTED
				[id:samsungvd.supportsPowerOnByOcf, version:1], //	NOT IMPLEMENTED
				[id:sec.diagnosticsInformation, version:1]], //	NOT IMPLEMENTED
			categories:[[name:Television, categoryType:manufacturer]]]], //	NOT IMPLEMENTED
	createTime:2022-08-30T14:25:17.547Z, 
	profile:[id:ba802429-d8cb-328d-b607-2d01d4c30fd7], 
	ocf:[
		ocfDeviceType:oic.d.tv, name:DenTV, specVersion:core.1.1.0, 
		verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, manufacturerName:Samsung Electronics, 
		modelNumber:UN55TU8000FXZA, platformVersion:5.5, platformOS:Tizen, hwVersion:, 
		firmwareVersion:T-NKLAKUC-2303.1, vendorId:VD-STV_2018_K, 
		vendorResourceClientServerVersion:2.4.24, locale:en_US, 
		lastSignupTime:2022-08-30T14:25:13.309285Z], 
	type:OCF, restrictionTier:0, allowed:null]

Map getReplicaCommands() [
	Map replicaCommands = [ 
		setSwitchValue:[[name:"switch*",type:"string"]], //
		setVolumeValue:[[name:"volume*", type: "integer"]],//
		setMuteValue:[[name:"mute", type: "string"]],//
		setTransportStatusValue:[[name:"playbackStatus*", type: "string"]],//
		setTvChannelValue:[[name:"tvChannel*", type: "string"]],
		setTvChannelNameValue:[[name:"tvChannelNAme*", type: "string"]],
		setSupportedInputSources:[[name:"supportedInputSources*", type: "object"]],//
		setInputSourceValue:[[name:"inputSource*", type: "string"]],//
		setSupportedSoundModesValue:[[name:"supportedSoundModes*", type: "object"]],//
		setSoundModeValue:[[name:"soundMode*", type: "string"]],//
		setSupportedPictureModeValue:[[name:"supportedPictureModes*", type: "object"]],//
		setPictureModeValue:[[name:"pictureMode*", type: "string"]],//
		setHealthStatusValue:[[name:"healthStatus*",type:"ENUM"]]]
	return replicaCommands
]
Map getReplicaTriggers() [
	def replicaTriggers = [
		refresh:[],//
		off:[],//
		on:[],//
//		volumeUp:[],	//ws
//		volumeDown:[], //ws
		setVolume: [[name:"volume*", type: "integer"]],//
//		mute:[],	//ws
//		unmute:[],	//ws
//		play:[],	//ws
//		pause:[],	//ws
//		stop:[],	//ws
		rewind:[],//
		fastForward:[],//
//		channelUp:[],//	ws
//		channelDown:[],//ws
		setTvChannel: [[name:"volume*", type: "integer"]],
		setInputSource: [[name:"tvChannel*", type: "string"]],//
		setSoundMode: [[name:"mode", type:"string"]],
		setPictureMode :[[name:"mode", type:"string"]],
	]
	return replicaTriggers
]

def defData() [
	capabilities: [
		[
			"id":"refresh","version":1,"status":"live","name":"Refresh","ephemeral":false,"attributes":[],"commands":["refresh":["name":"refresh","arguments":[]]]],	//	refresh
		[
			"id":"switch","version":1,"status":"live","name":"Switch","ephemeral":false,
			"attributes":[
				"switch":[
					"schema":[
						"type":"object",
						"properties":[
							"value":["title":"SwitchState","type":"string","enum":["on","off"]]],
						"additionalProperties":false,"required":["value"]],
					"enumCommands":[["command":"on","value":"on"],["command":"off","value":"off"]]]],
			"commands":["off":["name":"off","arguments":[]],"on":["name":"on","arguments":[]]]],	//	switch
		[
			"id":"audioVolume","version":1,"status":"live","name":"Audio Volume","ephemeral":false,
			"attributes":[
				"volume":["schema":[
					"title":"IntegerPercent","type":"object",
					"properties":[
						"value":["type":"integer","minimum":0,"maximum":100],
						"unit":["type":"string","enum":["%"],"default":"%"]],
					"additionalProperties":false,"required":["value"]],"setter":"setVolume","enumCommands":[]]],
			"commands":[
				"volumeDown":["name":"volumeDown","arguments":[]],
				"volumeUp":["name":"volumeUp","arguments":[]],
				"setVolume":["name":"setVolume","arguments":[["name":"volume","optional":false,"schema":["type":"integer","minimum":0,"maximum":100]]]]]],	//	audioVolume
		[
			"id":"audioMute","version":1,"status":"live","name":"Audio Mute","ephemeral":false,
			"attributes":["mute":["schema":[
				"type":"object","properties":["value":["title":"MuteState","type":"string","enum":["muted","unmuted"]]],
				"additionalProperties":false,"required":["value"]],"setter":"setMute","enumCommands":[["command":"mute","value":"muted"],["command":"unmute","value":"unmuted"]]]],
			"commands":["setMute":["name":"setMute","arguments":[["name":"state","optional":false,"schema":["title":"MuteState","type":"string","enum":["muted","unmuted"]]]]],"mute":["name":"mute","arguments":[]],"unmute":["name":"unmute","arguments":[]]]],	//	audioMute
		[
			"id":"mediaPlayback","version":1,"status":"live","name":"Media Playback","ephemeral":false,
			"attributes":[
				"supportedPlaybackCommands":[
					"schema":[
						"type":"object",
						"properties":[
							"value":[
								"items":["title":"MediaPlaybackCommands",
										 "enum":["pause","play","stop","fastForward","rewind"],
										 "type":"string"],"type":"array"]],
						"additionalProperties":false,"required":[]],
					"enumCommands":[]],
				"playbackStatus":[
					"schema":[
						"type":"object",
						"properties":[
							"value":["enum":["paused","playing","stopped","fast forwarding","rewinding","buffering"],"type":"string"]],
						"additionalProperties":false,"required":[]],"setter":"setPlaybackStatus",
					"enumCommands":[
						["command":"play","value":"playing"],["command":"pause","value":"paused"],["command":"stop","value":"stopped"],
						["command":"fastForward","value":"fast forwarding"],["command":"rewind","value":"rewinding"]]]],
			"commands":[
				"play":["name":"play","arguments":[]],
				"stop":["name":"stop","arguments":[]],
				"rewind":["name":"rewind","arguments":[]],
				"fastForward":["name":"fastForward","arguments":[]],
				"setPlaybackStatus":["name":"setPlaybackStatus",
									 "arguments":[
										 ["name":"status","optional":false,"schema":["enum":["paused","playing","stopped","fast forwarding","rewinding"],
																					 "type":"string"]]]],"pause":["name":"pause","arguments":[]]]],	//	mediaPlayback
		[
			"id":"tvChannel","version":1,"status":"proposed","name":"Tv Channel","ephemeral":false,
			"attributes":[
				"tvChannel":[
					"schema":["type":"object","properties":["value":["title":"String","type":"string","maxLength":255]],"additionalProperties":false,"required":[]],
					"setter":"setTvChannel","enumCommands":[]],
				"tvChannelName":[
					"schema":["type":"object","properties":["value":["title":"String","type":"string","maxLength":255]],"additionalProperties":false,"required":[]],
					"setter":"setTvChannelName","enumCommands":[]]],
			"commands":[
				"channelDown":["name":"channelDown","arguments":[]],
				"setTvChannel":["name":"setTvChannel","arguments":[["name":"tvChannel","optional":false,"schema":["title":"String","type":"string","maxLength":255]]]],
				"channelUp":["name":"channelUp","arguments":[]],
				"setTvChannelName":["name":"setTvChannelName","arguments":[["name":"tvChannelName","optional":true,"schema":["title":"String","type":"string","maxLength":255]]]]]],	//	tvChannel
		[
			"id":"mediaInputSource","version":1,"status":"live","name":"Media Input Source","ephemeral":false,
			"attributes":[
				"supportedInputSources":[
					"schema":[
						"type":"object",
						"properties":[
							"value":[
								"items":["title":"MediaSource","enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],
										 "type":"string"],"type":"array"]],
						"additionalProperties":false,"required":["value"]],"enumCommands":[]],
				"inputSource":[
					"schema":[
						"type":"object",
						"properties":[
							"value":[
								"title":"MediaSource",
								"enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],
								"additionalProperties":false,
								"required":["value"]],"setter":"setInputSource","enumCommands":[]]],
					"commands":["setInputSource":[
						"name":"setInputSource",
						"arguments":[
							["name":"mode","optional":false,"schema":[
								"title":"MediaSource",
								"enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],
								"type":"string"]]]]]]]],	//	mediaInputSource
		[
			"id":"custom.soundmode","version":1,"status":"proposed","name":"SoundMode","ephemeral":false,
			"attributes":[
				"supportedSoundModesMap":[
					"schema":[
						"type":"object","properties":["value":["required":[],"items":["type":"object","properties":["id":["type":"string"],"name":["type":"string"]]],"type":"array"]],
						"additionalProperties":false,"required":[]],"enumCommands":[]],
				"soundMode":[
					"schema":[
						"type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":[]],"enumCommands":[]],
				"supportedSoundModes":[
					"schema":[
						"type":"object","properties":["value":["items":["type":"string"],"type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]]],
			"commands":["setSoundMode":["name":"setSoundMode","arguments":[["name":"mode","optional":false,"schema":["type":"string"]]]]]],	//	soundMode
		[
			"id":"custom.picturemode","version":1,"status":"proposed","name":"PictureMode","ephemeral":false,
			"attributes":[
				"pictureMode":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":[]],"enumCommands":[]],
				"supportedPictureModes":["schema":["type":"object","properties":["value":["type":"array"]],"additionalProperties":false,"required":[]],"enumCommands":[]],
				"supportedPictureModesMap":[
					"schema":["type":"object","properties":["value":["required":[],"items":["type":"object","properties":["id":["type":"string"],"name":["type":"string"]]],"type":"array"]],
							  "additionalProperties":false,"required":[]],"enumCommands":[]]],
			"commands":["setPictureMode":["name":"setPictureMode","arguments":[["name":"mode","optional":false,"schema":["type":"string"]]]]]],	//	pictureMode
	]
]
*/






/*
SET VOL 10 on MY TV
[mediaPlayback:[supportedPlaybackCommands:[value:[play, pause, stop, fastForward, rewind], timestamp:2022-08-30T14:25:17.765Z], playbackStatus:[value:null]], samsungvd.supportsPowerOnByOcf:[supportsPowerOnByOcf:[value:true, timestamp:2022-11-07T17:44:53.629Z]], mediaInputSource:[supportedInputSources:[value:[digitalTv, HDMI1, HDMI2], timestamp:2022-11-18T01:22:32.100Z], inputSource:[value:digitalTv, timestamp:2023-01-10T14:22:21.330Z]], switch:[switch:[value:on, timestamp:2023-01-10T16:05:44.461Z]], ocf:[st:[value:2022-11-18T01:20:19Z, timestamp:2022-11-18T01:22:35.541Z], mndt:[value:2020-01-01, timestamp:2022-08-30T14:25:20.452Z], mnfv:[value:T-NKLAKUC-2303.1, timestamp:2022-08-30T14:25:20.452Z], mnhw:[value:, timestamp:2022-08-30T14:25:20.452Z], di:[value:7e19491f-48f0-5e57-a973-8d63d28bd311, timestamp:2022-08-30T14:25:20.452Z], mnsl:[value:, timestamp:2022-08-30T14:25:20.452Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-08-30T14:25:20.452Z], n:[value:DenTV, timestamp:2022-08-30T14:25:20.452Z], mnmo:[value:UN55TU8000FXZA, timestamp:2022-08-30T14:25:20.452Z], vid:[value:VD-STV_2018_K, timestamp:2022-08-30T14:25:20.452Z], mnmn:[value:Samsung Electronics, timestamp:2022-08-30T14:25:20.452Z], mnml:[value:, timestamp:2022-08-30T14:25:20.452Z], mnpv:[value:5.5, timestamp:2022-08-30T14:25:20.452Z], mnos:[value:Tizen, timestamp:2022-08-30T14:25:20.452Z], pi:[value:7e19491f-48f0-5e57-a973-8d63d28bd311, timestamp:2022-08-30T14:25:20.452Z], icv:[value:core.1.1.0, timestamp:2022-08-30T14:25:20.452Z]], custom.accessibility:[:], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungvd.ambient18, samsungvd.ambientContent, sec.diagnosticsInformation], timestamp:2022-11-18T01:22:32.074Z]], samsungvd.remoteControl:[:], sec.diagnosticsInformation:[logType:[value:null], endpoint:[value:null], minVersion:[value:null], signinPermission:[value:null], setupId:[value:null], protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], custom.launchapp:[:], samsungvd.firmwareVersion:[firmwareVersion:[value:3.4.0, timestamp:2022-08-30T14:25:20.425Z]], audioVolume:[volume:[value:10, unit:%, timestamp:2023-01-10T16:21:30.237Z]], samsungvd.mediaInputSource:[supportedInputSourcesMap:[value:[[id:dtv, name:TV], [id:HDMI1, name:Fire TV], [id:HDMI2, name:Soundbar]], timestamp:2022-12-29T15:27:27.461Z], inputSource:[value:dtv, timestamp:2023-01-10T14:22:21.330Z]], custom.tvsearch:[:], samsungvd.ambient:[:], refresh:[:], custom.error:[error:[value:null]], execute:[data:[value:null]], tvChannel:[tvChannel:[value:1212, timestamp:2023-01-10T16:21:30.209Z], tvChannelName:[value:Antiques Roadshow, timestamp:2023-01-10T16:21:30.209Z]], custom.picturemode:[pictureMode:[value:Dynamic, timestamp:2023-01-01T00:41:33.330Z], supportedPictureModes:[value:[Dynamic, FILMMAKER MODE, Movie, Natural, Standard], timestamp:2023-01-08T02:28:49.943Z], supportedPictureModesMap:[value:[[id:modeDynamic, name:Dynamic], [id:modeFilmmakerMode, name:FILMMAKER MODE], [id:modeMovie, name:Movie], [id:modeNatural, name:Natural], [id:modeStandard, name:Standard]], timestamp:2023-01-10T16:21:30.266Z]], samsungvd.ambientContent:[supportedAmbientApps:[value:[], timestamp:2022-08-30T14:25:17.765Z]], custom.recording:[:], samsungvd.ambient18:[:], custom.soundmode:[supportedSoundModesMap:[value:[[id:modeExternalVoice, name:Clear Voice], [id:modeExternalCinema, name:Movie], [id:modeExternalMusic, name:Music], [id:modeExternalSmart, name:Smart], [id:modeExternalSports, name:Sports], [id:modeExternalStandard, name:Standard], [id:modeExternal3DSurround, name:Surround]], timestamp:2023-01-09T19:32:24.700Z], soundMode:[value:Smart, timestamp:2023-01-09T19:32:24.700Z], supportedSoundModes:[value:[Clear Voice, Movie, Music, Smart, Sports, Standard, Surround], timestamp:2023-01-09T19:32:24.700Z]], audioMute:[mute:[value:unmuted, timestamp:2023-01-10T03:30:54.738Z]], mediaTrackControl:[supportedTrackControlCommands:[value:null]]]






//	On to OFF, using powerState
dev:90932023-01-10 09:51:00.466warnSTPoll: off
dev:90932023-01-10 09:51:00.131warnlocalPoll standby / on
dev:90932023-01-10 09:51:00.028warnSTARTPOLLCYCLE
dev:90932023-01-10 09:50:50.307warnSTPoll: on
dev:90932023-01-10 09:50:50.063warnlocalPoll on / on
dev:90932023-01-10 09:50:50.027warnSTARTPOLLCYCLE

//	Off to On using powerState, 2 minute wait from off to on.
dev:90932023-01-10 09:53:30.439warnlocalPoll on / on
dev:90932023-01-10 09:53:30.418warnSTPoll: on
dev:90932023-01-10 09:53:30.026warnSTARTPOLLCYCLE
dev:90932023-01-10 09:53:25.298warnlocalPoll standby / off
dev:90932023-01-10 09:53:22.214warnlocalPoll NC / off
dev:90932023-01-10 09:53:20.376warnSTPoll: off
dev:90932023-01-10 09:53:20.034warnSTARTPOLLCYCLE

//	DEVICES WITHOUT powerState
//	On to OFF, No powerState
//	Note delay in local polling detecting OFF, but not SmartThings
dev:90932023-01-10 09:59:06.069warnlocalPoll NC / off
dev:90932023-01-10 09:59:01.394warnSTPoll: off
dev:90932023-01-10 09:59:01.093warnSTARTPOLLCYCLE
dev:90932023-01-10 09:59:00.749warnSTPoll: off
dev:90932023-01-10 09:59:00.038warnSTARTPOLLCYCLE
dev:90932023-01-10 09:58:56.130warnlocalPoll NC / on
dev:90932023-01-10 09:58:50.422warnSTPoll: off
dev:90932023-01-10 09:58:50.027warnSTARTPOLLCYCLE
dev:90932023-01-10 09:58:40.562warnSTPoll: off
dev:90932023-01-10 09:58:40.065warnlocalPoll on / on
dev:90932023-01-10 09:58:40.027warnSTARTPOLLCYCLE
dev:90932023-01-10 09:58:30.409warnSTPoll: off
dev:90932023-01-10 09:58:30.073warnlocalPoll on / on
dev:90932023-01-10 09:58:30.032warnSTARTPOLLCYCLE
dev:90932023-01-10 09:58:21.001warnSTPoll: on
dev:90932023-01-10 09:58:20.294warnlocalPoll on / on
dev:90932023-01-10 09:58:20.027warnSTARTPOLLCYCLE

//	Off to ON, no powerState, two minute wait.
dev:90932023-01-10 10:01:10.306warnSTPoll: on
dev:90932023-01-10 10:01:10.078warnlocalPoll on / on
dev:90932023-01-10 10:01:10.036warnSTARTPOLLCYCLE
dev:90932023-01-10 10:01:01.847infoA TEST TV-4.0-3: onPollParse: [switch: on, powerState: on]
dev:90932023-01-10 10:01:00.710warnlocalPoll NC / off
dev:90932023-01-10 10:01:00.297warnSTPoll: off
dev:90932023-01-10 10:01:00.026warnSTARTPOLLCYCLE

*/
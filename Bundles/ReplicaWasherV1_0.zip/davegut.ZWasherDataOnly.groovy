metadata {
	definition (name: "Z Washer Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}



Map description = [
	name:"[washer] Samsung", label:"Washer", manufacturerName:"Samsung Electronics", 
	presentationId:"DA-WM-WM-000001", deviceManufacturerCode:"Samsung Electronics",
	deviceTypeName:"Samsung OCF Washer", 
	components:[
		[id:"main", label:"main", 
		 capabilities:[
			 [id:"execute", version:1], [id:"ocf", version:1], [id:"powerConsumptionReport", version:1], 
			 [id:"refresh", version:1], [id:"remoteControlStatus", version:1], [id:"switch", version:1], 
			 [id:"washerOperatingState", version:1], [id:"custom.disabledCapabilities", version:1], 
			 [id:"custom.dryerDryLevel", version:1], [id:"custom.jobBeginningStatus", version:1], 
			 [id:"custom.supportedOptions", version:1], [id:"custom.washerAutoDetergent", version:1], 
			 [id:"custom.washerAutoSoftener", version:1], [id:"custom.washerRinseCycles", version:1], 
			 [id:"custom.washerSoilLevel", version:1], [id:"custom.washerSpinLevel", version:1], 
			 [id:"custom.washerWaterTemperature", version:1], [id:"samsungce.autoDispenseDetergent", version:1], 
			 [id:"samsungce.autoDispenseSoftener", version:1], [id:"samsungce.detergentOrder", version:1], 
			 [id:"samsungce.detergentState", version:1], [id:"samsungce.deviceIdentification", version:1], 
			 [id:"samsungce.driverVersion", version:1], [id:"samsungce.kidsLock", version:1], 
			 [id:"samsungce.softenerOrder", version:1], [id:"samsungce.softenerState", version:1], 
			 [id:"samsungce.washerBubbleSoak", version:1], [id:"samsungce.washerCycle", version:1], 
			 [id:"samsungce.washerCyclePreset", version:1], [id:"samsungce.washerDelayEnd", version:1], 
			 [id:"samsungce.washerFreezePrevent", version:1], [id:"samsungce.washerWashingTime", version:1], 
			 [id:"samsungce.washerWaterLevel", version:1], [id:"samsungce.washerWaterValve", version:1], 
			 [id:"samsungce.welcomeMessage", version:1], [id:"samsungce.waterConsumptionReport", version:1]], 
		 categories:[[name:"Washer", categoryType:"manufacturer"]]]
	], 
	createTime:"2022-03-28T19:35:56.255Z", profile:[id:"b2c7d635-7f8a-3f3f-b431-36d81ac62eee"], 
	type:OCF, restrictionTier:0, allowed:[]]

Map status = [
	components:[
		main:[
			"samsungce.washerDelayEnd":[
				remainingTime:[value:null],
				minimumReservableTime:[value:null]], 
			"samsungce.washerWaterLevel":[
				supportedWaterLevel:[value:null], 
				waterLevel:[value:null]], 
			"samsungce.welcomeMessage":[
				welcomeMessage:[value:null]], 
			"custom.washerWaterTemperature":[
				supportedWasherWaterTemperature:[value:["none", "tapCold", "cold", "warm", "hot", "extraHot"], timestamp:"2022-03-28T19:35:57.777Z"],
				washerWaterTemperature:[value:"warm", timestamp:"2022-04-09T13:01:33.658Z"]],
			"samsungce.autoDispenseSoftener":[
				remainingAmount:[value:null]], 
			"samsungce.autoDispenseDetergent":[
				remainingAmount:[value:null]], 
			washerOperatingState:[
				completionTime:[value:"2022-04-09T17:56:26Z", timestamp:"2022-04-09T17:55:26.575Z"], 
				machineState:[value:"stop", timestamp:"2022-04-09T17:55:26.555Z"], 
				washerJobState:[value:"none", timestamp:"2022-04-09T17:55:26.566Z"], 
				supportedMachineStates:[value:null]], 
			switch:[
				switch:[value:"off", timestamp:"2022-04-09T17:55:26.399Z"]], 
			"custom.disabledCapabilities":[
				disabledCapabilities:[
					value:[
						"samsungce.autoDispenseDetergent", "samsungce.autoDispenseSoftener", "samsungce.washerCyclePreset",
						"samsungce.waterConsumptionReport", "demandResponseLoadControl", "samsungce.softenerOrder",
						"samsungce.softenerState", "samsungce.washerBubbleSoak", "samsungce.washerFreezePrevent",
						"custom.dryerDryLevel", "custom.washerRinseCycles", "custom.washerSoilLevel",
						"custom.washerSpinLevel", "samsungce.washerWaterLevel", "samsungce.washerWaterValve",
						"samsungce.washerWashingTime", "custom.washerAutoDetergent", "custom.washerAutoSoftener"], 
					timestamp:"2022-06-14T21:09:10.516Z"]], 
			"custom.washerRinseCycles":[
				supportedWasherRinseCycles:[value:null], 
				washerRinseCycles:[value:null]], 
			"samsungce.kidsLock":[
				lockState:[value:"unlocked", timestamp:"2022-03-28T19:35:57.523Z"]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:39800,
						deltaEnergy:0,
						power:0,
						powerEnergy:0.0,
						persistedEnergy:0,
						energySaved:0,
						start:"2022-04-09T17:42:42Z",
						end:"2022-04-09T17:54:58Z"],
					timestamp:"2022-04-09T17:54:58.541Z"]],
			"custom.washerSoilLevel":[
				supportedWasherSoilLevel:[value:["none", "light", "down", "normal", "up", "heavy"], timestamp:"2022-03-28T19:35:57.777Z"], 
				washerSoilLevel:[value:"normal", timestamp:"2022-03-28T19:35:57.777Z"]], 
			"samsungce.washerBubbleSoak":[
				status:[value:null]], 
			"samsungce.detergentState":[
				remainingAmount:[value:null], 
				dosage:[value:null], 
				initialAmount:[value:null], 
				detergentType:[value:null]], 
			refresh:[:], 
			"custom.jobBeginningStatus":[
				jobBeginningStatus:[value:null]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:"2022-03-29T19:43:22.494Z"]], 
			"custom.washerSpinLevel":[
				washerSpinLevel:[value:"low", timestamp:"2022-04-09T16:57:37.941Z"], 
				supportedWasherSpinLevel:[value:["rinseHold", "noSpin", "low", "medium", "high", "extraHigh"], timestamp:"2022-03-28T19:35:57.777Z"]]
		]
	]
]

/*
//	Capability API
//	Design Capabilities
def switch = [
	id:switch, version:1, status:live, name:Switch, ephemeral:false, 
	attributes:[
		switch:[schema:[
			type:object, 
			properties:[value:[title:SwitchState, type:string, enum:[on, off]]],
			additionalProperties:false, required:[value]], 
				enumCommands:[[command:on, value:on], [command:off, value:off]]]], 
	//	Not implemented
	commands:[
		off:[name:off, arguments:[]], 
		on:[name:on, arguments:[]]]]
	
def washerOperatingState = [
	id:washerOperatingState, version:1, status:live, name:Washer Operating State, ephemeral:false, 
	attributes:[
		completionTime:[
			schema:[
				type:object, 
				properties:[value:[pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$, title:Iso8601Date, type:string]], 
				additionalProperties:false, required:[value]], enumCommands:[]], 
		machineState:[
			schema:[
				type:object, 
				properties:[value:[title:MachineState, enum:[pause, run, stop], type:string]], 
				additionalProperties:false, required:[value]], setter:setMachineState, 
			enumCommands:[]], 
		washerJobState:[
			schema:[
				type:object, 
				properties:[value:[enum:[
					airWash, aIRinse, aISpin, aIWash, cooling, delayWash, drying, finish, 
					none, preWash, rinse, spin, wash, weightSensing, wrinklePrevent, 
					freezeProtection], type:string]], 
				additionalProperties:false, required:[value]], 
			enumCommands:[]], 
		//Not Implemented
		supportedMachineStates:[
			schema:[
				type:object, 
				properties:[value:[items:[title:MachineState, enum:[pause, run, stop], type:string], type:array]], 
				additionalProperties:false, required:[]], 
			enumCommands:[]]
	], 
	commands:[
		setMachineState:[
			name:setMachineState, 
			arguments:[
				[name:state, optional:false, schema:[title:MachineState, enum:[pause, run, stop], type:string]]
			]]]]

def samsungce_kidsLock = [
	id:samsungce.kidsLock, version:1, status:proposed, name:Kids Lock, ephemeral:false, 
	attributes:[
		lockState:[schema:[
			type:object,
			properties:[value:[type:string, enum:[locked, unlocked, paused]]],
			additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]

def remoteControlStatus = [
	id:remoteControlStatus, version:1, status:live, name:Remote Control Status, ephemeral:false, 
	attributes:[
		remoteControlEnabled:[schema:[
			type:object, 
			properties:[value:[type:string, enum:[false, true]]], 
			additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]

def custom_washerWaterTemperature = [
	id:custom.washerWaterTemperature, version:1, status:proposed, name:Washer Water Temperature, ephemeral:false, 
	attributes:[
		//	Not in baseline.  Future?
		supportedWasherWaterTemperature:[
			schema:[
				title:supportedWasherWaterTemperature, type:object, 
				properties:[value:[type:array, items:[enum:[
					none, 20, 30, 40, 50, 60, 65, 70, 75, 80, 90, 95, tapCold, cold, cool, ecoWarm, 
					warm, semiHot, hot, extraHot, extraLow, low, mediumLow, medium, high], type:string, title:waterTemperature]]], 
				additionalProperties:false, required:[value]], enumCommands:[]], 
		washerWaterTemperature:[
			schema:[
				title:washerWaterTemperature, type:object, 
				properties:[value:[enum:[
					none, 20, 30, 40, 50, 60, 65, 70, 75, 80, 90, 95, tapCold, cold, cool, ecoWarm, 
					warm, semiHot, hot, extraHot, extraLow, low, mediumLow, medium, high], type:string]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	//	Not in baseline.  Future?
	commands:[
		setWasherWaterTemperature:[
			name:setWasherWaterTemperature, 
			arguments:[[name:temperature, optional:false, schema:[enum:[
				none, 20, 30, 40, 50, 60, 65, 70, 75, 80, 90, 95, tapCold, cold, cool, ecoWarm, 
				warm, semiHot, hot, extraHot, extraLow, low, mediumLow, medium, high], type:string]]]]]]

def custom_washerSoilLevel = [
	id:custom.washerSoilLevel, version:1, status:proposed, name:Washer Soil Level, ephemeral:false, 
	attributes:[
	//	Not in baseline.  Future?
		supportedWasherSoilLevel:[
			schema:[
				title:supportedWasherSoilLevel, type:object, 
				properties:[value:[items:[enum:[
					none, heavy, normal, light, extraLight, extraHeavy, up, down],
										  title:soilLevel, type:string], type:array]], 
				additionalProperties:false, required:[value]], enumCommands:[]], 
		washerSoilLevel:[
			schema:[
				title:washerSoilLevel, type:object, 
				properties:[value:[enum:[none, heavy, normal, light, extraLight, extraHeavy, up, down], type:string]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	//	Not in baseline.  Future?
	commands:[
		setWasherSoilLevel:[
			name:setWasherSoilLevel, 
			arguments:[
				[name:soilLevel, optional:false, 
				 schema:[enum:[none, heavy, normal, light, extraLight, extraHeavy, up, down], type:string]]
			]]]]

def custom_washerSpinLevel = [
	id:custom.washerSpinLevel, version:1, status:proposed, name:Washer Spin Level, ephemeral:false, 
	attributes:[
		washerSpinLevel:[
			schema:[
				title:washerSpinLevel, type:object, 
				properties:[value:[enum:[none, rinseHold, noSpin, low, extraLow, delicate, medium, 
										 high, extraHigh, 200, 400, 600, 800, 1000, 1200, 1400, 1600], type:string]], 
				additionalProperties:false, required:[value]], enumCommands:[]], 
	//	Not in baseline.  Future?
		supportedWasherSpinLevel:[
			schema:[
				title:supportedWasherSpinLevel, type:object, 
				properties:[value:[type:array, items:[enum:[none, rinseHold, noSpin, low, extraLow, delicate, 
															medium, high, extraHigh, 200, 400, 600, 800, 1000, 
															1200, 1400, 1600], title:spinLevel, type:string]]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	//	Not in baseline.  Future?
	commands:[
		setWasherSpinLevel:[
			name:setWasherSpinLevel, 
			arguments:[
				[name:spinLevel, optional:false, schema:[enum:[none, rinseHold, noSpin, low, extraLow, delicate, 
															   medium, high, extraHigh, 200, 400, 600, 800, 1000, 
															   1200, 1400, 1600], type:string]]
			]]]]

def custom_jobBeginningStatus = [
	id:custom.jobBeginningStatus, version:1, status:proposed, name:Job Beginning Status, ephemeral:false, 
	attributes:[
		jobBeginningStatus:[schema:[type:object, properties:[value:[type:string, enum:[None, ReadyToRun]]], 
									additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]

//	Not Implemented Capabilities

def samsungce_washerDelayEnd = [
	id:samsungce.washerDelayEnd, version:1, status:proposed, name:Washer Delay End, ephemeral:false, 
	attributes:[
		remainingTime:[schema:[type:object, properties:[value:[type:integer, minimum:0, maximum:1440], 
														unit:[type:string, enum:[min], default:min]], 
							   additionalProperties:false, required:[value, unit]], 
					   enumCommands:[]], 
		minimumReservableTime:[schema:[type:object, properties:[value:[type:integer, minimum:0, maximum:1440], 
																unit:[type:string, enum:[min], default:min]], 
									   additionalProperties:false, required:[value, unit]], 
							   enumCommands:[]]], 
	commands:[
		refreshMinimumReservableTime:[
			name:refreshMinimumReservableTime, arguments:[]], 
		setDelayTime:[
			name:setDelayTime,
			arguments:[
				[name:delayTime, optional:false, schema:[type:integer, minimum:0, maximum:1440]]
			]]]]

def samsungce_washerCycle = [
	id:samsungce.washerCycle, version:1, status:proposed, name:Washer Cycle, ephemeral:false, 
	attributes:[
		supportedCycles:[
			schema:[type:object, 
					properties:[
						value:[type:array, 
							   items:[type:object, additionalProperties:false, 
									  properties:[cycle:[type:string], 
												  supportedOptions:[
													  type:object, 
													  additionalProperties:false, 
													  patternProperties:[^.{1,32}$:[
														  type:object, additionalProperties:false, 
														  properties:[raw:[type:string], default:[type:string], options:[type:array, items:[type:string]]]]]]], 
									  required:[cycle, supportedOptions], 
									  examples:[[cycle:01, supportedOptions:[spinLevel:[raw:A53F, default:extraHigh, options:[rinseHold, delicate, low, medium, high, extraHigh]], 
																			 rinseCycle:[raw:933F, default:3, options:[0, 1, 2, 3, 4, 5]], 
																			 waterTemperature:[raw:821E, default:30, options:[cold, 30, 40, 60]]]]]]]], 
					additionalProperties:false, required:[value]], enumCommands:[]], 
		washerCycle:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], setter:setWasherCycle, enumCommands:[]], 
		referenceTable:[schema:[type:object, properties:[value:[type:object, additionalProperties:false, properties:[id:[type:string]]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setWasherCycle:[name:setWasherCycle, arguments:[[name:washerCycle, optional:false, schema:[type:string]]]]]]

def powerConsumptionReport = [
	id:powerConsumptionReport, version:1, status:live, name:Power Consumption Report, ephemeral:false, attributes:[powerConsumption:[schema:[type:object, properties:[value:[properties:[deltaEnergy:[type:number], end:[pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$, title:Iso8601Date, type:string], start:[pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$, title:Iso8601Date, type:string], energySaved:[type:number], persistedSavedEnergy:[type:number], energy:[type:number], power:[type:number], powerEnergy:[type:number], persistedEnergy:[type:number]], additionalProperties:false, title:PowerConsumption, type:object]], additionalProperties:false, required:[value]], enumCommands:[]]], commands:[:]]

def custom_supportedOptions = [
	id:custom.supportedOptions, version:1, status:proposed, name:Supported Options, ephemeral:false, 
	attributes:[
		referenceTable:[schema:[type:object, properties:[value:[type:object, properties:[id:[type:string]], additionalProperties:false]], 
								additionalProperties:false, required:[]], enumCommands:[]], 
		supportedCourses:[schema:[type:object, properties:[value:[type:array, items:[type:string]]], 
								  additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]

//	Device Definition
def reducedWasherStatus = [
	status:OK, data:[components:[
		main:[
			samsungce.washerDelayEnd:[remainingTime:[value:null], minimumReservableTime:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, tapCold, cold, warm, hot, extraHot], timestamp:2022-03-28T19:35:57.777Z], 
				washerWaterTemperature:[value:warm, timestamp:2022-04-09T13:01:33.658Z]],
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:35:57.206Z], 
				modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], 
				modelClassificationCode:[value:20010101001031070100000000000000, timestamp:2022-03-28T19:35:57.206Z], 
				description:[value:DA_WM_A51_20_COMMON_WF7500, timestamp:2022-03-28T19:35:57.206Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-03-28T19:35:57.206Z]], 
			washerOperatingState:[
				completionTime:[value:2022-04-09T17:56:26Z, timestamp:2022-04-09T17:55:26.575Z], 
				machineState:[value:stop, timestamp:2022-04-09T17:55:26.555Z], 
				washerJobState:[value:none, timestamp:2022-04-09T17:55:26.566Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:off, timestamp:2022-04-09T17:55:26.399Z]], 
			samsungce.washerCycle:[supportedCycles:[value:[
				[cycle:7A, supportedOptions:[soilLevel:[raw:C520, default:heavy, options:[heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8410, default:hot, options:[hot]]]], 
				[cycle:57, supportedOptions:[soilLevel:[raw:C000, options:[]], spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], timestamp:2022-03-28T19:35:58.044Z], washerCycle:[value:Table_00_Course_77, timestamp:2022-04-09T16:57:38.040Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[
					samsungce.washerCyclePreset, samsungce.waterConsumptionReport, samsungce.autoDispenseDetergent, 
					samsungce.autoDispenseSoftener, samsungce.detergentOrder, samsungce.detergentState, 
					samsungce.softenerOrder, samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent, 
					custom.washerRinseCycles, custom.dryerWrinklePrevent, samsungce.washerWaterLevel, samsungce.washerWaterValve, 
					samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener, samsungce.welcomeMessage], timestamp:2022-03-28T19:35:59.670Z]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:35:56.591Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:35:57.523Z]], 
			powerConsumptionReport:[
				powerConsumption:[value:[
					energy:39800, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, 
					start:2022-04-09T17:42:42Z, end:2022-04-09T17:54:58Z], timestamp:2022-04-09T17:54:58.541Z]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:[none, light, down, normal, up, heavy], timestamp:2022-03-28T19:35:57.777Z], 
				washerSoilLevel:[value:normal, timestamp:2022-03-28T19:35:57.777Z]], 
			refresh:[:], 
			custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-29T19:43:22.494Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z], 
				supportedCourses:[value:[01, 70, 71, 55, 72, 54, 73, 74, 75, 76, 77, 56, 78, 7A, 57], timestamp:2022-03-28T19:35:57.601Z]], 
			custom.washerSpinLevel:[
				washerSpinLevel:[value:low, timestamp:2022-04-09T16:57:37.941Z], 
				supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2022-03-28T19:35:57.777Z]]
		]]]]]

def WasherDefinition = [
	stLabel:Washer, deviceId:38937b11-c1fb-b219-d3e8-3bc1500db94a, 
	deviceName:[washer] Samsung, 
	main:[
		execute, ocf, powerConsumptionReport, refresh, remoteControlStatus, 
		switch, washerOperatingState, custom.disabledCapabilities, 
		custom.dryerDryLevel, custom.jobBeginningStatus, custom.supportedOptions, 
		custom.washerAutoDetergent, custom.washerAutoSoftener, 
		custom.washerRinseCycles, custom.washerSoilLevel, custom.washerSpinLevel, 
		custom.washerWaterTemperature, samsungce.autoDispenseDetergent, 
		samsungce.autoDispenseSoftener, samsungce.detergentOrder, 
		samsungce.detergentState, samsungce.deviceIdentification, 
		samsungce.driverVersion, samsungce.kidsLock, samsungce.softenerOrder, 
		samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerCycle, 
		samsungce.washerCyclePreset, samsungce.washerDelayEnd, 
		samsungce.washerFreezePrevent, samsungce.washerWashingTime, 
		samsungce.washerWaterLevel, samsungce.washerWaterValve, 
		samsungce.welcomeMessage, samsungce.waterConsumptionReport]]

def fullWasherStatus = [
	status:OK, data:[components:[
		main:[
			samsungce.washerDelayEnd:[remainingTime:[value:null], minimumReservableTime:[value:null]], 
			samsungce.washerWaterLevel:[supportedWaterLevel:[value:null], waterLevel:[value:null]], 
			samsungce.welcomeMessage:[welcomeMessage:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, tapCold, cold, warm, hot, extraHot], timestamp:2022-03-28T19:35:57.777Z], 
				washerWaterTemperature:[value:warm, timestamp:2022-04-09T13:01:33.658Z]], 
			samsungce.autoDispenseSoftener:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], 
			samsungce.autoDispenseDetergent:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:35:57.206Z], 
				modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], 
				modelClassificationCode:[value:20010101001031070100000000000000, timestamp:2022-03-28T19:35:57.206Z], 
				description:[value:DA_WM_A51_20_COMMON_WF7500, timestamp:2022-03-28T19:35:57.206Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-03-28T19:35:57.206Z]], 
			samsungce.washerWaterValve:[waterValve:[value:null], supportedWaterValve:[value:null]], 
			washerOperatingState:[
				completionTime:[value:2022-04-09T17:56:26Z, timestamp:2022-04-09T17:55:26.575Z], 
				machineState:[value:stop, timestamp:2022-04-09T17:55:26.555Z], 
				washerJobState:[value:none, timestamp:2022-04-09T17:55:26.566Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:off, timestamp:2022-04-09T17:55:26.399Z]], 
			custom.washerAutoSoftener:[washerAutoSoftener:[value:null]], 
			samsungce.washerFreezePrevent:[operatingState:[value:null]], 
			samsungce.washerCycle:[supportedCycles:[value:[
				[cycle:01, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:833E, default:warm, options:[tapCold, cold, warm, hot, extraHot]]]], 
				[cycle:70, supportedOptions:[soilLevel:[raw:C53E, default:heavy, options:[light, down, normal, up, heavy]], spinLevel:[raw:A53F, default:extraHigh, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:843E, default:hot, options:[tapCold, cold, warm, hot, extraHot]]]], 
				[cycle:71, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A20F, default:low, options:[rinseHold, noSpin, low, medium]], waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
				[cycle:55, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:831E, default:warm, options:[tapCold, cold, warm, hot]]]], 
				[cycle:72, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]], 
				[cycle:54, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8410, default:hot, options:[hot]]]], 
				[cycle:73, supportedOptions:[soilLevel:[raw:C000, options:[]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8000, options:[]]]], 
				[cycle:74, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
				[cycle:75, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], waterTemperature:[raw:810E, default:tapCold, options:[tapCold, cold, warm]]]], 
				[cycle:76, supportedOptions:[soilLevel:[raw:C308, default:normal, options:[normal]], spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
				[cycle:77, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A21F, default:low, options:[rinseHold, noSpin, low, medium, high]], waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
				[cycle:56, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8106, default:tapCold, options:[tapCold, cold]]]], 
				[cycle:78, supportedOptions:[soilLevel:[raw:C13E, default:light, options:[light, down, normal, up, heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:831E, default:warm, options:[tapCold, cold, warm, hot]]]], 
				[cycle:7A, supportedOptions:[soilLevel:[raw:C520, default:heavy, options:[heavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], waterTemperature:[raw:8410, default:hot, options:[hot]]]], 
				[cycle:57, supportedOptions:[soilLevel:[raw:C000, options:[]], spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], timestamp:2022-03-28T19:35:58.044Z], washerCycle:[value:Table_00_Course_77, timestamp:2022-04-09T16:57:38.040Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z]], 
			samsungce.waterConsumptionReport:[waterConsumption:[value:null]], 
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2022-03-28T19:35:56.530Z], 
				mnhw:[value:ARTIK051, timestamp:2022-03-28T19:35:56.530Z], 
				di:[value:38937b11-c1fb-b219-d3e8-3bc1500db94a, timestamp:2022-03-28T19:35:56.530Z], 
				mnsl:[value:http:www.samsung.com, timestamp:2022-03-28T19:35:56.530Z], 
				dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-03-28T19:35:56.530Z], n:[value:[washer] Samsung, timestamp:2022-03-28T19:35:56.530Z], 
				mnmo:[value:DA_WM_A51_20_COMMON|20185441|20010101001031070100000000000000, timestamp:2022-03-28T19:35:56.530Z], 
				vid:[value:DA-WM-WM-000001, timestamp:2022-03-28T19:35:56.530Z], mnmn:[value:Samsung Electronics, timestamp:2022-03-28T19:35:56.530Z], 
				mnml:[value:http:www.samsung.com, timestamp:2022-03-28T19:35:56.530Z], mnpv:[value:DAWIT 2.0, timestamp:2022-03-28T19:35:56.530Z], 
				mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-03-28T19:35:56.530Z], pi:[value:38937b11-c1fb-b219-d3e8-3bc1500db94a, timestamp:2022-03-28T19:35:56.530Z], 
				icv:[value:core.1.1.0, timestamp:2022-03-28T19:35:56.530Z]], 
			custom.dryerDryLevel:[dryerDryLevel:[value:null], supportedDryerDryLevel:[value:null]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[
					samsungce.washerCyclePreset, samsungce.waterConsumptionReport, samsungce.autoDispenseDetergent, 
					samsungce.autoDispenseSoftener, samsungce.detergentOrder, samsungce.detergentState, 
					samsungce.softenerOrder, samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent, 
					custom.washerRinseCycles, custom.dryerWrinklePrevent, samsungce.washerWaterLevel, samsungce.washerWaterValve, 
					samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener, samsungce.welcomeMessage], timestamp:2022-03-28T19:35:59.670Z]], 
			custom.washerRinseCycles:[supportedWasherRinseCycles:[value:null], washerRinseCycles:[value:null]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:35:56.591Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:35:57.523Z]], 
			samsungce.detergentOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], 
			powerConsumptionReport:[
				powerConsumption:[value:[
					energy:39800, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, 
					start:2022-04-09T17:42:42Z, end:2022-04-09T17:54:58Z], timestamp:2022-04-09T17:54:58.541Z]], 
			samsungce.softenerOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:[none, light, down, normal, up, heavy], timestamp:2022-03-28T19:35:57.777Z], 
				washerSoilLevel:[value:normal, timestamp:2022-03-28T19:35:57.777Z]], 
			samsungce.washerBubbleSoak:[status:[value:null]], 
			samsungce.washerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2022-03-28T19:35:59.550Z], presets:[value:null]], 
			samsungce.detergentState:[remainingAmount:[value:null], dosage:[value:null], initialAmount:[value:null], detergentType:[value:null]], 
			refresh:[:], 
			custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], 
			xxexecute:[
				data:[value:[payload:[
					rt:[x.com.samsung.da.mode], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.options:[AddWashIndicator_On]]], 
					  data:[href:/course/vs/0], timestamp:2022-04-09T17:55:27.046Z]], 
			samsungce.softenerState:[remainingAmount:[value:null], dosage:[value:null], softenerType:[value:null], initialAmount:[value:null]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-29T19:43:22.494Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z], 
				supportedCourses:[value:[01, 70, 71, 55, 72, 54, 73, 74, 75, 76, 77, 56, 78, 7A, 57], timestamp:2022-03-28T19:35:57.601Z]], 
			samsungce.washerWashingTime:[supportedWashingTimes:[value:null], washingTime:[value:null]], 
			custom.washerAutoDetergent:[washerAutoDetergent:[value:null]], 
			custom.washerSpinLevel:[
				washerSpinLevel:[value:low, timestamp:2022-04-09T16:57:37.941Z], 
				supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2022-03-28T19:35:57.777Z]]
		]]]]]


Map status = [
	components:[
		main:[
			samsungce.washerDelayEnd:[
				remainingTime:[value:null],
				minimumReservableTime:[value:null]], 
			samsungce.washerWaterLevel:[
				supportedWaterLevel:[value:null], 
				waterLevel:[value:null]], 
			samsungce.welcomeMessage:[
				welcomeMessage:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, tapCold, cold, warm, hot, extraHot], timestamp:2022-03-28T19:35:57.777Z],
				washerWaterTemperature:[value:warm, timestamp:2022-04-09T13:01:33.658Z]],
			samsungce.autoDispenseSoftener:[
				remainingAmount:[value:null], 
				amount:[value:null], 
				supportedDensity:[value:null], 
				density:[value:null], 
				supportedAmount:[value:null]], 
			samsungce.autoDispenseDetergent:[
				remainingAmount:[value:null], 
				amount:[value:null], 
				supportedDensity:[value:null], 
				density:[value:null], 
				supportedAmount:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:35:57.206Z], 
				modelName:[value:null], serialNumber:[value:null], s
				erialNumberExtra:[value:null], 
				modelClassificationCode:[value:20010101001031070100000000000000, timestamp:2022-03-28T19:35:57.206Z], 
				description:[value:DA_WM_A51_20_COMMON_WF7500, timestamp:2022-03-28T19:35:57.206Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-03-28T19:35:57.206Z]], 
			samsungce.washerWaterValve:[
				waterValve:[value:null], 
				supportedWaterValve:[value:null]], 
			washerOperatingState:[
				completionTime:[value:2022-04-09T17:56:26Z, timestamp:2022-04-09T17:55:26.575Z], 
				machineState:[value:stop, timestamp:2022-04-09T17:55:26.555Z], 
				washerJobState:[value:none, timestamp:2022-04-09T17:55:26.566Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:off, timestamp:2022-04-09T17:55:26.399Z]], 
			custom.washerAutoSoftener:[
				washerAutoSoftener:[value:null]], 
			samsungce.washerFreezePrevent:[
				operatingState:[value:null]], 
			samsungce.washerCycle:[
				supportedCycles:[
					value:[
						[cycle:01, 
						 supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
										   spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
										   waterTemperature:[raw:833E, default:warm, options:[tapCold, cold, warm, hot, extraHot]]]], 
						[cycle:57, supportedOptions:[soilLevel:[raw:C000, options:[]], 
													 spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], 
													 waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], 
					timestamp:2022-03-28T19:35:58.044Z], 
				washerCycle:[value:Table_00_Course_77, timestamp:2022-04-09T16:57:38.040Z], 
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z]], 
			samsungce.waterConsumptionReport:[
				waterConsumption:[value:null]], 
			ocf:["various"], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:null], 
				supportedDryerDryLevel:[value:null]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[
					value:[
						samsungce.autoDispenseDetergent, samsungce.autoDispenseSoftener, samsungce.washerCyclePreset,
						samsungce.waterConsumptionReport, demandResponseLoadControl, samsungce.softenerOrder,
						samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent,
						custom.dryerDryLevel, custom.washerRinseCycles, custom.washerSoilLevel,
						custom.washerSpinLevel, samsungce.washerWaterLevel, samsungce.washerWaterValve,
						samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener], 
					timestamp:2022-06-14T21:09:10.516Z]], 
			custom.washerRinseCycles:[
				supportedWasherRinseCycles:[value:null], 
				washerRinseCycles:[value:null]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:35:56.591Z]], 
			samsungce.kidsLock:[
				lockState:[value:unlocked, timestamp:2022-03-28T19:35:57.523Z]], 
			samsungce.detergentOrder:[
				alarmEnabled:[value:null], 
				orderThreshold:[value:null]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:39800,
						deltaEnergy:0,
						power:0,
						powerEnergy:0.0,
						persistedEnergy:0,
						energySaved:0,
						start:2022-04-09T17:42:42Z,
						end:2022-04-09T17:54:58Z],
					timestamp:2022-04-09T17:54:58.541Z]],
			samsungce.softenerOrder:[
				alarmEnabled:[value:null], 
				orderThreshold:[value:null]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:[none, light, down, normal, up, heavy], timestamp:2022-03-28T19:35:57.777Z], 
				washerSoilLevel:[value:normal, timestamp:2022-03-28T19:35:57.777Z]], 
			samsungce.washerBubbleSoak:[
				status:[value:null]], 
			samsungce.washerCyclePreset:[
				maxNumberOfPresets:[value:10, timestamp:2022-03-28T19:35:59.550Z], 
				presets:[value:null]], 
			samsungce.detergentState:[
				remainingAmount:[value:null], 
				dosage:[value:null], 
				initialAmount:[value:null], 
				detergentType:[value:null]], 
			refresh:[:], 
			custom.jobBeginningStatus:[
				jobBeginningStatus:[value:null]], 
			execute:["various"], 
			samsungce.softenerState:[
				remainingAmount:[
					value:null], 
				dosage:[value:null], 
				softenerType:[value:null], 
				initialAmount:[value:null]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:2022-03-29T19:43:22.494Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z], 
				supportedCourses:[value:[01, 70, 71, 55, 72, 54, 73, 74, 75, 76, 77, 56, 78, 7A, 57], timestamp:2022-03-28T19:35:57.601Z]], 
			samsungce.washerWashingTime:[
				supportedWashingTimes:[value:null], 
				washingTime:[value:null]], 
			custom.washerAutoDetergent:[
				washerAutoDetergent:[value:null]], 
			custom.washerSpinLevel:[
				washerSpinLevel:[value:low, timestamp:2022-04-09T16:57:37.941Z], 
				supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2022-03-28T19:35:57.777Z]]
		]
	]
]

Map description = [
	deviceId:38937b11-c1fb-b219-d3e8-3bc1500db94a, name:[washer] Samsung, label:Washer, manufacturerName:Samsung Electronics, 
	presentationId:DA-WM-WM-000001, deviceManufacturerCode:Samsung Electronics, locationId:82d54519-bc1c-4a99-8873-afb8ab285945, 
	ownerId:0ecc7231-5889-d670-f73b-1004eccfce01, roomId:26d8970a-ca71-4abc-9c1a-a5bacbf3c7ba, 
	deviceTypeName:Samsung OCF Washer, 
	components:[
		[id:main, label:main, 
		 capabilities:[
			 [id:execute, version:1], [id:ocf, version:1], [id:powerConsumptionReport, version:1], 
			 [id:refresh, version:1], [id:remoteControlStatus, version:1], [id:switch, version:1], 
			 [id:washerOperatingState, version:1], [id:custom.disabledCapabilities, version:1], 
			 [id:custom.dryerDryLevel, version:1], [id:custom.jobBeginningStatus, version:1], 
			 [id:custom.supportedOptions, version:1], [id:custom.washerAutoDetergent, version:1], 
			 [id:custom.washerAutoSoftener, version:1], [id:custom.washerRinseCycles, version:1], 
			 [id:custom.washerSoilLevel, version:1], [id:custom.washerSpinLevel, version:1], 
			 [id:custom.washerWaterTemperature, version:1], [id:samsungce.autoDispenseDetergent, version:1], 
			 [id:samsungce.autoDispenseSoftener, version:1], [id:samsungce.detergentOrder, version:1], 
			 [id:samsungce.detergentState, version:1], [id:samsungce.deviceIdentification, version:1], 
			 [id:samsungce.driverVersion, version:1], [id:samsungce.kidsLock, version:1], 
			 [id:samsungce.softenerOrder, version:1], [id:samsungce.softenerState, version:1], 
			 [id:samsungce.washerBubbleSoak, version:1], [id:samsungce.washerCycle, version:1], 
			 [id:samsungce.washerCyclePreset, version:1], [id:samsungce.washerDelayEnd, version:1], 
			 [id:samsungce.washerFreezePrevent, version:1], [id:samsungce.washerWashingTime, version:1], 
			 [id:samsungce.washerWaterLevel, version:1], [id:samsungce.washerWaterValve, version:1], 
			 [id:samsungce.welcomeMessage, version:1], [id:samsungce.waterConsumptionReport, version:1]], 
		 categories:[[name:Washer, categoryType:manufacturer]]]
	], 
	createTime:2022-03-28T19:35:56.255Z, profile:[id:b2c7d635-7f8a-3f3f-b431-36d81ac62eee], 
	ocf:["various"], 
	type:OCF, restrictionTier:0, allowed:[]]

DRYER DATA
dev:1102022-04-10 04:36:09.917 pm info[, 1.0.0]:: Dryer: [stLabel:Dryer, deviceId:c98c12e1-b822-e22f-c98c-b14ff889c897, deviceName:[dryer] Samsung, main:[ocf, execute, refresh, switch, remoteControlStatus, dryerOperatingState, powerConsumptionReport, custom.disabledCapabilities, custom.dryerDryLevel, custom.dryerWrinklePrevent, custom.jobBeginningStatus, custom.supportedOptions, samsungce.detergentOrder, samsungce.detergentState, samsungce.deviceIdentification, samsungce.driverVersion, samsungce.dryerAutoCycleLink, samsungce.dryerCycle, samsungce.dryerCyclePreset, samsungce.dryerDelayEnd, samsungce.dryerDryingTemperature, samsungce.dryerDryingTime, samsungce.dryerFreezePrevent, samsungce.kidsLock, samsungce.welcomeMessage]]
dev:1102022-04-10 04:39:57.823 pm trace[, 1.0.0]:: stGetDeviceStatus: [c98c12e1-b822-e22f-c98c-b14ff889c897 : [status:OK, data:[components:[main:[custom.dryerWrinklePrevent:[operatingState:[value:null], dryerWrinklePrevent:[value:off, timestamp:2022-03-28T19:41:13.634Z]], samsungce.dryerDryingTemperature:[dryingTemperature:[value:medium, timestamp:2022-04-09T20:02:05.594Z], supportedDryingTemperature:[value:[none, extraLow, low, mediumLow, medium, high], timestamp:2022-03-28T19:41:13.634Z]], samsungce.welcomeMessage:[welcomeMessage:[value:null]], samsungce.dryerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2022-04-03T16:00:38.127Z], presets:[value:null]], samsungce.deviceIdentification:[micomAssayCode:[value:20185441, timestamp:2022-03-28T19:41:13.603Z], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], modelClassificationCode:[value:30000001001031000100000000000000, timestamp:2022-03-28T19:41:13.603Z], description:[value:DA_WM_A51_20_COMMON_DV45K6500Ex0, timestamp:2022-04-03T15:53:57.781Z], binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-04-03T15:53:57.781Z]], switch:[switch:[value:off, timestamp:2022-04-09T20:02:05.188Z]], samsungce.dryerFreezePrevent:[operatingState:[value:null]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2022-04-03T16:00:36.424Z], mnhw:[value:ARTIK051, timestamp:2022-04-03T15:53:56.204Z], di:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], mnsl:[value:null], dmv:[value:1.2.1, timestamp:2022-03-28T19:41:15.224Z], n:[value:[dryer] Samsung, timestamp:2022-03-28T19:41:15.224Z], mnmo:[value:DA_WM_A51_20_COMMON|20185441|30000001001031000100000000000000, timestamp:2022-04-03T15:53:56.204Z], vid:[value:DA-WM-WD-000001, timestamp:2022-03-28T19:39:25.368Z], mnmn:[value:Samsung Electronics, timestamp:2022-03-28T19:39:25.368Z], mnml:[value:http://www.samsung.com, timestamp:2022-03-28T19:39:25.368Z], mnpv:[value:DAWIT 2.0, timestamp:2022-04-03T15:53:56.204Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-04-03T15:53:56.204Z], pi:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], icv:[value:core.1.1.0, timestamp:2022-03-28T19:39:25.368Z]], custom.dryerDryLevel:[dryerDryLevel:[value:normal, timestamp:2022-04-09T20:02:05.744Z], supportedDryerDryLevel:[value:[none, damp, less, normal, more, very], timestamp:2022-03-28T19:41:13.634Z]], samsungce.dryerAutoCycleLink:[dryerAutoCycleLink:[value:null]], samsungce.dryerCycle:[dryerCycle:[value:Table_00_Course_01, timestamp:2022-04-09T20:02:05.165Z], supportedCycles:[value:[[cycle:01, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:70, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:71, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:77, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:76, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8204, default:low, options:[low]]]], [cycle:75, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]], [cycle:74, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:6F, supportedOptions:[dryingLevel:[raw:D520, default:very, options:[very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7C, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7D, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7E, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8000, options:[]]]], [cycle:7F, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:853E, default:high, options:[extraLow, low, mediumLow, medium, high]]]], [cycle:80, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:81, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]]], timestamp:2022-03-28T19:41:15.122Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z]], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.dryerCyclePreset, samsungce.detergentOrder, samsungce.detergentState, samsungce.dryerFreezePrevent, samsungce.welcomeMessage], timestamp:2022-04-03T15:53:59.721Z]], samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:39:25.388Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:41:15.099Z]], samsungce.detergentOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], powerConsumptionReport:[powerConsumption:[value:[energy:626400, deltaEnergy:200, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, start:2022-04-09T19:52:23Z, end:2022-04-09T19:57:57Z], timestamp:2022-04-09T19:57:57.648Z]], dryerOperatingState:[completionTime:[value:2022-04-09T21:17:05Z, timestamp:2022-04-09T20:02:05.880Z], machineState:[value:stop, timestamp:2022-04-09T20:02:05.267Z], supportedMachineStates:[value:null], dryerJobState:[value:none, timestamp:2022-04-09T20:02:05.458Z]], samsungce.detergentState:[remainingAmount:[value:null], dosage:[value:null], initialAmount:[value:null], detergentType:[value:null]], samsungce.dryerDelayEnd:[remainingTime:[value:null]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.operation], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.state:Ready, x.com.samsung.da.remainingTime:01:15:00, x.com.samsung.da.progressPercentage:1, x.com.samsung.da.progress:None, x.com.samsung.da.supportedProgress:[None, Drying, Cooling, Finish]]], data:[href:/operational/state/vs/0], timestamp:2022-04-09T20:02:05.880Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-29T19:45:26.777Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z], supportedCourses:[value:[01, 70, 71, 77, 76, 75, 74, 6F, 7C, 7D, 7E, 7F, 80, 81], timestamp:2022-03-28T19:41:15.122Z]], samsungce.dryerDryingTime:[supportedDryingTime:[value:[0, 20, 30, 40, 50, 60], timestamp:2022-03-28T19:41:13.634Z], dryingTime:[value:0, unit:min, timestamp:2022-04-09T20:02:05.740Z]]]]]]]

//WASHERS WITH TOP LOADS
//deviceStatus: [components:[sub:[samsungce.washerDelayEnd:[remainingTime:[value:0, unit:min, timestamp:2021-10-29T02:43:51.582Z], minimumReservableTime:[value:41, unit:min, timestamp:2021-10-29T02:43:50.218Z]], samsungce.washerWaterLevel:[supportedWaterLevel:[value:null], waterLevel:[value:null]], custom.washerWaterTemperature:[supportedWasherWaterTemperature:[value:[none, cold, warm], timestamp:2021-05-21T03:19:49.096Z], washerWaterTemperature:[value:cold, timestamp:2021-05-21T03:19:49.096Z]], samsungce.autoDispenseSoftener:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], samsungce.autoDispenseDetergent:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], samsungce.deviceIdentification:[micomAssayCode:[value:20198042, timestamp:2021-05-21T03:19:48.915Z], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], modelClassificationCode:[value:20020001001111000203000000000000, timestamp:2021-05-21T03:19:48.915Z], description:[value:DA_WM_A51_20_COMMON_WV9900M/DC92-02089B_0010, timestamp:2021-05-21T09:14:04.920Z], binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2021-05-21T03:19:48.915Z]], samsungce.washerWaterValve:[waterValve:[value:null], supportedWaterValve:[value:null]], washerOperatingState:[completionTime:[value:2022-08-21T15:02:13Z, timestamp:2022-08-21T14:21:13.521Z], machineState:[value:stop, timestamp:2021-12-01T20:10:32.860Z], washerJobState:[value:none, timestamp:2021-12-01T20:10:35.804Z], supportedMachineStates:[value:null]], switch:[switch:[value:on, timestamp:2022-08-21T14:21:13.523Z]], custom.washerAutoSoftener:[washerAutoSoftener:[value:null]], samsungce.washerFreezePrevent:[operatingState:[value:null]], samsungce.washerCycle:[supportedCycles:[value:[[cycle:01, supportedOptions:[waterTemperature:[raw:8206, default:warm, options:[cold, warm]]]], [cycle:A2, supportedOptions:[waterTemperature:[raw:8106, default:cold, options:[cold, warm]]]], [cycle:A3, supportedOptions:[waterTemperature:[raw:8206, default:warm, options:[cold, warm]]]], [cycle:9D, supportedOptions:[waterTemperature:[raw:8000, options:[]]]], [cycle:91, supportedOptions:[waterTemperature:[raw:8204, default:warm, options:[warm]]]]], timestamp:2021-05-21T03:19:50.366Z], washerCycle:[value:Table_00_Course_A2, timestamp:2021-05-21T09:14:05.765Z], referenceTable:[value:[id:Table_00], timestamp:2021-05-21T09:14:05.765Z]], samsungce.waterConsumptionReport:[waterConsumption:[value:null]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], di:[value:null], mnsl:[value:null], dmv:[value:null], n:[value:null], mnmo:[value:null], vid:[value:null], mnmn:[value:null], mnml:[value:null], mnpv:[value:null], mnos:[value:null], pi:[value:null], icv:[value:null]], custom.dryerDryLevel:[dryerDryLevel:[value:null], supportedDryerDryLevel:[value:null]], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.autoDispenseDetergent, samsungce.autoDispenseSoftener, samsungce.washerCyclePreset, samsungce.waterConsumptionReport, demandResponseLoadControl, samsungce.softenerOrder, samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent, custom.dryerDryLevel, custom.washerRinseCycles, custom.washerSoilLevel, custom.washerSpinLevel, samsungce.washerWaterLevel, samsungce.washerWaterValve, samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener], timestamp:2022-06-14T21:09:10.516Z]], custom.washerRinseCycles:[supportedWasherRinseCycles:[value:null], washerRinseCycles:[value:null]], samsungce.driverVersion:[versionNumber:[value:null]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-05-21T03:19:48.343Z]], demandResponseLoadControl:[drlcStatus:[value:null]], samsungce.detergentOrder:[alarmEnabled:[value:false, timestamp:2021-05-21T03:19:48.842Z], orderThreshold:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z]], powerConsumptionReport:[powerConsumption:[value:[energy:100, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, start:2022-08-21T20:50:40Z, end:2022-08-21T21:05:42Z], timestamp:2022-08-21T21:05:42.888Z]], samsungce.softenerOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], custom.washerSoilLevel:[supportedWasherSoilLevel:[value:null], washerSoilLevel:[value:null]], samsungce.washerBubbleSoak:[status:[value:null]], samsungce.washerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2021-05-21T03:19:48.455Z], presets:[value:null]], samsungce.detergentState:[remainingAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], dosage:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], initialAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], detergentType:[value:none, timestamp:2021-05-21T03:19:48.842Z]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:null]], samsungce.softenerState:[remainingAmount:[value:null], dosage:[value:null], softenerType:[value:null], initialAmount:[value:null]], remoteControlStatus:[remoteControlEnabled:[value:true, timestamp:2022-08-21T14:21:25.233Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2021-05-21T09:14:05.765Z], supportedCourses:[value:[01, A2, A3, 9D, 91], timestamp:2021-05-21T03:19:48.842Z]], samsungce.washerWashingTime:[supportedWashingTimes:[value:null], washingTime:[value:null]], custom.washerAutoDetergent:[washerAutoDetergent:[value:null]], custom.washerSpinLevel:[washerSpinLevel:[value:null], supportedWasherSpinLevel:[value:null]]], main:[samsungce.washerDelayEnd:[remainingTime:[value:0, unit:min, timestamp:2021-10-29T02:43:51.496Z], minimumReservableTime:[value:75, unit:min, timestamp:2022-08-21T20:29:55.173Z]], samsungce.washerWaterLevel:[supportedWaterLevel:[value:null], waterLevel:[value:null]], samsungce.welcomeMessage:[welcomeMessage:[value:null]], custom.washerWaterTemperature:[supportedWasherWaterTemperature:[value:[none, cold, cool, warm, hot, extraHot], timestamp:2021-05-21T03:19:47.318Z], washerWaterTemperature:[value:warm, timestamp:2022-08-21T17:59:44.885Z]], samsungce.autoDispenseSoftener:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], samsungce.autoDispenseDetergent:[remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], density:[value:null], supportedAmount:[value:null]], samsungce.deviceIdentification:[micomAssayCode:[value:20198042, timestamp:2021-05-21T03:19:48.614Z], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], modelClassificationCode:[value:20020001001111420203000000000000, timestamp:2021-05-21T03:19:48.614Z], description:[value:DA_WM_A51_20_COMMON_WV9900M/DC92-01980B_0010, timestamp:2021-05-21T03:19:48.614Z], binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2021-05-21T03:19:48.614Z]], samsungce.washerWaterValve:[waterValve:[value:null], supportedWaterValve:[value:null]], washerOperatingState:[completionTime:[value:2022-08-21T21:47:16Z, timestamp:2022-08-21T20:35:16.615Z], machineState:[value:run, timestamp:2022-08-21T20:30:04.241Z], washerJobState:[value:wash, timestamp:2022-08-21T20:30:45.407Z], supportedMachineStates:[value:null]], switch:[switch:[value:on, timestamp:2022-08-21T20:29:54.442Z]], custom.washerAutoSoftener:[washerAutoSoftener:[value:null]], samsungce.washerFreezePrevent:[operatingState:[value:null]], samsungce.washerCycle:[supportedCycles:[value:[[cycle:01, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43B, default:high, options:[rinseHold, noSpin, medium, high, extraHigh]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:833E, default:warm, options:[cold, cool, warm, hot, extraHot]]]], [cycle:9C, supportedOptions:[soilLevel:[raw:C53E, default:extraHeavy, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A53F, default:extraHigh, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:843E, default:hot, options:[cold, cool, warm, hot, extraHot]]]], [cycle:AA, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], [cycle:A9, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]], [cycle:A2, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], rinseCycle:[raw:920F, default:2, options:[0, 1, 2, 3]], waterTemperature:[raw:810E, default:cold, options:[cold, cool, warm]]]], [cycle:9E, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A21F, default:low, options:[rinseHold, noSpin, low, medium, high]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], [cycle:94, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], [cycle:A5, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A20F, default:low, options:[rinseHold, noSpin, low, medium]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], [cycle:9F, supportedOptions:[soilLevel:[raw:C13E, default:extraLight, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], [cycle:AB, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:8106, default:cold, options:[cold, cool]]]], [cycle:A3, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], [cycle:9D, supportedOptions:[soilLevel:[raw:C000, options:[]], spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], waterTemperature:[raw:8000, options:[]]]], [cycle:B1, supportedOptions:[soilLevel:[raw:C000, options:[]], spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], rinseCycle:[raw:9204, default:2, options:[2]], waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], timestamp:2021-05-21T03:19:48.954Z], washerCycle:[value:Table_00_Course_A5, timestamp:2022-08-21T20:29:54.716Z], referenceTable:[value:[id:Table_00], timestamp:2021-05-21T03:19:48.023Z]], samsungce.waterConsumptionReport:[waterConsumption:[value:null]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2021-05-21T03:19:49.725Z], mnhw:[value:ARTIK051, timestamp:2021-05-21T03:19:49.725Z], di:[value:f124b323-891b-03f2-6374-9e1f57c70a72, timestamp:2021-05-21T03:19:49.725Z], mnsl:[value:http://www.samsung.com, timestamp:2021-10-30T22:53:31.831Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2021-05-21T03:19:49.725Z], n:[value:[washer] Samsung, timestamp:2021-05-21T03:19:49.725Z], mnmo:[value:DA_WM_A51_20_COMMON|20198042|20020001001111420203000000000000, timestamp:2021-05-21T03:19:49.725Z], vid:[value:DA-WM-WM-000002, timestamp:2021-05-21T03:19:49.725Z], mnmn:[value:Samsung Electronics, timestamp:2021-05-21T03:19:49.725Z], mnml:[value:http://www.samsung.com, timestamp:2021-05-21T03:19:49.725Z], mnpv:[value:DAWIT 2.0, timestamp:2021-05-21T03:19:49.725Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-05-21T03:19:49.725Z], pi:[value:f124b323-891b-03f2-6374-9e1f57c70a72, timestamp:2021-05-21T03:19:49.725Z], icv:[value:core.1.1.0, timestamp:2021-05-21T03:19:49.725Z]], custom.dryerDryLevel:[dryerDryLevel:[value:null], supportedDryerDryLevel:[value:null]], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.autoDispenseDetergent, samsungce.autoDispenseSoftener, samsungce.washerCyclePreset, samsungce.waterConsumptionReport, samsungce.welcomeMessage, demandResponseLoadControl, samsungce.softenerOrder, samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent, custom.dryerDryLevel, samsungce.washerWaterLevel, samsungce.washerWaterValve, samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener, sec.diagnosticsInformation], timestamp:2022-06-14T21:09:10.360Z]], custom.washerRinseCycles:[supportedWasherRinseCycles:[value:[0, 1, 2, 3, 4, 5], timestamp:2021-05-21T03:19:47.318Z], washerRinseCycles:[value:2, timestamp:2022-07-21T12:27:31.784Z]], samsungce.driverVersion:[versionNumber:[value:22061301, timestamp:2022-06-14T21:09:10.360Z]], sec.diagnosticsInformation:[logType:[value:null], endpoint:[value:null], minVersion:[value:null], setupId:[value:null], protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-08-21T17:53:52.956Z]], demandResponseLoadControl:[drlcStatus:[value:null]], samsungce.detergentOrder:[alarmEnabled:[value:false, timestamp:2021-05-21T03:19:48.954Z], orderThreshold:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z]], powerConsumptionReport:[powerConsumption:[value:[energy:234800, deltaEnergy:100, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, start:2022-08-21T20:50:39Z, end:2022-08-21T21:05:41Z], timestamp:2022-08-21T21:05:41.880Z]], samsungce.softenerOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], custom.washerSoilLevel:[supportedWasherSoilLevel:[value:[none, extraLight, light, normal, heavy, extraHeavy], timestamp:2021-05-21T03:19:47.318Z], washerSoilLevel:[value:normal, timestamp:2022-08-07T06:38:46.969Z]], samsungce.washerBubbleSoak:[status:[value:null]], samsungce.washerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2021-05-21T03:19:47.922Z], presets:[value:null]], samsungce.detergentState:[remainingAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], dosage:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], initialAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], detergentType:[value:none, timestamp:2021-05-21T03:19:48.954Z]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.energyconsumption], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.instantaneousPowerUnit:W, x.com.samsung.da.instantaneousPower:-500, x.com.samsung.da.cumulativePower:100, x.com.samsung.da.cumulativeUnit:Wh, x.com.samsung.da.cumulativeDate:1661090400, x.com.samsung.da.cumulativeDateUTC:1661115600]], data:[href:/energy/consumption/vs/1], timestamp:2022-08-21T21:05:42.888Z]], samsungce.softenerState:[remainingAmount:[value:null], dosage:[value:null], softenerType:[value:null], initialAmount:[value:null]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T17:53:27.392Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2021-05-21T03:19:48.023Z], supportedCourses:[value:[01, 9C, AA, A9, A2, 9E, 94, A5, 9F, AB, A3, 9D, B1], timestamp:2021-05-21T03:19:48.954Z]], samsungce.washerWashingTime:[supportedWashingTimes:[value:null], washingTime:[value:null]], custom.energyType:[energyType:[value:3.0, timestamp:2022-06-14T21:09:10.360Z], energySavingSupport:[value:false, timestamp:2022-06-14T21:09:10.360Z], drMaxDuration:[value:null], energySavingOperation:[value:null], energySavingOperationSupport:[value:null]], samsungce.softwareUpdate:[otnDUID:[value:RLCDM6YAHRJ2S, timestamp:2022-06-14T21:09:10.360Z], availableModules:[value:[], timestamp:2022-06-14T21:09:10.360Z], newVersionAvailable:[value:false, timestamp:2022-06-14T21:09:10.360Z]], custom.washerAutoDetergent:[washerAutoDetergent:[value:null]], custom.washerSpinLevel:[washerSpinLevel:[value:low, timestamp:2022-08-21T20:29:54.842Z], supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2021-05-21T03:19:47.318Z]]]]]
deviceStatus: [
	components:[
		sub:[
			samsungce.washerDelayEnd:[
				remainingTime:[value:0, unit:min, timestamp:2021-10-29T02:43:51.582Z], 
				minimumReservableTime:[value:41, unit:min, timestamp:2021-10-29T02:43:50.218Z]], 
			samsungce.washerWaterLevel:[supportedWaterLevel:[value:null], waterLevel:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, cold, warm], timestamp:2021-05-21T03:19:49.096Z], 
				washerWaterTemperature:[value:cold, timestamp:2021-05-21T03:19:49.096Z]],
			samsungce.autoDispenseSoftener:[
				remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], 
				density:[value:null], supportedAmount:[value:null]], 
			samsungce.autoDispenseDetergent:[
				remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], 
				density:[value:null], supportedAmount:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20198042, timestamp:2021-05-21T03:19:48.915Z],
				modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], 
				modelClassificationCode:[value:20020001001111000203000000000000, timestamp:2021-05-21T03:19:48.915Z], 
				description:[value:DA_WM_A51_20_COMMON_WV9900M/DC92-02089B_0010, timestamp:2021-05-21T09:14:04.920Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2021-05-21T03:19:48.915Z]], 
			samsungce.washerWaterValve:[waterValve:[value:null], supportedWaterValve:[value:null]], 
			washerOperatingState:[
				completionTime:[value:2022-08-21T15:02:13Z, timestamp:2022-08-21T14:21:13.521Z], 
				machineState:[value:stop, timestamp:2021-12-01T20:10:32.860Z], 
				washerJobState:[value:none, timestamp:2021-12-01T20:10:35.804Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:on, timestamp:2022-08-21T14:21:13.523Z]], 
			custom.washerAutoSoftener:[washerAutoSoftener:[value:null]], 
			samsungce.washerFreezePrevent:[operatingState:[value:null]], 
			samsungce.washerCycle:[
				supportedCycles:[
					value:[
						[cycle:01,supportedOptions:[waterTemperature:[raw:8206, default:warm, options:[cold, warm]]]],
						[cycle:A2, supportedOptions:[waterTemperature:[raw:8106, default:cold, options:[cold, warm]]]],
						[cycle:A3,supportedOptions:[waterTemperature: [raw:8206, default:warm, options:[cold, warm]]]], 
						[cycle:9D, supportedOptions:[waterTemperature:[raw:8000, options:[]]]], 
						[cycle:91, supportedOptions:[waterTemperature:[raw:8204, default:warm, options:[warm]]]]], 
					timestamp:2021-05-21T03:19:50.366Z], 
				washerCycle:[value:Table_00_Course_A2, timestamp:2021-05-21T09:14:05.765Z], 
				referenceTable:[value:[id:Table_00], timestamp:2021-05-21T09:14:05.765Z]], 
			samsungce.waterConsumptionReport:[waterConsumption:[value:null]], 
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], di:[value:null], 
				mnsl:[value:null], dmv:[value:null], n:[value:null], mnmo:[value:null], vid:[value:null], 
				mnmn:[value:null], mnml:[value:null], mnpv:[value:null], mnos:[value:null], 
				pi:[value:null], icv:[value:null]], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:null], 
				supportedDryerDryLevel:[value:null]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[
					value:[
						samsungce.autoDispenseDetergent, samsungce.autoDispenseSoftener, samsungce.washerCyclePreset,
						samsungce.waterConsumptionReport, demandResponseLoadControl, samsungce.softenerOrder,
						samsungce.softenerState, samsungce.washerBubbleSoak, samsungce.washerFreezePrevent,
						custom.dryerDryLevel, custom.washerRinseCycles, custom.washerSoilLevel,
						custom.washerSpinLevel, samsungce.washerWaterLevel, samsungce.washerWaterValve,
						samsungce.washerWashingTime, custom.washerAutoDetergent, custom.washerAutoSoftener], 
					timestamp:2022-06-14T21:09:10.516Z]], 
			custom.washerRinseCycles:[
				supportedWasherRinseCycles:[value:null], 
				washerRinseCycles:[value:null]], 
			samsungce.driverVersion:[versionNumber:[value:null]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-05-21T03:19:48.343Z]], 
			demandResponseLoadControl:[drlcStatus:[value:null]], 
			samsungce.detergentOrder:[
				alarmEnabled:[value:false, timestamp:2021-05-21T03:19:48.842Z], 
				orderThreshold:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[energy:100, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, 
						   energySaved:0, start:2022-08-21T20:50:40Z, end:2022-08-21T21:05:42Z], 
					timestamp:2022-08-21T21:05:42.888Z]], 
			samsungce.softenerOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:null], 
				washerSoilLevel:[value:null]], 
			samsungce.washerBubbleSoak:[status:[value:null]], 
			samsungce.washerCyclePreset:[
				maxNumberOfPresets:[value:10, timestamp:2021-05-21T03:19:48.455Z], 
				presets:[value:null]], 
			samsungce.detergentState:[
				remainingAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], 
				dosage:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], 
				initialAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.842Z], 
				detergentType:[value:none, timestamp:2021-05-21T03:19:48.842Z]], 
			refresh:[:], 
			custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], 
			execute:[data:[value:null]], 
			samsungce.softenerState:[
				remainingAmount:[value:null], dosage:[value:null], 
				softenerType:[value:null], initialAmount:[value:null]], 
			remoteControlStatus:[remoteControlEnabled:[value:true, timestamp:2022-08-21T14:21:25.233Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2021-05-21T09:14:05.765Z], 
				supportedCourses:[value:[01, A2, A3, 9D, 91], timestamp:2021-05-21T03:19:48.842Z]], 
			samsungce.washerWashingTime:[supportedWashingTimes:[value:null], washingTime:[value:null]], 
			custom.washerAutoDetergent:[washerAutoDetergent:[value:null]], 
			custom.washerSpinLevel:[washerSpinLevel:[value:null], supportedWasherSpinLevel:[value:null]]], 
		main:[
			samsungce.washerDelayEnd:[
				remainingTime:[value:0, unit:min, timestamp:2021-10-29T02:43:51.496Z], 
				minimumReservableTime:[value:75, unit:min, timestamp:2022-08-21T20:29:55.173Z]], 
			samsungce.washerWaterLevel:[supportedWaterLevel:[value:null], waterLevel:[value:null]], 
			samsungce.welcomeMessage:[welcomeMessage:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, cold, cool, warm, hot, extraHot], timestamp:2021-05-21T03:19:47.318Z],
				washerWaterTemperature:[value:warm, timestamp:2022-08-21T17:59:44.885Z]], 
			samsungce.autoDispenseSoftener:[
				remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], 
				density:[value:null], supportedAmount:[value:null]], 
			samsungce.autoDispenseDetergent:[
				remainingAmount:[value:null], amount:[value:null], supportedDensity:[value:null], 
				density:[value:null], supportedAmount:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20198042, timestamp:2021-05-21T03:19:48.614Z], modelName:[value:null], 
				serialNumber:[value:null], serialNumberExtra:[value:null], 
				modelClassificationCode:[value:20020001001111420203000000000000, timestamp:2021-05-21T03:19:48.614Z], 
				description:[value:DA_WM_A51_20_COMMON_WV9900M/DC92-01980B_0010, timestamp:2021-05-21T03:19:48.614Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2021-05-21T03:19:48.614Z]], 
			samsungce.washerWaterValve:[waterValve:[value:null], supportedWaterValve:[value:null]], 
			washerOperatingState:[
				completionTime:[value:2022-08-21T21:47:16Z, timestamp:2022-08-21T20:35:16.615Z], 
				machineState:[value:run, timestamp:2022-08-21T20:30:04.241Z], 
				washerJobState:[value:wash, timestamp:2022-08-21T20:30:45.407Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:on, timestamp:2022-08-21T20:29:54.442Z]], 
			custom.washerAutoSoftener:[washerAutoSoftener:[value:null]], 
			samsungce.washerFreezePrevent:[operatingState:[value:null]], 
			samsungce.washerCycle:[
				supportedCycles:[
					value:[
						[cycle:01, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]],
							spinLevel:[raw:A43B, default:high, options:[rinseHold, noSpin, medium, high, extraHigh]],
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]],
							waterTemperature:[raw:833E, default:warm, options:[cold, cool, warm, hot, extraHot]]]], 
						[cycle:9C, supportedOptions:[
							soilLevel:[raw:C53E, default:extraHeavy, options:[extraLight, light, normal, heavy, extraHeavy]],
							spinLevel:[raw:A53F, default:extraHigh, options:[rinseHold, noSpin, low, medium, high, extraHigh]],
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:843E, default:hot, options:[cold, cool, warm, hot, extraHot]]]], 
						[cycle:AA, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], 
						[cycle:A9, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]], 
						[cycle:A2, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], 
							rinseCycle:[raw:920F, default:2, options:[0, 1, 2, 3]], 
							waterTemperature:[raw:810E, default:cold, options:[cold, cool, warm]]]], 
						[cycle:9E, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A21F, default:low, options:[rinseHold, noSpin, low, medium, high]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], 
						[cycle:94, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], 
						[cycle:A5, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A20F, default:low, options:[rinseHold, noSpin, low, medium]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], 
						[cycle:9F, supportedOptions:[
							soilLevel:[raw:C13E, default:extraLight, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:831E, default:warm, options:[cold, cool, warm, hot]]]], 
						[cycle:AB, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:8106, default:cold, options:[cold, cool]]]], 
						[cycle:A3, supportedOptions:[
							soilLevel:[raw:C33E, default:normal, options:[extraLight, light, normal, heavy, extraHeavy]], 
							spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], 
							rinseCycle:[raw:923F, default:2, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:830E, default:warm, options:[cold, cool, warm]]]], 
						[cycle:9D, supportedOptions:[
							soilLevel:[raw:C000, options:[]], 
							spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
							rinseCycle:[raw:913F, default:1, options:[0, 1, 2, 3, 4, 5]], 
							waterTemperature:[raw:8000, options:[]]]], 
						[cycle:B1, supportedOptions:[
							soilLevel:[raw:C000, options:[]], 
							spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], 
							rinseCycle:[raw:9204, default:2, options:[2]], 
							waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], timestamp:2021-05-21T03:19:48.954Z], 
				washerCycle:[value:Table_00_Course_A5, timestamp:2022-08-21T20:29:54.716Z], 
				referenceTable:[value:[id:Table_00], timestamp:2021-05-21T03:19:48.023Z]], 
			samsungce.waterConsumptionReport:[waterConsumption:[value:null]], 
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2021-05-21T03:19:49.725Z], 
				mnhw:[value:ARTIK051, timestamp:2021-05-21T03:19:49.725Z], 
				di:[value:f124b323-891b-03f2-6374-9e1f57c70a72, timestamp:2021-05-21T03:19:49.725Z], 
				mnsl:[value:http:www.samsung.com, timestamp:2021-10-30T22:53:31.831Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2021-05-21T03:19:49.725Z], 
				n:[value:[washer] Samsung, timestamp:2021-05-21T03:19:49.725Z], 
				mnmo:[value:DA_WM_A51_20_COMMON|20198042|20020001001111420203000000000000, timestamp:2021-05-21T03:19:49.725Z], 
				vid:[value:DA-WM-WM-000002, timestamp:2021-05-21T03:19:49.725Z], 
				mnmn:[value:Samsung Electronics, timestamp:2021-05-21T03:19:49.725Z], 
				mnml:[value:http:www.samsung.com, timestamp:2021-05-21T03:19:49.725Z], 
				mnpv:[value:DAWIT 2.0, timestamp:2021-05-21T03:19:49.725Z], 
				mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-05-21T03:19:49.725Z], 
				pi:[value:f124b323-891b-03f2-6374-9e1f57c70a72, timestamp:2021-05-21T03:19:49.725Z], 
				icv:[value:core.1.1.0, timestamp:2021-05-21T03:19:49.725Z]], 
			custom.dryerDryLevel:[dryerDryLevel:[value:null], supportedDryerDryLevel:[value:null]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[
					samsungce.autoDispenseDetergent, samsungce.autoDispenseSoftener, samsungce.washerCyclePreset, 
					samsungce.waterConsumptionReport, samsungce.welcomeMessage, demandResponseLoadControl, 
					samsungce.softenerOrder, samsungce.softenerState, samsungce.washerBubbleSoak, 
					samsungce.washerFreezePrevent, custom.dryerDryLevel, samsungce.washerWaterLevel, 
					samsungce.washerWaterValve, samsungce.washerWashingTime, custom.washerAutoDetergent, 
					custom.washerAutoSoftener, sec.diagnosticsInformation], timestamp:2022-06-14T21:09:10.360Z]], 
			custom.washerRinseCycles:[
				supportedWasherRinseCycles:[value:[0, 1, 2, 3, 4, 5], timestamp:2021-05-21T03:19:47.318Z], 
				washerRinseCycles:[value:2, timestamp:2022-07-21T12:27:31.784Z]], 
			samsungce.driverVersion:[versionNumber:[value:22061301, timestamp:2022-06-14T21:09:10.360Z]], 
			sec.diagnosticsInformation:[
				logType:[value:null], endpoint:[value:null], minVersion:[value:null], setupId:[value:null], 
				protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-08-21T17:53:52.956Z]], 
			demandResponseLoadControl:[drlcStatus:[value:null]], 
			samsungce.detergentOrder:[
				alarmEnabled:[value:false, timestamp:2021-05-21T03:19:48.954Z], 
				orderThreshold:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z]], 
			powerConsumptionReport:[
				powerConsumption:[value:[
					energy:234800, deltaEnergy:100, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, 
					start:2022-08-21T20:50:39Z, end:2022-08-21T21:05:41Z], timestamp:2022-08-21T21:05:41.880Z]], 
			samsungce.softenerOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:[none, extraLight, light, normal, heavy, extraHeavy], timestamp:2021-05-21T03:19:47.318Z], 
				washerSoilLevel:[value:normal, timestamp:2022-08-07T06:38:46.969Z]], 
			samsungce.washerBubbleSoak:[status:[value:null]], 
			samsungce.washerCyclePreset:[
				maxNumberOfPresets:[value:10, timestamp:2021-05-21T03:19:47.922Z], presets:[value:null]], 
			samsungce.detergentState:[
				remainingAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], 
				dosage:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], 
				initialAmount:[value:0, unit:cc, timestamp:2021-05-21T03:19:48.954Z], 
				detergentType:[value:none, timestamp:2021-05-21T03:19:48.954Z]], 
			refresh:[:], 
			custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], 
			execute:[
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.energyconsumption],
							if:[oic.if.baseline, oic.if.a],
							x.com.samsung.da.instantaneousPowerUnit:W, x.com.samsung.da.instantaneousPower:-500,
							x.com.samsung.da.cumulativePower:100, x.com.samsung.da.cumulativeUnit:Wh,
							x.com.samsung.da.cumulativeDate:1661090400, x.com.samsung.da.cumulativeDateUTC:1661115600]],
					data:[href:/energy/consumption/vs/1], timestamp:2022-08-21T21:05:42.888Z]], 
			samsungce.softenerState:[
				remainingAmount:[value:null], dosage:[value:null], softenerType:[value:null], initialAmount:[value:null]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T17:53:27.392Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2021-05-21T03:19:48.023Z], 
				supportedCourses:[value:[01, 9C, AA, A9, A2, 9E, 94, A5, 9F, AB, A3, 9D, B1], timestamp:2021-05-21T03:19:48.954Z]], 
			samsungce.washerWashingTime:[supportedWashingTimes:[value:null], washingTime:[value:null]], 
			custom.energyType:[
				energyType:[value:3.0, timestamp:2022-06-14T21:09:10.360Z], 
				energySavingSupport:[value:false, timestamp:2022-06-14T21:09:10.360Z], 
				drMaxDuration:[value:null], energySavingOperation:[value:null], 
				energySavingOperationSupport:[value:null]], 
			samsungce.softwareUpdate:[
				otnDUID:[value:RLCDM6YAHRJ2S, timestamp:2022-06-14T21:09:10.360Z], 
				availableModules:[value:[], timestamp:2022-06-14T21:09:10.360Z], 
				newVersionAvailable:[value:false, timestamp:2022-06-14T21:09:10.360Z]], 
			custom.washerAutoDetergent:[washerAutoDetergent:[value:null]], 
			custom.washerSpinLevel:[
				washerSpinLevel:[value:low, timestamp:2022-08-21T20:29:54.842Z], 
				supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2021-05-21T03:19:47.318Z]]]
	]
]

devDescription: [
	deviceId:38937b11-c1fb-b219-d3e8-3bc1500db94a, name:[washer] Samsung, label:Washer, manufacturerName:Samsung Electronics, 
	presentationId:DA-WM-WM-000001, deviceManufacturerCode:Samsung Electronics, locationId:82d54519-bc1c-4a99-8873-afb8ab285945, 
	ownerId:0ecc7231-5889-d670-f73b-1004eccfce01, roomId:26d8970a-ca71-4abc-9c1a-a5bacbf3c7ba, 
	deviceTypeName:Samsung OCF Washer, 
	components:[
		[id:main, label:main, 
		 capabilities:[
			 [id:execute, version:1], [id:ocf, version:1], [id:powerConsumptionReport, version:1], 
			 [id:refresh, version:1], [id:remoteControlStatus, version:1], [id:switch, version:1], 
			 [id:washerOperatingState, version:1], [id:custom.disabledCapabilities, version:1], 
			 [id:custom.dryerDryLevel, version:1], [id:custom.jobBeginningStatus, version:1], 
			 [id:custom.supportedOptions, version:1], [id:custom.washerAutoDetergent, version:1], 
			 [id:custom.washerAutoSoftener, version:1], [id:custom.washerRinseCycles, version:1], 
			 [id:custom.washerSoilLevel, version:1], [id:custom.washerSpinLevel, version:1], 
			 [id:custom.washerWaterTemperature, version:1], [id:samsungce.autoDispenseDetergent, version:1], 
			 [id:samsungce.autoDispenseSoftener, version:1], [id:samsungce.detergentOrder, version:1], 
			 [id:samsungce.detergentState, version:1], [id:samsungce.deviceIdentification, version:1], 
			 [id:samsungce.driverVersion, version:1], [id:samsungce.kidsLock, version:1], 
			 [id:samsungce.softenerOrder, version:1], [id:samsungce.softenerState, version:1], 
			 [id:samsungce.washerBubbleSoak, version:1], [id:samsungce.washerCycle, version:1], 
			 [id:samsungce.washerCyclePreset, version:1], [id:samsungce.washerDelayEnd, version:1], 
			 [id:samsungce.washerFreezePrevent, version:1], [id:samsungce.washerWashingTime, version:1], 
			 [id:samsungce.washerWaterLevel, version:1], [id:samsungce.washerWaterValve, version:1], 
			 [id:samsungce.welcomeMessage, version:1], [id:samsungce.waterConsumptionReport, version:1]], 
		 categories:[[name:Washer, categoryType:manufacturer]]]
	], 
	createTime:2022-03-28T19:35:56.255Z, profile:[id:b2c7d635-7f8a-3f3f-b431-36d81ac62eee], 
	ocf:[ocfDeviceType:oic.d.washer, name:[washer] Samsung, specVersion:core.1.1.0, 
		 verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, manufacturerName:Samsung Electronics, 
		 modelNumber:DA_WM_A51_20_COMMON|20185441|20010101001031070100000000000000, platformVersion:DAWIT 2.0, 
		 platformOS:TizenRT 1.0 + IPv6, hwVersion:ARTIK051, firmwareVersion:DA_WM_A51_20_COMMON_30210227, 
		 vendorId:DA-WM-WM-000001, vendorResourceClientServerVersion:ARTIK051 Release 2.210219.1, 
		 lastSignupTime:2022-03-28T19:35:52.099859Z], 
	type:OCF, restrictionTier:0, allowed:[]]
]

//	data from partners
//	===== Washer =====	


def washer =[ data:[
	components:[
		main:[
			samsungce.washerDelayEnd:[
				remainingTime:[value:null],
				minimumReservableTime:[value:null]], 
			samsungce.washerWaterLevel:[
				supportedWaterLevel:[value:null], 
				waterLevel:[value:null]], 
			samsungce.welcomeMessage:[
				welcomeMessage:[value:null]], 
			custom.washerWaterTemperature:[
				supportedWasherWaterTemperature:[value:[none, tapCold, cold, warm, hot, extraHot], timestamp:2022-03-28T19:35:57.777Z],
				washerWaterTemperature:[value:warm, timestamp:2022-04-09T13:01:33.658Z]], ////////////////////////
			samsungce.autoDispenseSoftener:[
				remainingAmount:[value:null], 
				amount:[value:null], 
				supportedDensity:[value:null], 
				density:[value:null], 
				supportedAmount:[value:null]], 
			samsungce.autoDispenseDetergent:[
				remainingAmount:[value:null], 
				amount:[value:null], 
				supportedDensity:[value:null], 
				density:[value:null], 
				supportedAmount:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:35:57.206Z], 
				modelName:[value:null], serialNumber:[value:null], s
				erialNumberExtra:[value:null], 
				modelClassificationCode:[value:20010101001031070100000000000000, timestamp:2022-03-28T19:35:57.206Z], 
				description:[value:DA_WM_A51_20_COMMON_WF7500, timestamp:2022-03-28T19:35:57.206Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-03-28T19:35:57.206Z]], 
			samsungce.washerWaterValve:[
				waterValve:[value:null], 
				supportedWaterValve:[value:null]], 
			washerOperatingState:[
				completionTime:[value:2022-04-09T17:56:26Z, timestamp:2022-04-09T17:55:26.575Z], 
				machineState:[value:stop, timestamp:2022-04-09T17:55:26.555Z], 
				washerJobState:[value:none, timestamp:2022-04-09T17:55:26.566Z], 
				supportedMachineStates:[value:null]], 
			switch:[switch:[value:off, timestamp:2022-04-09T17:55:26.399Z]], 
			custom.washerAutoSoftener:[
				washerAutoSoftener:[value:null]], 
			samsungce.washerFreezePrevent:[
				operatingState:[value:null]], 
			samsungce.washerCycle:[
				supportedCycles:[
					value:[
						[cycle:01, 
						 supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
										   spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
										   waterTemperature:[raw:833E, default:warm, options:[tapCold, cold, warm, hot, extraHot]]]], 
						[cycle:70, 
						 supportedOptions:[soilLevel:[raw:C53E, default:heavy, options:[light, down, normal, up, heavy]],
										   spinLevel:[raw:A53F, default:extraHigh, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
										   waterTemperature:[raw:843E, default:hot, options:[tapCold, cold, warm, hot, extraHot]]]], 
						[cycle:71, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A20F, default:low, options:[rinseHold, noSpin, low, medium]], 
													 waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
						[cycle:55, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:831E, default:warm, options:[tapCold, cold, warm, hot]]]], 
						[cycle:72, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]], 
						[cycle:54, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:8410, default:hot, options:[hot]]]], 
						[cycle:73, supportedOptions:[soilLevel:[raw:C000, options:[]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:8000, options:[]]]], 
						[cycle:74, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], 
													 waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
						[cycle:75, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], 
													 waterTemperature:[raw:810E, default:tapCold, options:[tapCold, cold, warm]]]], 
						[cycle:76, supportedOptions:[soilLevel:[raw:C308, default:normal, options:[normal]], 
													 spinLevel:[raw:A207, default:low, options:[rinseHold, noSpin, low]], 
													 waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
						[cycle:77, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A21F, default:low, options:[rinseHold, noSpin, low, medium, high]], 
													 waterTemperature:[raw:830E, default:warm, options:[tapCold, cold, warm]]]], 
						[cycle:56, supportedOptions:[soilLevel:[raw:C33E, default:normal, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:8106, default:tapCold, options:[tapCold, cold]]]], 
						[cycle:78, supportedOptions:[soilLevel:[raw:C13E, default:light, options:[light, down, normal, up, heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:831E, default:warm, options:[tapCold, cold, warm, hot]]]], 
						[cycle:7A, supportedOptions:[soilLevel:[raw:C520, default:heavy, options:[heavy]], 
													 spinLevel:[raw:A43F, default:high, options:[rinseHold, noSpin, low, medium, high, extraHigh]], 
													 waterTemperature:[raw:8410, default:hot, options:[hot]]]], 
						[cycle:57, supportedOptions:[soilLevel:[raw:C000, options:[]], 
													 spinLevel:[raw:A520, default:extraHigh, options:[extraHigh]], 
													 waterTemperature:[raw:8520, default:extraHot, options:[extraHot]]]]], 
					timestamp:2022-03-28T19:35:58.044Z], 
				washerCycle:[value:Table_00_Course_77, timestamp:2022-04-09T16:57:38.040Z], 
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z]], 
			samsungce.waterConsumptionReport:[
				waterConsumption:[value:null]], 
			ocf:[VARIOUS], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:null], 
				supportedDryerDryLevel:[value:null]], 
			custom.disabledCapabilities:[various],
			custom.washerRinseCycles:[
				supportedWasherRinseCycles:[value:null], 
				washerRinseCycles:[value:null]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:35:56.591Z]], 
			samsungce.kidsLock:[
				lockState:[value:unlocked, timestamp:2022-03-28T19:35:57.523Z]], 
			samsungce.detergentOrder:[
				alarmEnabled:[value:null], 
				orderThreshold:[value:null]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:39800,
						deltaEnergy:0,
						power:0,
						powerEnergy:0.0,
						persistedEnergy:0,
						energySaved:0,
						start:2022-04-09T17:42:42Z,
						end:2022-04-09T17:54:58Z],
					timestamp:2022-04-09T17:54:58.541Z]],
			samsungce.softenerOrder:[
				alarmEnabled:[value:null], 
				orderThreshold:[value:null]], 
			custom.washerSoilLevel:[
				supportedWasherSoilLevel:[value:[none, light, down, normal, up, heavy], timestamp:2022-03-28T19:35:57.777Z], 
				washerSoilLevel:[value:normal, timestamp:2022-03-28T19:35:57.777Z]], 
			samsungce.washerBubbleSoak:[
				status:[value:null]], 
			samsungce.washerCyclePreset:[
				maxNumberOfPresets:[value:10, timestamp:2022-03-28T19:35:59.550Z], 
				presets:[value:null]], 
			samsungce.detergentState:[
				remainingAmount:[value:null], 
				dosage:[value:null], 
				initialAmount:[value:null], 
				detergentType:[value:null]], 
			refresh:[:], 
			custom.jobBeginningStatus:[
				jobBeginningStatus:[value:null]], 
			execute:[
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.mode], 
							if:[oic.if.baseline, oic.if.a], 
							x.com.samsung.da.options:[AddWashIndicator_On]]], 
					data:[href:/course/vs/0], timestamp:2022-04-09T17:55:27.046Z]], 
			samsungce.softenerState:[
				remainingAmount:[
					value:null], 
				dosage:[value:null], 
				softenerType:[value:null], 
				initialAmount:[value:null]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:2022-03-29T19:43:22.494Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:35:57.931Z], 
				supportedCourses:[value:[01, 70, 71, 55, 72, 54, 73, 74, 75, 76, 77, 56, 78, 7A, 57], timestamp:2022-03-28T19:35:57.601Z]], 
			samsungce.washerWashingTime:[
				supportedWashingTimes:[value:null], 
				washingTime:[value:null]], 
			custom.washerAutoDetergent:[
				washerAutoDetergent:[value:null]], 
			custom.washerSpinLevel:[
				washerSpinLevel:[value:low, timestamp:2022-04-09T16:57:37.941Z], 
				supportedWasherSpinLevel:[value:[rinseHold, noSpin, low, medium, high, extraHigh], timestamp:2022-03-28T19:35:57.777Z]]
		]
	]
]]


def simulate() { return true }
def testData() {
	def waterTemp = "hot"
	def completionTime = "2022-05-03T17:56:26Z"
	def machineState = "running"
	def jobState = "spin"
	def onOff = "on"
	def kidsLock = "locked"
	def soilLevel = "low"
	def remoteControlEnabled = "false"
	def spinLevel = "high"
	
	return  [components:[
		main:[
			"custom.washerWaterTemperature":[washerWaterTemperature:[value:waterTemp]], 
			washerOperatingState:[
				completionTime:[value:completionTime], 
				machineState:[value:machineState], 
				washerJobState:[value:jobState]], 
			switch:[switch:[value:onOff]], 
			"samsungce.kidsLock":[lockState:[value:kidsLock]], 
			"custom.washerSoilLevel":[washerSoilLevel:[value:soilLevel]], 
			remoteControlStatus:[remoteControlEnabled:[value:remoteControlEnabled]], 
			"custom.washerSpinLevel":[washerSpinLevel:[value:spinLevel]]
		]]]
}
def refresh() { 
	if (simulate() == true) {
		deviceStatusParse(testData(), "simulation")
	} else {
		commonRefresh()
	}
}




*/














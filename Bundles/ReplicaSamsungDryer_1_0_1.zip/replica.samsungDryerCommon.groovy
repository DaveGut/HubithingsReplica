library (
	name: "samsungDryerCommon",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "Common Methods for replica Samsung Oven parent/children",
	category: "utilities",
	documentationLink: ""
)
//	Version 1.0

//	===== Common Capabilities, Commands, and Attributes =====
capability "Refresh"
attribute "remoteControlEnabled", "boolean"
attribute "switch", "string"
attribute "completionTime", "string"
attribute "machineState", "string"
attribute "dryerJobState", "string"
command "start"
command "pause"
command "stop"
attribute "timeRemaining", "string"

String helpLogo() {
	return """<a href="https://github.com/DaveGut/HubithingsReplica/blob/main/Docs/SamsungDryerReadme.md">""" +
		"""<div style="position: absolute; top: 20px; right: 150px; height: 80px; font-size: 28px;">Dryer Help</div></a>"""
}

//	===== Device Commands =====
def start() { setMachineState("run") }
def pause() { setMachineState("pause") }
def stop() { setMachineState("stop") }
def setMachineState(machState) {
	def oldState = device.currentValue("machineState")
	Map cmdStatus = [oldState: oldState, newState: machState]
	if (oldState != machState) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), "dryerOperatingState", 
									"setMachineState", [machState])
	} else {
		cmdStatus << [FAILED: "no change in state"]
		runIn(10, checkAttribute, [data: ["setMachineState", "machineState", machState]])
	}
	logInfo("setMachineState: ${cmdStatus}")
}

def checkAttribute(setCommand, attrName, attrValue) {
	def checkValue = device.currentValue(attrName).toString()
	if (checkValue != attrValue.toString()) {
		Map warnTxt = [command: setCommand,
					   attribute: attrName,
					   checkValue: checkValue,
					   attrValue: attrValue,
					   failed: "Function may be disabled by SmartThings"]
		logWarn("checkAttribute: ${warnTxt}")
	}
}

def parseEvent(event) {
	logDebug("parseEvent: <b>${event}</b>")
	if (state.deviceCapabilities.contains(event.capability)) {
		logTrace("parseEvent: <b>${event}</b>")
		if (event.value != null) {
			switch(event.attribute) {
				case "completionTime":
					setEvent(event)
					def timeRemaining = calcTimeRemaining(event.value)
					setEvent([attribute: "timeRemaining", value: timeRemaining, unit: null])
					break
				case "supportedMachineStates":
				case "supportedDryerDryLevel":
				case "operatingState":
				case "supportedDryingTime":
					break				
				default:
					setEvent(event)
					break
			}
		}
	}
}

def setEvent(event) {
	logTrace("<b>setEvent</b>: ${event}")
	sendEvent(name: event.attribute, value: event.value, unit: event.unit)
	if (device.currentValue(event.attribute).toString() != event.value.toString()) {
		logInfo("setEvent: [event: ${event}]")
	}
}

def calcTimeRemaining(completionTime) {
	Integer currTime = now()
	Integer compTime
	try {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	} catch (e) {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	}
	Integer timeRemaining = ((compTime-currTime) /1000).toInteger()
	def hhmmss
	if (timeRemaining < 0) {
		hhmmss = "00:00:00"
    } else {
		hhmmss = new GregorianCalendar( 0, 0, 0, 0, 0, timeRemaining, 0 ).time.format( 'HH:mm:ss' )
	}
	return hhmmss
}

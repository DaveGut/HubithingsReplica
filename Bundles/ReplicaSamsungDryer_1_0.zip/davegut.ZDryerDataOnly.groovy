metadata {
	definition (name: "Z Dryer Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}


Map description = [
	name:"[dryer] Samsung", 
	label:"Dryer", 
	deviceId:"3047d02b-c0aa-48be-ae09-9d0f6afee091",
	deviceTypeName:"Samsung OCF Dryer", 
	components:[
		[id:"main", label:"main",
		 capabilities:[
			 [id:"ocf", version:1],
			 [id:"execute", version:1], 
			 [id:"refresh", version:1], 
			 [id:"switch", version:1], 
			 [id:"remoteControlStatus", version:1], 
			 [id:"dryerOperatingState", version:1], 
			 [id:"powerConsumptionReport", version:1], 
			 [id:"custom.disabledCapabilities", version:1], 
			 [id:"custom.dryerDryLevel", version:1], 
			 [id:"custom.dryerWrinklePrevent", version:1], 
			 [id:"custom.jobBeginningStatus", version:1], 
			 [id:"custom.supportedOptions", version:1], 
			 [id:"samsungce.detergentOrder", version:1], 
			 [id:"samsungce.detergentState", version:1], 
			 [id:"samsungce.deviceIdentification", version:1], 
			 [id:"samsungce.driverVersion", version:1], 
			 [id:"samsungce.dryerAutoCycleLink", version:1], 
			 [id:"samsungce.dryerCycle", version:1], 
			 [id:"samsungce.dryerCyclePreset", version:1], 
			 [id:"samsungce.dryerDelayEnd", version:1], 
			 [id:"samsungce.dryerDryingTemperature", version:1], 
			 [id:"samsungce.dryerDryingTime", version:1], 
			 [id:"samsungce.dryerFreezePrevent", version:1], 
			 [id:"samsungce.kidsLock", version:1], 
			 [id:"samsungce.welcomeMessage", version:1]],
		 categories:[[name:"Dryer", categoryType:"manufacturer"]]]], 
	createTime:"2022-03-28T19:39:24.986Z", 
	profile:[id:"c89de99f-2730-3a8f-882f-49a2c488be46"], 
	type:"OCF", restrictionTier:0, allowed:[]
]

Map status = [
	components:[
		main:[
			"custom.dryerWrinklePrevent":[
				operatingState:[value:null], 
				dryerWrinklePrevent:[value:"off"]], 
			"samsungce.dryerDryingTemperature":[
				dryingTemperature:[value:"medium"],
				supportedDryingTemperature:[value:["none", "extraLow", "low", "mediumLow", "medium", "high"]]], 
			"samsungce.dryerCyclePreset":[
				maxNumberOfPresets:[value:10], 
				presets:[value:null]], 
			"samsungce.deviceIdentification":[:], 
			switch:[
				switch:[value:"off"]], 
			"samsungce.dryerFreezePrevent":[
				operatingState:[value:null]], 
			ocf:[:], 
			"custom.dryerDryLevel":[
				dryerDryLevel:[value:"normal",], 
				supportedDryerDryLevel:[value:["none", "damp", "less", "normal", "more", "very"]]], 
			"samsungce.dryerAutoCycleLink":[
				dryerAutoCycleLink:[value:null]], 
			"samsungce.dryerCycle":[
				dryerCycle:[value:"Table_00_Course_01"],
				supportedCycles:[:], 
				referenceTable:[:]], 
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:[
					"samsungce.dryerCyclePreset", "samsungce.detergentOrder", "samsungce.detergentState", 
					"samsungce.dryerFreezePrevent", "samsungce.welcomeMessage"]]], 
			"samsungce.driverVersion":[
				versionNumber:[value:"21082401"]], 
			"samsungce.kidsLock":[
				lockState:[value:unlocked]], 
			powerConsumptionReport:[
				powerConsumption:[value:[energy:626400, deltaEnergy:200, power:0, powerEnergy:0.0, persistedEnergy:0, 
										 energySaved:0, start:"2022-04-09T19:52:23Z", end:"2022-04-09T19:57:57Z"]]], 
			dryerOperatingState:[
				completionTime:[value:"2022-04-09T21:17:05Z"], 
				machineState:[value:"stop"], 
				supportedMachineStates:[value:null], dryerJobState:[value:none]], 
			"samsungce.dryerDelayEnd":[
				remainingTime:[value:null]], 
			refresh:[:], 
			"custom.jobBeginningStatus":[
				jobBeginningStatus:[value:null]], 
			execute:[], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false]], 
			"custom.supportedOptions":[
				referenceTable:[value:[id:"Table_00"]], 
				supportedCourses:[value:["01", "81"]]], 
			"samsungce.dryerDryingTime":[
				supportedDryingTime:[value:[0, 20, 30, 40, 50, 60]], 
				dryingTime:[value:0, unit:"min"]]
			]
	]
]
	
def designCapabilities() {
	return ["refresh", "remoteControlStatus", "samsungce.kidsLock", 
			"switch", "dryerOperatingState",  "custom.dryerDryLevel", 
			"custom.dryerWrinklePrevent", "custom.jobBeginningStatus", 
			"samsungce.dryerDryingTime"
			]
}



/*
//	API Definitions
def dryerOperatingState = [
	id:dryerOperatingState, version:1, status:proposed, name:Dryer Operating State, ephemeral:false, 
	attributes:[
		completionTime:[schema:[
			type:object, 
			properties:[value:[
				title:Iso8601Date, type:string, 
				pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$]], 
			additionalProperties:false, required:[value]], enumCommands:[]], 
		machineState:[schema:[
			type:object, properties:[value:[
				title:MachineState, type:string, enum:[pause, run, stop]]], 
			additionalProperties:false, required:[value]], setter:setMachineState, enumCommands:[]], 
		supportedMachineStates:[
			schema:[type:object, properties:[value:[type:array, items:[title:MachineState, type:string, enum:[pause, run, stop]]]], 
					additionalProperties:false, required:[value]], enumCommands:[]], 
		dryerJobState:[
			schema:[type:object, 
					properties:[value:[title:DryerJobState, type:string, enum:[
						cooling, delayWash, drying, finished, none, refreshing, weightSensing, wrinklePrevent, 
						dehumidifying, aIDrying, sanitizing, internalCare, freezeProtection, continuousDehumidifying, thawingFrozenInside]]], 
					additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setMachineState:[name:setMachineState, arguments:[
			[name:state, optional:false, schema:[
				title:MachineState, type:string, enum:[pause, run, stop]]]]]]]

def custom_dryerDryLevel = [
	id:custom.dryerDryLevel, version:1, status:proposed, name:Dryer Dry Level, ephemeral:false, 
	attributes:[
		dryerDryLevel:[
			schema:[
				title:dryerDryLevel, type:object, 
				properties:[value:[enum:[
					none, damp, less, normal, more, very, 0, 1, 2, 3, 4, 5, cupboard, extra, shirt, 
					delicate, 30, 60, 90, 120, 150, 180, 210, 240, 270], type:string]],
				additionalProperties:false, required:[value]], setter:setDryerDryLevel, enumCommands:[]], 
		supportedDryerDryLevel:[
			schema:[
				title:supportedDryerDryLevel, type:object,
				properties:[value:[type:array, items:[enum:[
					none, damp, less, normal, more, very, 0, 1, 2, 3, 4, 5, cupboard, extra, shirt, 
					delicate, 30, 60, 90, 120, 150, 180, 210, 240, 270], type:string]]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setDryerDryLevel:[
			name:setDryerDryLevel, 
			arguments:[[name:dryLevel, optional:false, schema:[enum:[
				none, damp, less, normal, more, very, 0, 1, 2, 3, 4, 5, cupboard, extra, 
				shirt, delicate, 30, 60, 90, 120, 150, 180, 210, 240, 270], type:string]]]]]]

def custom_dryerWrinklePrevent = [
	id:custom.dryerWrinklePrevent, version:1, status:proposed, name:Dryer Wrinkle Prevent, ephemeral:false, 
	attributes:[
		operatingState:[schema:[type:object, properties:[value:[type:string, enum:[ready, running]]], 
								additionalProperties:false, required:[value]], enumCommands:[]], 
		dryerWrinklePrevent:[schema:[title:WrinklePrevent, type:object, 
									 properties:[value:[type:string, enum:[on, off]]], 
									 additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setDryerWrinklePrevent:[
			name:setDryerWrinklePrevent, arguments:[
				[name:WrinklePrevent, optional:false, schema:[type:string, enum:[on, off]]]]]]]

def custom_jobBeginningStatus = [
	id:custom.jobBeginningStatus, version:1, status:proposed, name:Job Beginning Status, ephemeral:false, 
	attributes:[
		jobBeginningStatus:[schema:[type:object, properties:[value:[type:string, enum:[None, ReadyToRun]]], 
									additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]

//	Not Implemented!
def samsungce_dryerDelayEnd = [
	id:samsungce.dryerDelayEnd, version:1, status:proposed, name:Dryer Delay End, ephemeral:false, 
	attributes:[
		remainingTime:[schema:[type:object, properties:[value:[type:integer, minimum:0, maximum:1440], unit:[type:string, enum:[min], default:min]], 
							   additionalProperties:false, required:[value, unit]], enumCommands:[]]], 
	commands:[
		setDelayTime:[name:setDelayTime, arguments:[
			[name:delayTime, optional:false, schema:[type:integer, minimum:0, maximum:1440]]]]]]

//	Not Implemented
def samsungce_dryerDryingTime = [
	id:samsungce.dryerDryingTime, version:1, status:proposed, name:Dryer Drying Time, ephemeral:false, 
	attributes:[
		supportedDryingTime:[
			schema:[type:object, properties:[value:[type:array, items:[type:string]]], 
					additionalProperties:false, required:[value]], enumCommands:[]], 
		dryingTime:[
			schema:[type:object, properties:[value:[type:string], 
											 unit:[type:string, enum:[min], default:min]], 
					additionalProperties:false, required:[value]], setter:setDryingTime, enumCommands:[]]], 
	commands:[
		setDryingTime:[name:setDryingTime, arguments:[[name:dryingTime, optional:false, schema:[type:string]]]]]]




//DRYERS with top loads

deviceStatus: [components:[sub:[ocf:[st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], di:[value:null], mnsl:[value:null], dmv:[value:null], n:[value:null], mnmo:[value:null], vid:[value:null], mnmn:[value:null], mnml:[value:null], mnpv:[value:null], mnos:[value:null], pi:[value:null], icv:[value:null]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T14:20:22.670Z]], dryerOperatingState:[completionTime:[value:2022-08-21T21:20:47Z, timestamp:2022-08-21T20:30:47.239Z], machineState:[value:stop, timestamp:2022-08-21T14:20:22.593Z], supportedMachineStates:[value:null], dryerJobState:[value:none, timestamp:2022-08-21T14:20:22.593Z]], samsungce.driverVersion:[versionNumber:[value:null]], refresh:[:], switch:[switch:[value:null]]], main:[ocf:[st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], di:[value:5C86C115-47FF-0000-0000-000000000000, timestamp:2022-08-21T14:20:18.524Z], mnsl:[value:null], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-08-21T14:20:18.524Z], n:[value:Samsung Dryer, timestamp:2022-08-21T14:50:33.598Z], mnmo:[value:TP6X_DM9900M/DC92-01972A_0005|20197241|30000101001111000203000000000000, timestamp:2022-08-21T14:20:18.524Z], vid:[value:DA-WM-WD-100002, timestamp:2022-08-21T14:20:18.524Z], mnmn:[value:Samsung Electronics, timestamp:2022-08-21T14:20:18.524Z], mnml:[value:null], mnpv:[value:null], mnos:[value:null], pi:[value:shp, timestamp:2022-08-21T14:20:22.811Z], icv:[value:core.1.1.0, timestamp:2022-08-21T14:20:18.524Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T14:20:22.632Z]], dryerOperatingState:[completionTime:[value:2022-08-21T21:45:20Z, timestamp:2022-08-21T21:07:20.950Z], machineState:[value:run, timestamp:2022-08-21T20:53:12.258Z], supportedMachineStates:[value:null], dryerJobState:[value:drying, timestamp:2022-08-21T20:30:18.354Z]], samsungce.driverVersion:[versionNumber:[value:21040501, timestamp:2022-08-21T14:20:22.524Z]], refresh:[:], switch:[switch:[value:null]]]]]


deviceStatus: [
	components:[
		sub:[
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], di:[value:null], 
				mnsl:[value:null], dmv:[value:null], n:[value:null], mnmo:[value:null], vid:[value:null], 
				mnmn:[value:null], mnml:[value:null], mnpv:[value:null], mnos:[value:null], pi:[value:null], 
				icv:[value:null]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T14:20:22.670Z]], 
			dryerOperatingState:[
				completionTime:[value:2022-08-21T21:20:47Z, timestamp:2022-08-21T20:30:47.239Z], 
				machineState:[value:stop, timestamp:2022-08-21T14:20:22.593Z], 
				supportedMachineStates:[value:null], 
				dryerJobState:[value:none, timestamp:2022-08-21T14:20:22.593Z]], 
			samsungce.driverVersion:[versionNumber:[value:null]], 
			refresh:[:], 
			switch:[switch:[value:null]]], 
		main:[
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], 
				di:[value:5C86C115-47FF-0000-0000-000000000000, timestamp:2022-08-21T14:20:18.524Z], 
				mnsl:[value:null], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-08-21T14:20:18.524Z], 
				n:[value:Samsung Dryer, timestamp:2022-08-21T14:50:33.598Z], 
				mnmo:[value:TP6X_DM9900M/DC92-01972A_0005|20197241|30000101001111000203000000000000, 
					  timestamp:2022-08-21T14:20:18.524Z], 
				vid:[value:DA-WM-WD-100002, timestamp:2022-08-21T14:20:18.524Z], 
				mnmn:[value:Samsung Electronics, timestamp:2022-08-21T14:20:18.524Z], 
				mnml:[value:null], mnpv:[value:null], mnos:[value:null], 
				pi:[value:shp, timestamp:2022-08-21T14:20:22.811Z], 
				icv:[value:core.1.1.0, timestamp:2022-08-21T14:20:18.524Z]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-08-21T14:20:22.632Z]], 
			dryerOperatingState:[
				completionTime:[value:2022-08-21T21:45:20Z, timestamp:2022-08-21T21:07:20.950Z], 
				machineState:[value:run, timestamp:2022-08-21T20:53:12.258Z], 
				supportedMachineStates:[value:null], 
				dryerJobState:[value:drying, timestamp:2022-08-21T20:30:18.354Z]], 
			samsungce.driverVersion:[versionNumber:[value:21040501, timestamp:2022-08-21T14:20:22.524Z]], 
			refresh:[:], 
			switch:[switch:[value:null]]]]]






//	data from partners
data:[
	components:[
		main:[
			custom.dryerWrinklePrevent:[
				operatingState:[value:null], dryerWrinklePrevent:[value:off, timestamp:2022-03-28T19:41:13.634Z]], 
			samsungce.dryerDryingTemperature:[
				dryingTemperature:[value:medium, timestamp:2022-04-09T20:02:05.594Z],
				supportedDryingTemperature:[value:[none, extraLow, low, mediumLow, medium, high], 
											timestamp:2022-03-28T19:41:13.634Z]], 
			samsungce.welcomeMessage:[welcomeMessage:[value:null]], 
			samsungce.dryerCyclePreset:[
				maxNumberOfPresets:[value:10, timestamp:2022-04-03T16:00:38.127Z], 
				presets:[value:null]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:41:13.603Z],
				modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], 
				modelClassificationCode:[value:30000001001031000100000000000000, timestamp:2022-03-28T19:41:13.603Z], 
				description:[value:DA_WM_A51_20_COMMON_DV45K6500Ex0, timestamp:2022-04-03T15:53:57.781Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-04-03T15:53:57.781Z]], 
			switch:[switch:[value:off, timestamp:2022-04-09T20:02:05.188Z]], 
			samsungce.dryerFreezePrevent:[operatingState:[value:null]], 
			ocf:[st:[value:null], mndt:[value:null], 
				 mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2022-04-03T16:00:36.424Z], 
				 mnhw:[value:ARTIK051, timestamp:2022-04-03T15:53:56.204Z], 
				 di:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], 
				 mnsl:[value:null], dmv:[value:1.2.1, timestamp:2022-03-28T19:41:15.224Z], 
				 n:[value:[dryer] Samsung, timestamp:2022-03-28T19:41:15.224Z], 
				 mnmo:[value:DA_WM_A51_20_COMMON|20185441|30000001001031000100000000000000, timestamp:2022-04-03T15:53:56.204Z], 
				 vid:[value:DA-WM-WD-000001, timestamp:2022-03-28T19:39:25.368Z], 
				 mnmn:[value:Samsung Electronics, timestamp:2022-03-28T19:39:25.368Z], 
				 mnml:[value:http:www.samsung.com, timestamp:2022-03-28T19:39:25.368Z], 
				 mnpv:[value:DAWIT 2.0, timestamp:2022-04-03T15:53:56.204Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-04-03T15:53:56.204Z], 
				 pi:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], 
				 icv:[value:core.1.1.0, timestamp:2022-03-28T19:39:25.368Z]], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:normal, timestamp:2022-04-09T20:02:05.744Z], 
				supportedDryerDryLevel:[value:[none, damp, less, normal, more, very], timestamp:2022-03-28T19:41:13.634Z]], 
			samsungce.dryerAutoCycleLink:[dryerAutoCycleLink:[value:null]], 
			samsungce.dryerCycle:[
				dryerCycle:[value:Table_00_Course_01, timestamp:2022-04-09T20:02:05.165Z],
				supportedCycles:[value:[[cycle:01, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
										[cycle:70, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:71, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:77, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
										[cycle:76, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], 
																	 dryingTemperature:[raw:8204, default:low, options:[low]]]], 
										[cycle:75, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]], 
										[cycle:74, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], 
																	 dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
										[cycle:6F, supportedOptions:[dryingLevel:[raw:D520, default:very, options:[very]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:7C, supportedOptions:[dryingLevel:[raw:D000, options:[]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:7D, supportedOptions:[dryingLevel:[raw:D000, options:[]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:7E, supportedOptions:[dryingLevel:[raw:D000, options:[]], 
																	 dryingTemperature:[raw:8000, options:[]]]], 
										[cycle:7F, supportedOptions:[dryingLevel:[raw:D000, options:[]], 
																	 dryingTemperature:[raw:853E, default:high, 
																						options:[extraLow, low, mediumLow, medium, high]]]],
										[cycle:80, supportedOptions:[dryingLevel:[raw:D000, options:[]], 
																	 dryingTemperature:[raw:8520, default:high, options:[high]]]], 
										[cycle:81, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], 
																	 dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]]], 
								 timestamp:2022-03-28T19:41:15.122Z], 
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[samsungce.dryerCyclePreset, samsungce.detergentOrder, samsungce.detergentState, 
																	  samsungce.dryerFreezePrevent, samsungce.welcomeMessage],timestamp:2022-04-03T15:53:59.721Z]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:39:25.388Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:41:15.099Z]], 
			samsungce.detergentOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], 
			powerConsumptionReport:[
				powerConsumption:[value:[energy:626400, deltaEnergy:200, power:0, powerEnergy:0.0, persistedEnergy:0, 
										 energySaved:0, start:2022-04-09T19:52:23Z, end:2022-04-09T19:57:57Z], timestamp:2022-04-09T19:57:57.648Z]], 
			dryerOperatingState:[
				completionTime:[value:2022-04-09T21:17:05Z, timestamp:2022-04-09T20:02:05.880Z], 
				machineState:[value:stop, timestamp:2022-04-09T20:02:05.267Z], 
				supportedMachineStates:[value:null], dryerJobState:[value:none, timestamp:2022-04-09T20:02:05.458Z]], 
			samsungce.detergentState:[remainingAmount:[value:null], dosage:[value:null], initialAmount:[value:null], detergentType:[value:null]], samsungce.dryerDelayEnd:[remainingTime:[value:null]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.operation], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.state:Ready, x.com.samsung.da.remainingTime:01:15:00, x.com.samsung.da.progressPercentage:1, x.com.samsung.da.progress:None, x.com.samsung.da.supportedProgress:[None, Drying, Cooling, Finish]]], data:[href:/operational/state/vs/0], timestamp:2022-04-09T20:02:05.880Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-29T19:45:26.777Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z], supportedCourses:[value:[01, 70, 71, 77, 76, 75, 74, 6F, 7C, 7D, 7E, 7F, 80, 81], timestamp:2022-03-28T19:41:15.122Z]], samsungce.dryerDryingTime:[supportedDryingTime:[value:[0, 20, 30, 40, 50, 60], timestamp:2022-03-28T19:41:13.634Z], dryingTime:[value:0, unit:min, timestamp:2022-04-09T20:02:05.740Z]]]]]


[
	deviceId:c98c12e1-b822-e22f-c98c-b14ff889c897, name:[dryer] Samsung, 
	label:Dryer, manufacturerName:Samsung Electronics, presentationId:DA-WM-WD-000001, deviceManufacturerCode:Samsung Electronics, 
	locationId:82d54519-bc1c-4a99-8873-afb8ab285945, ownerId:0ecc7231-5889-d670-f73b-1004eccfce01, roomId:26d8970a-ca71-4abc-9c1a-a5bacbf3c7ba, 
	deviceTypeName:Samsung OCF Dryer, 
	components:[[id:main, label:main, capabilities:[
		[id:ocf, version:1], 
		[id:execute, version:1], 
		[id:refresh, version:1], 
		[id:switch, version:1], 
		[id:remoteControlStatus, version:1], 
		[id:dryerOperatingState, version:1], 
		[id:powerConsumptionReport, version:1], 
		[id:custom.disabledCapabilities, version:1], 
		[id:custom.dryerDryLevel, version:1], 
		[id:custom.dryerWrinklePrevent, version:1], 
		[id:custom.jobBeginningStatus, version:1], 
		[id:custom.supportedOptions, version:1], 
		[id:samsungce.detergentOrder, version:1], 
		[id:samsungce.detergentState, version:1], 
		[id:samsungce.deviceIdentification, version:1], 
		[id:samsungce.driverVersion, version:1], 
		[id:samsungce.dryerAutoCycleLink, version:1], 

		[id:samsungce.dryerCycle, version:1], 
		[id:samsungce.dryerCyclePreset, version:1], 
		[id:samsungce.dryerDelayEnd, version:1], 
		[id:samsungce.dryerDryingTemperature, version:1], 
		[id:samsungce.dryerDryingTime, version:1], 
		[id:samsungce.dryerFreezePrevent, version:1], 
		
		[id:samsungce.kidsLock, version:1], 
		[id:samsungce.welcomeMessage, version:1]], 
				 categories:[
					 [name:Dryer, categoryType:manufacturer]]]], 
	createTime:2022-03-28T19:39:24.986Z, profile:[id:c89de99f-2730-3a8f-882f-49a2c488be46], 
	ocf:[ocfDeviceType:oic.d.dryer, name:[dryer] Samsung, specVersion:core.1.1.0, verticalDomainSpecVersion:1.2.1, 
		 manufacturerName:Samsung Electronics, modelNumber:DA_WM_A51_20_COMMON|20185441|30000001001031000100000000000000, platformVersion:DAWIT 2.0, 
		 platformOS:TizenRT 1.0 + IPv6, hwVersion:ARTIK051, firmwareVersion:DA_WM_A51_20_COMMON_30210227, vendorId:DA-WM-WD-000001, 
		 vendorResourceClientServerVersion:ARTIK051 Release 2.210219.1, lastSignupTime:2022-03-28T19:39:21.773935Z], 
	type:OCF, restrictionTier:0, allowed:[]]]

dev:2382022-05-02 06:46:46.247 pm trace[devStatus: [components:[main:[
	custom.dryerWrinklePrevent:[operatingState:[value:null], dryerWrinklePrevent:[value:off, timestamp:2022-03-28T19:41:13.634Z]], samsungce.dryerDryingTemperature:[dryingTemperature:[value:high, timestamp:2022-05-02T22:43:08.435Z], supportedDryingTemperature:[value:[none, extraLow, low, mediumLow, medium, high], timestamp:2022-03-28T19:41:13.634Z]], samsungce.welcomeMessage:[welcomeMessage:[value:null]], samsungce.dryerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2022-04-03T16:00:38.127Z], presets:[value:null]], samsungce.deviceIdentification:[micomAssayCode:[value:20185441, timestamp:2022-03-28T19:41:13.603Z], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], modelClassificationCode:[value:30000001001031000100000000000000, timestamp:2022-03-28T19:41:13.603Z], description:[value:DA_WM_A51_20_COMMON_DV45K6500Ex0, timestamp:2022-04-03T15:53:57.781Z], binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-04-03T15:53:57.781Z]], switch:[switch:[value:on, timestamp:2022-05-02T22:43:08.369Z]], samsungce.dryerFreezePrevent:[operatingState:[value:null]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2022-04-03T16:00:36.424Z], mnhw:[value:ARTIK051, timestamp:2022-04-03T15:53:56.204Z], di:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], mnsl:[value:null], dmv:[value:1.2.1, timestamp:2022-03-28T19:41:15.224Z], n:[value:[dryer] Samsung, timestamp:2022-03-28T19:41:15.224Z], mnmo:[value:DA_WM_A51_20_COMMON|20185441|30000001001031000100000000000000, timestamp:2022-04-03T15:53:56.204Z], vid:[value:DA-WM-WD-000001, timestamp:2022-03-28T19:39:25.368Z], mnmn:[value:Samsung Electronics, timestamp:2022-03-28T19:39:25.368Z], mnml:[value:http://www.samsung.com, timestamp:2022-03-28T19:39:25.368Z], mnpv:[value:DAWIT 2.0, timestamp:2022-04-03T15:53:56.204Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-04-03T15:53:56.204Z], pi:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], icv:[value:core.1.1.0, timestamp:2022-03-28T19:39:25.368Z]], custom.dryerDryLevel:[dryerDryLevel:[value:none, timestamp:2022-05-02T22:43:08.435Z], supportedDryerDryLevel:[value:[none, damp, less, normal, more, very], timestamp:2022-03-28T19:41:13.634Z]], samsungce.dryerAutoCycleLink:[dryerAutoCycleLink:[value:null]], samsungce.dryerCycle:[dryerCycle:[value:Table_00_Course_80, timestamp:2022-05-02T22:43:08.705Z], supportedCycles:[value:[[cycle:01, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:70, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:71, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:77, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:76, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8204, default:low, options:[low]]]], [cycle:75, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]], [cycle:74, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:6F, supportedOptions:[dryingLevel:[raw:D520, default:very, options:[very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7C, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7D, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7E, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8000, options:[]]]], [cycle:7F, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:853E, default:high, options:[extraLow, low, mediumLow, medium, high]]]], [cycle:80, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:81, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]]], timestamp:2022-03-28T19:41:15.122Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z]], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.dryerCyclePreset, samsungce.detergentOrder, samsungce.detergentState, samsungce.dryerFreezePrevent, samsungce.welcomeMessage], timestamp:2022-04-03T15:53:59.721Z]], samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:39:25.388Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:41:15.099Z]], samsungce.detergentOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], powerConsumptionReport:[powerConsumption:[value:[energy:659800, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, start:2022-05-01T17:02:55Z, end:2022-05-02T22:43:07Z], timestamp:2022-05-02T22:43:07.614Z]], dryerOperatingState:[completionTime:[value:2022-05-02T23:13:08Z, timestamp:2022-05-02T22:43:08.417Z], machineState:[value:stop, timestamp:2022-05-01T17:02:21.313Z], supportedMachineStates:[value:null], dryerJobState:[value:none, timestamp:2022-05-01T17:02:21.516Z]], samsungce.detergentState:[remainingAmount:[value:null], dosage:[value:null], initialAmount:[value:null], detergentType:[value:null]], samsungce.dryerDelayEnd:[remainingTime:[value:null]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.configuration], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.region:0000000000, x.com.samsung.da.countryCode:US]], data:[href:/configuration/vs/0], timestamp:2022-05-02T22:43:23.145Z]], remoteControlStatus:[remoteControlEnabled:[value:true, timestamp:2022-05-02T22:43:23.010Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z], supportedCourses:[value:[01, 70, 71, 77, 76, 75, 74, 6F, 7C, 7D, 7E, 7F, 80, 81], timestamp:2022-03-28T19:41:15.122Z]], samsungce.dryerDryingTime:[supportedDryingTime:[value:[0, 20, 30, 40, 50, 60], timestamp:2022-03-28T19:41:13.634Z], dryingTime:[value:30, unit:min, timestamp:2022-05-02T22:43:08.435Z]]]]]]





def dryer: [
	components:[
		main:[
			refresh:[:], 
			switch:[switch:[value:off, timestamp:2022-04-09T20:02:05.188Z]], 
			samsungce.kidsLock:[
				lockState:[value:unlocked, timestamp:2022-03-28T19:41:15.099Z]], 
			dryerOperatingState:[
				completionTime:[value:2022-04-09T21:17:05Z, timestamp:2022-04-09T20:02:05.880Z], 
				machineState:[value:stop, timestamp:2022-04-09T20:02:05.267Z], 
				supportedMachineStates:[value:null], 
				dryerJobState:[value:none, timestamp:2022-04-09T20:02:05.458Z]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:2022-03-29T19:45:26.777Z]], 
			
			samsungce.dryerDryingTemperature:[
				dryingTemperature:[value:medium, timestamp:2022-04-09T20:02:05.594Z], 
				supportedDryingTemperature:[value:[none, extraLow, low, mediumLow, medium, high], timestamp:2022-03-28T19:41:13.634Z]], 
			custom.dryerWrinklePrevent:[
				operatingState:[value:null], 
				dryerWrinklePrevent:[value:off, timestamp:2022-03-28T19:41:13.634Z]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:626400, 
						deltaEnergy:200, 
						power:0, 
						powerEnergy:0.0, 
						persistedEnergy:0, 
						energySaved:0, 
						start:2022-04-09T19:52:23Z, 
						end:2022-04-09T19:57:57Z], 
					timestamp:2022-04-09T19:57:57.648Z]], 

			samsungce.welcomeMessage:[DISABLED], 
			samsungce.dryerCyclePreset:[DISABLED], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:20185441, timestamp:2022-03-28T19:41:13.603Z], 
				modelName:[value:null], serialNumber:[value:null], 
				serialNumberExtra:[value:null],
				modelClassificationCode:[value:30000001001031000100000000000000, timestamp:2022-03-28T19:41:13.603Z], 
				description:[value:DA_WM_A51_20_COMMON_DV45K6500Ex0, timestamp:2022-04-03T15:53:57.781Z], 
				binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-04-03T15:53:57.781Z]], 
			samsungce.dryerFreezePrevent:[DISABLED], 
			ocf:[VARIOUS], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:normal, timestamp:2022-04-09T20:02:05.744Z], 
				supportedDryerDryLevel:[value:[none, damp, less, normal, more, very], timestamp:2022-03-28T19:41:13.634Z]], 
			samsungce.dryerAutoCycleLink:[
				dryerAutoCycleLink:[value:null]], 
			samsungce.dryerCycle:[
				dryerCycle:[value:Table_00_Course_01, timestamp:2022-04-09T20:02:05.165Z], 
				supportedCycles:[
					value:[
						[cycle:01, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
						[cycle:70, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:71, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:77, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
						[cycle:76, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8204, default:low, options:[low]]]], 
						[cycle:75, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]], 
						[cycle:74, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], 
						[cycle:6F, supportedOptions:[dryingLevel:[raw:D520, default:very, options:[very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:7C, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:7D, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:7E, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8000, options:[]]]], 
						[cycle:7F, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:853E, default:high, options:[extraLow, low, mediumLow, medium, high]]]], 
						[cycle:80, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], 
						[cycle:81, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]]], 
					timestamp:2022-03-28T19:41:15.122Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[
					value:[samsungce.dryerCyclePreset, samsungce.detergentOrder, samsungce.detergentState, 
						   samsungce.dryerFreezePrevent, samsungce.welcomeMessage], timestamp:2022-04-03T15:53:59.721Z]], 
			samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:39:25.388Z]], 
			samsungce.detergentOrder:[DISABLED], 
			samsungce.detergentState:[DISABLED], 
			samsungce.dryerDelayEnd:[
				remainingTime:[value:null]], 
			custom.jobBeginningStatus:[
				jobBeginningStatus:[value:null]], 
			execute:[
				data:[
					value:[
						payload:[rt:[x.com.samsung.da.operation], 
								 if:[oic.if.baseline, oic.if.a], 
								 x.com.samsung.da.state:Ready, 
								 x.com.samsung.da.remainingTime:01:15:00, 
								 x.com.samsung.da.progressPercentage:1, 
								 x.com.samsung.da.progress:None, 
								 x.com.samsung.da.supportedProgress:[None, Drying, Cooling, Finish]]], 
					data:[href:/operational/state/vs/0], 
					timestamp:2022-04-09T20:02:05.880Z]], 
			custom.supportedOptions:[
				referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z], 
				supportedCourses:[value:[01, 70, 71, 77, 76, 75, 74, 6F, 7C, 7D, 7E, 7F, 80, 81], timestamp:2022-03-28T19:41:15.122Z]], 
			samsungce.dryerDryingTime:[
				supportedDryingTime:[value:[0, 20, 30, 40, 50, 60], timestamp:2022-03-28T19:41:13.634Z],
				dryingTime:[value:0, unit:min, timestamp:2022-04-09T20:02:05.740Z]]
		]
	]
]

def dryerAttrs: [
	components:[
		main:[
			custom.dryerWrinklePrevent:[
				dryerWrinklePrevent:[value:off]], 
			samsungce.dryerDryingTemperature:[
				dryingTemperature:[value:medium]], 
			switch:[
				switch:[value:off,]], 
			custom.dryerDryLevel:[
				dryerDryLevel:[value:normal, timestamp:2022-04-09T20:02:05.744Z]], 
			samsungce.kidsLock:[
				lockState:[value:unlocked]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:626400, 
						power:0.0]]]
			samsungce.dryerDelayEnd:[
				remainingTime:[value:null]], 
			dryerOperatingState:[
				completionTime:[value:2022-04-09T21:17:05Z], 
				machineState:[value:stop], 
				dryerJobState:[value:none]], 
			custom.jobBeginningStatus:[
				jobBeginningStatus:[value:null]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false]], 
			samsungce.dryerDryingTime:[
				dryingTime:[value:0, unit:min, timestamp:2022-04-09T20:02:05.740Z]]
		]
	]
]]	 

Dryer: [stLabel:Dryer, deviceId:c98c12e1-b822-e22f-c98c-b14ff889c897, deviceName:[dryer] Samsung, main:[ocf, execute, refresh, switch, remoteControlStatus, dryerOperatingState, powerConsumptionReport, custom.disabledCapabilities, custom.dryerDryLevel, custom.dryerWrinklePrevent, custom.jobBeginningStatus, custom.supportedOptions, samsungce.detergentOrder, samsungce.detergentState, samsungce.deviceIdentification, samsungce.driverVersion, samsungce.dryerAutoCycleLink, samsungce.dryerCycle, samsungce.dryerCyclePreset, samsungce.dryerDelayEnd, samsungce.dryerDryingTemperature, samsungce.dryerDryingTime, samsungce.dryerFreezePrevent, samsungce.kidsLock, samsungce.welcomeMessage]]

data:[components:[
	main:[
		custom.dryerWrinklePrevent:[operatingState:[value:null], dryerWrinklePrevent:[value:off, timestamp:2022-03-28T19:41:13.634Z]], 
		samsungce.dryerDryingTemperature:[dryingTemperature:[value:medium, timestamp:2022-04-09T20:02:05.594Z], 
										  supportedDryingTemperature:[value:[none, extraLow, low, mediumLow, medium, high], timestamp:2022-03-28T19:41:13.634Z]], 
		samsungce.welcomeMessage:[welcomeMessage:[value:null]], 
		samsungce.dryerCyclePreset:[maxNumberOfPresets:[value:10, timestamp:2022-04-03T16:00:38.127Z], presets:[value:null]], 
		samsungce.deviceIdentification:[micomAssayCode:[value:20185441, timestamp:2022-03-28T19:41:13.603Z], modelName:[value:null], serialNumber:[value:null], 
										serialNumberExtra:[value:null], modelClassificationCode:[value:30000001001031000100000000000000, timestamp:2022-03-28T19:41:13.603Z], 
										description:[value:DA_WM_A51_20_COMMON_DV45K6500Ex0, timestamp:2022-04-03T15:53:57.781Z], 
										binaryId:[value:DA_WM_A51_20_COMMON, timestamp:2022-04-03T15:53:57.781Z]], 
		switch:[switch:[value:off, timestamp:2022-04-09T20:02:05.188Z]], 
		samsungce.dryerFreezePrevent:[operatingState:[value:null]], 
		ocf:[st:[value:null], mndt:[value:null], mnfv:[value:DA_WM_A51_20_COMMON_30210227, timestamp:2022-04-03T16:00:36.424Z], mnhw:[value:ARTIK051, timestamp:2022-04-03T15:53:56.204Z], 
			 di:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], mnsl:[value:null], dmv:[value:1.2.1, timestamp:2022-03-28T19:41:15.224Z], 
			 n:[value:[dryer] Samsung, timestamp:2022-03-28T19:41:15.224Z], mnmo:[value:DA_WM_A51_20_COMMON|20185441|30000001001031000100000000000000, timestamp:2022-04-03T15:53:56.204Z], 
			 vid:[value:DA-WM-WD-000001, timestamp:2022-03-28T19:39:25.368Z], mnmn:[value:Samsung Electronics, timestamp:2022-03-28T19:39:25.368Z], 
			 mnml:[value:http:www.samsung.com, timestamp:2022-03-28T19:39:25.368Z], mnpv:[value:DAWIT 2.0, timestamp:2022-04-03T15:53:56.204Z], 
			 mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-04-03T15:53:56.204Z], pi:[value:c98c12e1-b822-e22f-c98c-b14ff889c897, timestamp:2022-03-28T19:39:25.368Z], 
			 icv:[value:core.1.1.0, timestamp:2022-03-28T19:39:25.368Z]], 
		custom.dryerDryLevel:[dryerDryLevel:[value:normal, timestamp:2022-04-09T20:02:05.744Z], 
							  supportedDryerDryLevel:[value:[none, damp, less, normal, more, very], timestamp:2022-03-28T19:41:13.634Z]], 
		samsungce.dryerAutoCycleLink:[dryerAutoCycleLink:[value:null]], 
		samsungce.dryerCycle:[dryerCycle:[value:Table_00_Course_01, timestamp:2022-04-09T20:02:05.165Z], 
							  supportedCycles:[value:[
								  [cycle:01, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:70, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:71, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:77, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:76, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8204, default:low, options:[low]]]], [cycle:75, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]], [cycle:74, supportedOptions:[dryingLevel:[raw:D308, default:normal, options:[normal]], dryingTemperature:[raw:8410, default:medium, options:[medium]]]], [cycle:6F, supportedOptions:[dryingLevel:[raw:D520, default:very, options:[very]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7C, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7D, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:7E, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8000, options:[]]]], [cycle:7F, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:853E, default:high, options:[extraLow, low, mediumLow, medium, high]]]], [cycle:80, supportedOptions:[dryingLevel:[raw:D000, options:[]], dryingTemperature:[raw:8520, default:high, options:[high]]]], [cycle:81, supportedOptions:[dryingLevel:[raw:D33E, default:normal, options:[damp, less, normal, more, very]], dryingTemperature:[raw:8102, default:extraLow, options:[extraLow]]]]], timestamp:2022-03-28T19:41:15.122Z], referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z]], custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.dryerCyclePreset, samsungce.detergentOrder, samsungce.detergentState, samsungce.dryerFreezePrevent, samsungce.welcomeMessage], timestamp:2022-04-03T15:53:59.721Z]], samsungce.driverVersion:[versionNumber:[value:21082401, timestamp:2022-03-28T19:39:25.388Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-03-28T19:41:15.099Z]], samsungce.detergentOrder:[alarmEnabled:[value:null], orderThreshold:[value:null]], powerConsumptionReport:[powerConsumption:[value:[energy:626400, deltaEnergy:200, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, start:2022-04-09T19:52:23Z, end:2022-04-09T19:57:57Z], timestamp:2022-04-09T19:57:57.648Z]], dryerOperatingState:[completionTime:[value:2022-04-09T21:17:05Z, timestamp:2022-04-09T20:02:05.880Z], machineState:[value:stop, timestamp:2022-04-09T20:02:05.267Z], supportedMachineStates:[value:null], dryerJobState:[value:none, timestamp:2022-04-09T20:02:05.458Z]], samsungce.detergentState:[remainingAmount:[value:null], dosage:[value:null], initialAmount:[value:null], detergentType:[value:null]], samsungce.dryerDelayEnd:[remainingTime:[value:null]], refresh:[:], custom.jobBeginningStatus:[jobBeginningStatus:[value:null]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.operation], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.state:Ready, x.com.samsung.da.remainingTime:01:15:00, x.com.samsung.da.progressPercentage:1, x.com.samsung.da.progress:None, x.com.samsung.da.supportedProgress:[None, Drying, Cooling, Finish]]], data:[href:/operational/state/vs/0], timestamp:2022-04-09T20:02:05.880Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-29T19:45:26.777Z]], custom.supportedOptions:[referenceTable:[value:[id:Table_00], timestamp:2022-03-28T19:41:15.219Z], supportedCourses:[value:[01, 70, 71, 77, 76, 75, 74, 6F, 7C, 7D, 7E, 7F, 80, 81], timestamp:2022-03-28T19:41:15.122Z]], samsungce.dryerDryingTime:[supportedDryingTime:[value:[0, 20, 30, 40, 50, 60], timestamp:2022-03-28T19:41:13.634Z], dryingTime:[value:0, unit:min, timestamp:2022-04-09T20:02:05.740Z]]]]]]]

Time Remaing.  Same as washer
Command processing.  Same as washer
dryerJobState: Check Null.  Move to custom capability.
Remove dryingTime

New Change: Eliminate attribute dryLevel.
Remove try loops for attributes
Fix logging

========== Test Methods
def simulate() { return true }
def testData() {
	def wrinklePrevent = "off"
	def dryingTemp = "high"
	def completionTime = "2022-05-03T17:56:26Z"
	def machineState = "run"
	def jobState = "wash"
	def onOff = "off"
	def kidsLock = "locked"
	def remoteControl = "false"
	
	return  [components:[
		main:[
			"custom.dryerWrinklePrevent":[dryerWrinklePrevent:[value:wrinklePrevent]], 
			"samsungce.dryerDryingTemperature":[dryingTemperature:[value:dryingTemp]], 
			switch:[switch:[value:onOff]],
			"samsungce.kidsLock":[lockState:[value:kidsLock]], 
			dryerOperatingState:[
				completionTime:[value:completionTime], 
				machineState:[value:machineState], 
				dryerJobState:[value:jobState]], 
			remoteControlStatus:[remoteControlEnabled:[value:remoteControl]], 
		]]]
}
def refresh() {
	if (simulate() == true) {
		deviceStatusParse(testData(), "simulation")
	} else {
		commonRefresh()
	}
}
*/














/*	HubiThings Replica Samsung Dryer Driver
	HubiThings Replica Applications Copyright 2023 by Bloodtick
	Replica RangeOven Copyright 2023 by Dave Gutheinz

	Licensed under the Apache License, Version 2.0 (the "License"); 
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at:
	      http://www.apache.org/licenses/LICENSE-2.0
	Unless required by applicable law or agreed to in writing, software 
	distributed under the License is distributed on an "AS IS" BASIS, 
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
	implied. See the License for the specific language governing 
	permissions and limitations under the License.

Issues with this driver: Contact davegut via Private Message on the
Hubitat Community site: https://community.hubitat.com/
==========================================================================*/
def driverVer() { return "1.0" }
def appliance() { return "ReplicaSamsungDryer" }

metadata {
	definition (name: appliance(),
				namespace: "replica",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubithingsReplica/main/Drivers/${appliance()}.groovy"
			   ){
		capability "Configuration"
		capability "Refresh"
		attribute "healthStatus", "enum", ["offline", "online"]
		capability "Refresh"
		attribute "lockState", "string"
		attribute "remoteControlEnabled", "boolean"
		attribute "switch", "string"
		attribute "completionTime", "string"
		attribute "machineState", "string"
		attribute "dryerJobState", "string"
		command "start"
		command "pause"
		command "stop"
		attribute "timeRemaining", "string"
		attribute "dryerDryLevel", "string"
		attribute "dryerWrinklePrevent", "string"
		attribute "jobBeginningStatus", "string"
	}
	preferences {
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging${helpLogo()}",defaultValue: true)
		input ("traceLog", "bool", title: "Enable trace logging as directed by developer", defaultValue: false)
	}
}

String helpLogo() {
	return """<a href="https://github.com/DaveGut/HubitatActive/blob/master/HubiThingsReplica/Docs/SamsungDryerReadme.md">""" +
		"""<div style="position: absolute; top: 20px; right: 150px; height: 80px; font-size: 28px;">Dryer Help</div></a>"""
}

//	===== Installation, setup and update =====
def installed() {
	updateDataValue("componentId", "main")
	runIn(1, updated)
}

def updated() {
	unschedule()
	pauseExecution(2000)
	def updStatus = [:]
	if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		updStatus << [driverVer: driverVer()]
	}
	if (logEnable) { runIn(1800, debugLogOff) }
	if (traceLog) { runIn(600, traceLogOff) }
	updStatus << [logEnable: logEnable, infoLog: infoLog, traceLog: traceLog]
	runIn(3, configure)
	logInfo("updated: ${updStatus}")
}

def designCapabilities() {
	return ["refresh", "remoteControlStatus", "samsungce.kidsLock", 
			"switch", "dryerOperatingState",  "custom.dryerDryLevel", 
			"custom.dryerWrinklePrevent", "custom.jobBeginningStatus"
			]
}

Map designChildren() { return [:] }

def sendRawCommand(component, capability, command, arguments = []) {
	Map status = [:]
	def rcEnabled = device.currentValue("remoteControlEnabled")
	if (rcEnabled) {
		def deviceId = new JSONObject(getDataValue("description")).deviceId
		def cmdStatus = parent.setSmartDeviceCommand(deviceId, component, capability, command, arguments)
		def cmdData = [component, capability, command, arguments, cmdStatus]
		status << [cmdData: cmdData]
	} else {
		status << [FAILED: [rcEnabled: rcEnabled]]
	}
	return status
}

//	===== Device Commands =====
def start() { setMachineState("run") }
def pause() { setMachineState("pause") }
def stop() { setMachineState("stop") }
def setMachineState(machState) {
	def oldState = device.currentValue("machineState")
	Map cmdStatus = [oldState: oldState, newState: machState]
	if (oldState != machState) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), "dryerOperatingState", 
									"setMachineState", [machState])
	} else {
		cmdStatus << [FAILED: "no change in state"]
		runIn(10, checkAttribute, [data: ["setMachineState", "machineState", machState]])
	}
	logInfo("setMachineState: ${cmdStatus}")
}

def checkAttribute(setCommand, attrName, attrValue) {
	def checkValue = device.currentValue(attrName).toString()
	if (checkValue != attrValue.toString()) {
		Map warnTxt = [command: setCommand,
					   attribute: attrName,
					   checkValue: checkValue,
					   attrValue: attrValue,
					   failed: "Function not accepted by the device."]
		logWarn("checkAttribute: ${warnTxt}")
	}
}

def parseEvent(event) {
	logDebug("parseEvent: <b>${event}</b>")
	if (state.deviceCapabilities.contains(event.capability)) {
		logTrace("parseEvent: <b>${event}</b>")
		if (event.value != null) {
			switch(event.attribute) {
				case "completionTime":
					setEvent(event)
					def timeRemaining = calcTimeRemaining(event.value)
					setEvent([attribute: "timeRemaining", value: timeRemaining, unit: null])
					break
				case "supportedMachineStates":
				case "supportedDryerDryLevel":
				case "operatingState":
				case "supportedDryingTime":
					break				
				default:
					setEvent(event)
					break
			}
		}
	}
}

def setState(event) {
	def attribute = event.attribute
	if (state."${attribute}" != event.value) {
		state."${event.attribute}" = event.value
		logInfo("setState: [event: ${event}]")
	}
}

def setEvent(event) {
	logTrace("<b>setEvent</b>: ${event}")
	sendEvent(name: event.attribute, value: event.value, unit: event.unit)
	if (device.currentValue(event.attribute).toString() != event.value.toString()) {
		logInfo("setEvent: [event: ${event}]")
	}
}

def calcTimeRemaining(completionTime) {
	Integer currTime = now()
	Integer compTime
	try {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	} catch (e) {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	}
	Integer timeRemaining = ((compTime-currTime) /1000).toInteger()
	def hhmmss
	if (timeRemaining < 0) {
		hhmmss = "00:00:00"
    } else {
		hhmmss = new GregorianCalendar( 0, 0, 0, 0, 0, timeRemaining, 0 ).time.format( 'HH:mm:ss' )
	}
	return hhmmss
}

//	===== Libraries =====
#include replica.samsungReplicaCommon
#include davegut.Logging

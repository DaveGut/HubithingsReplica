library (
	name: "samsungReplicaCommon",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "Common Methods for replica Samsung Appliances",
	category: "utilities",
	documentationLink: ""
)
//	version 1.0

import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def configure() {
	Map logData = [:]
    updateDataValue("triggers", groovy.json.JsonOutput.toJson(getReplicaTriggers()))
    updateDataValue("commands", groovy.json.JsonOutput.toJson(getReplicaCommands()))
	updateDataValue("rules", getReplicaRules())
	logData << [triggers: "initialized", commands: "initialized", rules: "initialized"]
	logData << [replicaRules: "initialized"]
	state.checkCapabilities = true
	sendCommand("configure")
	logData: [device: "configuring HubiThings"]
	runIn(5, listAttributes,[data:true])
	logInfo("configure: ${logData}")
}

Map getReplicaCommands() {
    return (["replicaEvent":[[name:"parent*",type:"OBJECT"],[name:"event*",type:"JSON_OBJECT"]], 
			 "replicaStatus":[[name:"parent*",type:"OBJECT"],[name:"event*",type:"JSON_OBJECT"]], 
			 "replicaHealth":[[name:"parent*",type:"OBJECT"],[name:"health*",type:"JSON_OBJECT"]],
			 "setHealthStatusValue":[[name:"healthStatus*",type:"ENUM"]]])
}

Map getReplicaTriggers() {
	return [refresh:[], deviceRefresh: []]
}

String getReplicaRules() {
	return """{"version":1,"components":[{"trigger":{"type":"attribute","properties":{"value":{"title":"HealthState","type":"string"}},"additionalProperties":false,"required":["value"],"capability":"healthCheck","attribute":"healthStatus","label":"attribute: healthStatus.*"},"command":{"name":"setHealthStatusValue","label":"command: setHealthStatusValue(healthStatus*)","type":"command","parameters":[{"name":"healthStatus*","type":"ENUM"}]},"type":"smartTrigger","mute":true},{"trigger":{"name":"refresh","label":"command: refresh()","type":"command"},"command":{"name":"refresh","type":"command","capability":"refresh","label":"command: refresh()"},"type":"hubitatTrigger"},{"trigger":{"name":"deviceRefresh","label":"command: deviceRefresh()","type":"command"},"command":{"name":"refresh","type":"command","capability":"refresh","label":"command: refresh()"},"type":"hubitatTrigger"}]}"""
}
	
//	===== Event Parse Interface s=====
void replicaStatus(def parent=null, Map status=null) {
	def logData = [parent: parent, status: status]
	if (state.checkCapabilities) {
		runIn(10, checkCapabilities, [data: status.components])
	} else if (state.refreshAttributes) {
		refreshAttributes(status.components)
	}
	logDebug("replicaStatus: ${logData}")
}

def checkCapabilities(components) {
	state.checkCapabilities = false
	def componentId = getDataValue("componentId")
	def disabledCapabilities = []
	try {
		disabledCapabilities << components[componentId]["custom.disabledCapabilities"].disabledCapabilities.value
	} catch (e) { }

	def enabledCapabilities = []
	Map description
	try {
		description = new JsonSlurper().parseText(getDataValue("description"))
	} catch (error) {
		logWarn("checkCapabilities.  Data element Description not loaded. Run Configure")
	}
	def thisComponent = description.components.find { it.id == componentId }
	thisComponent.capabilities.each { capability ->
		if (designCapabilities().contains(capability.id) &&
			!disabledCapabilities.contains(capability.id)) {
			enabledCapabilities << capability.id
		}
	}
	state.deviceCapabilities = enabledCapabilities
	runIn(1, configureChildren, [data: components])
	runIn(5, refreshAttributes, [data: components])
	logInfo("checkCapabilities: [design: ${designCapabilities()}, disabled: ${disabledCapabilities}, enabled: ${enabledCapabilities}]")
}

//	===== Child Configure / Install =====
def configureChildren(components) {
	def logData = [:]
	def componentId = getDataValue("componentId")
	def disabledComponents = []
	try {
		disabledComponents << components[componentId]["custom.disabledComponents"].disabledComponents.value
	} catch (e) { }
	designChildren().each { designChild ->
		if (disabledComponents.contains(designChild.key)) {
			logData << ["${designChild.key}": [status: "SmartThingsDisabled"]]
		} else {
			def dni = device.getDeviceNetworkId()
			def childDni = "${dni}-${designChild.key}"
			def child = getChildDevice(childDni)
			def name = "${device.displayName} ${designChild.key}"
			if (child == null) {
				def type = "${appliance()}${designChild.value}"
				try {
					addChildDevice("replica", "${type}", "${childDni}", [
						name: type, 
						label: name,
						componentId: designChild.key
					])
					logData << ["${name}": [status: "installed"]]
				} catch (error) {
					logData << ["${name}": [status: "FAILED", reason: error]]
				}
			} else {
				child.checkCapabilities(components)
				logData << ["${name}": [status: "already installed"]]
			}
		}
	}
	runIn(1, checkChildren, [data: components])
	runIn(3, refreshAttributes, [data: components])
	logInfo("configureChildren: ${logData}")
}

def checkChildren(components) {
	getChildDevices().each {
		it.checkCapabilities(components)
	}
}

//	===== Attributes
def refreshAttributes(components) {
	state.refreshAttributes = false
	def component = components."${getDataValue("componentId")}"
	logDebug("refreshAttributes: ${component}")
	component.each { capability ->
		capability.value.each { attribute ->
			parseEvent([capability: capability.key,
						attribute: attribute.key,
						value: attribute.value.value,
						unit: attribute.value.unit])
			pauseExecution(50)
		}
	}
	getChildDevices().each {
		it.refreshAttributes(components)
	}
}

void replicaHealth(def parent=null, Map health=null) {
	if(parent) { logInfo("replicaHealth: ${parent?.getLabel()}") }
	if(health) { logInfo("replicaHealth: ${health}") }
}

def setHealthStatusValue(value) {    
    sendEvent(name: "healthStatus", value: value, descriptionText: "${device.displayName} healthStatus set to $value")
}

void replicaEvent(def parent=null, Map event=null) {
	if (event && event.deviceEvent.componentId == getDataValue("componentId")) {
		try {
			parseEvent(event.deviceEvent)
		} catch (err) {
			logWarn("replicaEvent: [event = ${event}, error: ${err}")
		}
	} else {
		getChildDevices().each { 
			it.parentEvent(event)
		}
	}
}

def sendCommand(String name, def value=null, String unit=null, data=[:]) {
    parent?.deviceTriggerHandler(device, [name:name, value:value, unit:unit, data:data, now:now])
}

//	===== Refresh Commands =====
def refresh() {
	logDebug("refresh")
	state.refreshAttributes = true
	sendCommand("deviceRefresh")
	runIn(1, sendCommand, [data: ["refresh"]])
}

def deviceRefresh() {
	sendCommand("deviceRefresh")
}

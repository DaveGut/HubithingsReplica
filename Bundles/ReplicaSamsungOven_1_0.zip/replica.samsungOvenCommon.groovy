library (
	name: "samsungOvenCommon",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "Common Methods for replica Samsung Oven parent/children",
	category: "utilities",
	documentationLink: ""
)
//	Version 1.0

//	===== Common Capabilities, Commands, and Attributes =====
command "setOvenSetpoint", [[name: "oven temperature", type: "NUMBER"]]
attribute "ovenSetpoint", "number"
attribute "ovenTemperature", "number"	//	attr.temperature
command "setOvenMode", [[name: "from state.supported OvenModes", type:"STRING"]]
attribute "ovenMode", "string"
command "stop"
command "pause"
command "start", [[name: "mode", type: "STRING"],
				  [name: "time (hh:mm:ss OR secs)", type: "STRING"],
				  [name: "setpoint", type: "NUMBER"]]
attribute "completionTime", "string"	//	time string
attribute "progress", "number"			//	percent
attribute "operatingState", "string"	//	attr.machineState
attribute "ovenJobState", "string"
attribute "operationTime", "string"
command "setOperationTime", [[name: "time (hh:mm:ss OR secs)", type: "STRING"]]

def parseEvent(event) {
	logDebug("parseEvent: <b>${event}</b>")
	if (state.deviceCapabilities.contains(event.capability)) {
		logTrace("parseEvent: <b>${event}</b>")
		if (event.value != null) {
			switch(event.attribute) {
				case "machineState":
					if (!state.deviceCapabilities.contains("samsungce.ovenOperatingState")) {
						event.attribute = "operatingState"
						setEvent(event)
					}
					break
				case "operationTime":
					def opTime = formatTime(event.value, "hhmmss", "parseEvent")
					event.value = opTime
				case "completionTime":
				case "progress":
				case "ovenJobState":
				case "operationTime":
					if (state.deviceCapabilities.contains("samsungce.ovenOperatingState")) {
						if (event.capability == "samsungce.ovenOperatingState") {
							setEvent(event)
						}
					} else {
						setEvent(event)
					}
					break
				case "temperature":
					def attr = "ovenTemperature"
					if (event.capability == "samsungce.meatProbe") {
						attr = "probeTemperature"
					}
					event["attribute"] = attr
					setEvent(event)
					break
				case "temperatureSetpoint":
					event["attribute"] = "probeSetpoint"
					setEvent(event)
					break
				case "status":
					event["attribute"] = "probeStatus"
					setEvent(event)
					break
				case "ovenMode":
					if (state.deviceCapabilities.contains("samsungce.ovenMode")) {
						if (event.capability == "samsungce.ovenMode") {
							setEvent(event)
						}
					} else {
						setEvent(event)
					}
					break
				case "supportedOvenModes":
				//	if samsungce.ovenMode, use that, otherwise use
				//	ovenMode.  Format always hh:mm:ss.
					if (state.deviceCapabilities.contains("samsungce.ovenMode")) {
						if (event.capability == "samsungce.ovenMode") {
							setState(event)
						}
					} else {
						setState(event)
					}
					break
				case "supportedBrightnessLevel":
					setState(event)
					break
				case "supportedCooktopOperatingState":
					break
				default:
					setEvent(event)
					break
			}
		}
	}
}

def setState(event) {
	def attribute = event.attribute
	if (state."${attribute}" != event.value) {
		state."${event.attribute}" = event.value
		logInfo("setState: [event: ${event}]")
	}
}

def setEvent(event) {
	logTrace("<b>setEvent</b>: ${event}")
	sendEvent(name: event.attribute, value: event.value, unit: event.unit)
	if (device.currentValue(event.attribute).toString() != event.value.toString()) {
		logInfo("setEvent: [event: ${event}]")
	}
}

//	===== Device Commands =====
def setOvenMode(mode) {
	def ovenMode = checkMode(mode)
	def hasAdvCap =  state.deviceCapabilities.contains("samsungce.ovenOperatingState")
	Map cmdStatus = [mode: mode, ovenMode: ovenMode, hasAdvCap: hasAdvCap]
	if (ovenMode == "notSupported") {
		cmdStatus << [FAILED: ovenMode]
	} else if (hasAdvCap) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), 
									"samsungce.ovenMode", "setOvenMode", [ovenMode])
	} else {
		cmdStatus << sendRawCommand(getDataValue("componentId"), 
									"ovenMode", "setOvenMode", [ovenMode])
	}
	logInfo("setOvenMode: ${cmdStatus}")
}

def checkMode(mode) {
	mode = state.supportedOvenModes.find { it.toLowerCase() == mode.toLowerCase() }
	if (mode == null) {
		mode = "notSupported"
	}
	return mode
}

def setOvenSetpoint(setpoint) {
	setpoint = setpoint.toInteger()
	Map cmdStatus = [setpoint: setpoint]
	if (setpoint >= 0) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), "ovenSetpoint", "setOvenSetpoint", [setpoint])
		logInfo("setOvenSetpoint: ${setpoint}")
	} else {
		cmdStatus << [FAILED: "invalidSetpoint"]
	}
	logInfo("setOvenSetpoint: ${cmdStatus}")
}

def setOperationTime(opTime) {
	def hasAdvCap =  state.deviceCapabilities.contains("samsungce.ovenOperatingState")
	Map cmdStatus = [opTime: opTime, hasAdvCap: hasAdvCap]
	def success = true
	def hhmmss = formatTime(opTime, "hhmmss", "setOperationTime")
	if (hasAdvCap) {
		cmdStatus << [formatedOpTime: opTime]
		if (opTime == "invalidEntry") {
			cmdStatus << [FAILED: opTime]
			success = false
		} else {
			cmdStatus << sendRawCommand(getDataValue("componentId"), 
										"samsungce.ovenOperatingState", 
										"setOperationTime", [hhmmss])
		}
	} else {
		opTime = formatTime(opTime, "seconds", "setOperationTime")
		cmdStatus << [formatedOpTime: opTime]
		if (opTime == "invalidEntry") {
			cmdStatus << [FAILED: opTime]
			success = false
		} else {
			Map opCmd = [time: opTime]
			cmdStatus << sendRawCommand(getDataValue("componentId"), 
										"ovenOperatingState", 
										"start", [opCmd])
		}
	}
	logInfo("setOperationTime: ${cmdStatus}")
	if (success) {
		runIn(10, checkAttribute, [data: ["setOperationTime", "operationTime", hhmmss]])
	}
}

def stop() {
	def hasAdvCap =  state.deviceCapabilities.contains("samsungce.ovenOperatingState")
	Map cmdStatus = [hasAdvCap: hasAdvCap]
	if (hasAdvCap) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), 
									"samsungce.ovenOperatingState", "stop")
	} else {
		cmdStatus << sendRawCommand(getDataValue("componentId"), 
									"ovenOperatingState", "stop")
	}
	logInfo("stop: ${cmdStatus}")
}

def pause() {
	def hasAdvCap =  state.deviceCapabilities.contains("samsungce.ovenOperatingState")
	Map cmdStatus = [hasAdvCap: hasAdvCap]
	if (hasAdvCap) {
		cmdStatus << sendRawCommand(getDataValue("componentId"), 
									"samsungce.ovenOperatingState", "pause")
		runIn(10, checkAttribute, [data: ["pause", "operatingState", "paused"]])
	} else {
		cmdStatus << [FAILED: "pause not available on device"]
	}
	logInfo("pause: ${cmdStatus}")
}

def start(mode = null, opTime = null, setpoint = null) {
	def hasAdvCap =  state.deviceCapabilities.contains("samsungce.ovenOperatingState")
	Map cmdStatus = [hasAdvCap: hasAdvCap, input: 
					 [mode: mode, opTime: opTime, setpoint: setpoint]]
	if (hasAdvCap) {
		if (mode != null) {
			setOvenMode(mode)
			pauseExecution(2000)
		}
		if (setpoint != null) {
			setOvenSetpoint(setpoint)
			pauseExecution(2000)
		}
		if (opTime != null) {
			setOperationTime(opTime)
			pauseExecution(2000)
		}
		cmdStatus << sendRawCommand(getDataValue("componentId"),
									"samsungce.ovenOperatingState", "start", [])
		runIn(10, checkAttribute, [data: ["start", "operatingState", "running"]])
	} else {
		Map opCmd = [:]
		def failed = false
		if (mode != null) {
			def ovenMode = checkMode(mode)
			cmdStatus << [cmdMode: ovenMode]
			opCmd << [mode: ovenMode]
			if (ovenMode == "notSupported") {
				failed = true
			}
		}
		if (opTime != null) {
			opTime = formatTime(opTime, "seconds", "setOperationTime")
			cmdStatus << [cmdOpTime: opTime]
			opCmd << [time: opTime]
			if (opTime == "invalidEntry") {
				failed = true
			}
		}
		if (setpoint != null) {
			setpoint = setpoint.toInteger()
			cmdStatus << [cmdSetpoint: setpoint]
			opCmd << [setpoint: setpoint]
			if (setpoint < 0) {
				failed = true
			}
		}
		if (failed == false) {
			cmdStatus << sendRawCommand(getDataValue("componentId"),
										"ovenOperatingState", "start", [opCmd])
			runIn(10, checkAttribute, [data: ["start", "operatingState", "running"]])
		} else {
			cmdStatus << [FAILED: "invalidInput"]
		}
	}
	logInfo("start: ${cmdStatus}")
}

def checkAttribute(setCommand, attrName, attrValue) {
	def checkValue = device.currentValue(attrName).toString()
	if (checkValue != attrValue.toString()) {
		Map warnTxt = [command: setCommand,
					   attribute: attrName,
					   checkValue: checkValue,
					   attrValue: attrValue,
					   failed: "Function may be disabled by SmartThings"]
		logWarn("checkAttribute: ${warnTxt}")
	}
}

def formatTime(timeValue, desiredFormat, callMethod) {
	timeValue = timeValue.toString()
	def currentFormat = "seconds"
	if (timeValue.contains(":")) {
		currentFormat = "hhmmss"
	}
	def formatedTime
	if (currentFormat == "hhmmss") {
		formatedTime = formatHhmmss(timeValue)
		if (desiredFormat == "seconds") {
			formatedTime = convertHhMmSsToInt(formatedTime)
		}
	} else {
		formatedTime = timeValue
		if (desiredFormat == "hhmmss") {
			formatedTime = convertIntToHhMmSs(timeValue)
		}
	}
	if (formatedTime == "invalidEntry") {
		Map errorData = [callMethod: callMethod, timeValue: timeValue,
						 desiredFormat: desiredFormat]
		logWarn("formatTime: [error: ${formatedTime}, data: ${errorData}")
	}
	return formatedTime
}

def formatHhmmss(timeValue) {
	def timeArray = timeValue.split(":")
	def hours = 0
	def minutes = 0
	def seconds = 0
	if (timeArray.size() != timeValue.count(":") + 1) {
		return "invalidEntry"
	} else {
		try {
			if (timeArray.size() == 3) {
				hours = timeArray[0].toInteger()
				minutes = timeArray[1].toInteger()
				seconds = timeArray[2].toInteger()
			} else if (timeArray.size() == 2) {
				minutes = timeArray[0].toInteger()
				seconds = timeArray[1].toInteger()
			}
		} catch (error) {
			return "invalidEntry"
		}
	}
	if (hours < 10) { hours = "0${hours}" }
	if (minutes < 10) { minutes = "0${minutes}" }
	if (seconds < 10) { seconds = "0${seconds}" }
	return "${hours}:${minutes}:${seconds}"
}

def convertIntToHhMmSs(timeSeconds) {
	def hhmmss
	try {
		hhmmss = new GregorianCalendar( 0, 0, 0, 0, 0, timeSeconds.toInteger(), 0 ).time.format( 'HH:mm:ss' )
	} catch (error) {
		hhmmss = "invalidEntry"
	}
	return hhmmss
}

def convertHhMmSsToInt(timeValue) {
	def timeArray = timeValue.split(":")
	def seconds = 0
	if (timeArray.size() != timeValue.count(":") + 1) {
		return "invalidEntry"
	} else {
		try {
			if (timeArray.size() == 3) {
				seconds = timeArray[0].toInteger() * 3600 +
				timeArray[1].toInteger() * 60 + timeArray[2].toInteger()
			} else if (timeArray.size() == 2) {
				seconds = timeArray[0].toInteger() * 60 + timeArray[1].toInteger()
			}
		} catch (error) {
			seconds = "invalidEntry"
		}
	}
	return seconds
}

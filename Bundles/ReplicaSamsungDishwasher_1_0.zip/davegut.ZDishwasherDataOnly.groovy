metadata {
	definition (name: "Z Dishwasher Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}
def designCaps () {
	def caps = [
		"refresh", "switch", 
		"samsungce.dishwasherWashingCourse",
		"samsungce.dishwasherJobState",
		"samsungce.dishwasherOperation",
		"samsungce.kidsLock",
		"remoteControlStatus",
		"dishwasherOperatingState",
		"custom_dishwasherDelayStartTime",
		"custom.dishwasherOperatingProgress"
	]
}

def setModeCaps() {
/*	
	def ce_dishwasherOperation = [
	id:samsungce.dishwasherOperation, version:1, status:proposed, name:Dishwasher Operation, ephemeral:false, 
	attributes:[
		xx_supportedOperatingState:[schema:[type:object, properties:[value:[type:array, items:[type:string, enum:[idle, ready, running, paused]]]], additionalProperties:false, required:[value]], enumCommands:[]], 
		operatingState:[schema:[type:object, properties:[value:[type:string, enum:[idle, ready, running, paused]]], additionalProperties:false, required:[value]], setter:setOperatingState, enumCommands:[]], 
		xx_reservable:[schema:[type:object, properties:[value:[type:boolean, default:false]], additionalProperties:false, required:[value]], enumCommands:[]], 
		xx_progressPercentage:[schema:[type:object, properties:[value:[type:number]], additionalProperties:false, required:[value]], enumCommands:[]], 
		xx_remainingTimeStr:[schema:[type:object, properties:[value:[type:string], additionalProperties:false, required:[value]], enumCommands:[]], 
		operationTime:[schema:[type:object, properties:[value:[type:number], unit:[type:string, enum:[hour, min, sec]]], additionalProperties:false, required:[value, unit]], enumCommands:[]], 
		remainingTime:[schema:[type:object, properties:[value:[type:number], unit:[type:string, enum:[hour, min, sec]]], additionalProperties:false, required:[value, unit]], enumCommands:[]], 
		timeLeftToStart:[schema:[type:object, properties:[value:[type:number], unit:[type:string, enum:[hour, min, sec]]], additionalProperties:false, required:[value, unit]], enumCommands:[]]], 
	commands:[
		resume:[name:resume, arguments:[]], 
		cancel:[name:cancel, arguments:[[name:drain, optional:true, schema:[type:boolean]]]], 
		xx_setOperatingState:[name:setOperatingState, arguments:[[name:operatingState, optional:false, schema:[type:string, enum:[running, paused, ready]]]]], 
		start:[name:start, arguments:[[name:option, optional:true, schema:[type:object]]]], 
		startLater:[name:startLater, arguments:[[name:delay, optional:false, schema:[type:number]]]], 
		pause:[name:pause, arguments:[]]]]]

	def dishwasherOperatingState = [
	id:dishwasherOperatingState, version:1, status:proposed, name:"Dishwasher Operating State, 
	ephemeral:false, 
	attributes:[
		completionTime:[
			schema:[type:object, 
					properties:[value:[title:Iso8601Date, type:string, pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$]], 
					additionalProperties:false, required:[value]], enumCommands:[]], 
		machineState:[schema:[type:object, properties:[value:[title:MachineState, type:string, enum:[pause, run, stop]]], 
							  additionalProperties:false, required:[value]], setter:setMachineState, enumCommands:[]], 
		xx_supportedMachineStates:[schema:[type:object, properties:[value:[type:array, items:[title:MachineState, type:string, enum:[pause, run, stop]]]], 
										additionalProperties:false, required:[value]], enumCommands:[]], 
		xx_dishwasherJobState:[schema:[type:object, properties:[value:[title:DishwasherJobState, type:string, 
																	enum:[airwash, cooling, drying, finish, preDrain, prewash, rinse, spin, unknown, wash, wrinklePrevent]]], 
									additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setMachineState:[name:setMachineState, 
						 arguments:[
							 [name:state, 
							  optional:false, 
							  schema:[title:MachineState, type:string, enum:[pause, run, stop]]]]]]]

	def custom_dishwasherDelayStartTime = [
	id:custom.dishwasherDelayStartTime, version:1, status:proposed, 
	name:Dishwasher Delay Start Time, ephemeral:false, 
	attributes:[
		dishwasherDelayStartTime:[
			schema:[
				type:object, 
				properties:[value:[type:string, pattern:^((([0-1][0-9]|2[0-3]):([0-5][0-9]):00)|(24:00:00))$]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setDishwasherDelayStartTime:[
			name:setDishwasherDelayStartTime, 
			arguments:[
				[name:dishwasherDelayStartTime, optional:false,
				 schema:[type:string, pattern:^((([0-1][0-9]|2[0-3]):([0-5][0-9]):00)|(24:00:00))$]]]]]]
*/
}

def jobState() {
/*
	def custom.dishwasherOperatingProgress = [
	id:custom.dishwasherOperatingProgress, version:1, status:proposed, name:Dishwasher Operating Progress, 
	ephemeral:false, 
	attributes:[
		dishwasherOperatingProgress:[
			schema:[type:object, properties:[value:[enum:[
			none, delaywash, weightsensing, prewash, wash, rinse, spin, sud, drying, airwash, cooling, wrinkleprevent, finish, waitend, 
			predrain, sanitizing, autoreleasedrying], type:string]], additionalProperties:false, required:[value]], enumCommands:[]]
	], 
	commands:[:]]

	def samsungce.dishwasherJobState = [
	id:samsungce.dishwasherJobState, version:1, status:proposed, name:Dishwasher Job State, ephemeral:false, 
	attributes:[
		scheduledJobs:[
			schema:[type:object, properties:[value:[type:array, items:[type:object, properties:[jobName:[type:string, enum:[none, delayWashing, preWashing, washing, rinsing, drying, cooling, draining, finished, preDrain, sanitizing, autoReleaseDrying]], timeInSec:[type:integer]], required:[jobName, timeInSec]]]], additionalProperties:false, required:[value]], enumCommands:[]], 
		dishwasherJobState:[
			schema:[
				type:object, 
				properties:[
					value:[
						type:string, enum:[none, delayWashing, preWashing, washing, rinsing, drying, 
										   cooling, draining, finished, preDrain, sanitizing, 
										   autoReleaseDrying]]], 
				additionalProperties:false, required:[value]], enumCommands:[]]
	], 
	commands:[:]]
*/
}

def miscImplementedCaps() {
/*
	def samsungce.kidsLock = [
	id:samsungce.kidsLock, version:1, status:proposed, name:Kids Lock, ephemeral:false, attributes:[lockState:[schema:[type:object, properties:[value:[type:string, enum:[locked, unlocked, paused]]], additionalProperties:false, required:[value]], enumCommands:[]]], commands:[:]]
	def remoteControlStatus = [
	id:remoteControlStatus, version:1, status:live, name:Remote Control Status, 
	ephemeral:false, 
	attributes:[
		remoteControlEnabled:[schema:[type:object, properties:[value:[type:string, enum:[false, true]]], 
									  additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[:]]
	def samsungce.dishwasherWashingCourse = [
	id:samsungce.dishwasherWashingCourse, version:1, status:proposed, name:Dishwasher Washing Course, ephemeral:false, 
	attributes:[
		customCourseCandidates:[schema:[type:object, properties:[value:[type:array, items:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]]], additionalProperties:false, required:[value]], enumCommands:[]], 
		washingCourse:[schema:[type:object, properties:[value:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]], additionalProperties:false, required:[value]], setter:setWashingCourse, enumCommands:[]], 
		supportedCourses:[schema:[type:object, properties:[value:[type:array, items:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setWashingCourse:[name:setWashingCourse, arguments:[[name:course, optional:false, schema:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]]]], 
		setCustomCourse:[name:setCustomCourse, arguments:[[name:course, optional:false, schema:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]]]], 
		startWashingCourse:[name:startWashingCourse, arguments:[[name:course, optional:false, schema:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]]]], 
		startWashingCourseWithOptions:[name:startWashingCourseWithOptions, arguments:[
			[name:course, optional:false, schema:[type:string, enum:[auto, eco, intensive, delicate, express, preWash, selfClean, extraSilence, rinseOnly, plastics, potsAndPans, babycare, normal, selfSanitize, dryOnly, upperExpress, night, babyBottle, coldRinse, glasses, quick, heavy, daily, chef, preBlast, steamSoak, rinseDry, machineCare, AI, nightSilence, express_0C, daily_09, eco_08, eco_10]]], 
			[name:options, optional:false, schema:[type:object, additionalProperties:false, 
												   properties:[selectedZone:[type:string, enum:[none, lower, upper, all]],zoneBooster:[type:string, enum:[none, left, right, all]], 
															   speedBooster:[type:boolean], sanitize:[type:boolean],  highTempWash:[type:boolean], steamSoak:[type:boolean], 
															   addRinse:[type:boolean], dryPlus:[type:boolean], stormWash:[type:boolean], sanitizingWash:[type:boolean], 
															   rinsePlus:[type:boolean], hotAirDry:[type:boolean]]]]]]]]
*/
}

def notImplemented() {
	def notImplemented = [
	[id:execute, version:1],
	[id:ocf, version:1],
	[id:powerConsumptionReport, version:1],
	[id:custom.disabledCapabilities, version:1],
	[id:custom.dishwasherOperatingPercentage, version:1], 
	[id:custom.supportedOptions, version:1],
	[id:custom.waterFilter, version:1],
	[id:samsungce.deviceIdentification, version:1],
	[id:samsungce.dishwasherWashingCourseDetails, version:1],
	[id:samsungce.dishwasherWashingOptions, version:1],
	[id:samsungce.driverVersion, version:1],
	[id:samsungce.softwareUpdate, version:1],
	[id:sec.diagnosticsInformation, version:1]
	]
/*	def custom_dishwasherDelayStartTime = [
	id:custom.dishwasherDelayStartTime, version:1, status:proposed, 
	name:Dishwasher Delay Start Time, ephemeral:false, 
	attributes:[
		dishwasherDelayStartTime:[
			schema:[
				type:object, 
				properties:[value:[type:string, pattern:^((([0-1][0-9]|2[0-3]):([0-5][0-9]):00)|(24:00:00))$]], 
				additionalProperties:false, required:[value]], enumCommands:[]]], 
	commands:[
		setDishwasherDelayStartTime:[
			name:setDishwasherDelayStartTime, 
			arguments:[
				[name:dishwasherDelayStartTime, optional:false,
				 schema:[type:string, pattern:^((([0-1][0-9]|2[0-3]):([0-5][0-9]):00)|(24:00:00))$]]]]]]*/
	
}
/*
device capabilities = components.each (it.id ) - components.disabledCapabilities
attributes:  Define attributes bases on implementation.  Use same attribute id's
for mode and progress messaging.
*/




/*

description: [
	"deviceId":"5C86C108-BAEB-0000-0000-000000000000","name":"Dishwasher","label":"Dishwasher",
	"manufacturerName":"Samsung Electronics","presentationId":"DA-WM-DW-100001",
	"deviceManufacturerCode":"Samsung Electronics","locationId":"d258ce45-48ca-420c-bacd-30e98c0cdf72",
	"ownerId":"b86a18d7-22a2-40c0-62ca-76da4f73e64b","roomId":"d4139b3f-a056-49bc-8fbf-bb9429fd182d",
	"deviceTypeName":"Samsung OCF Dishwasher",
	"components":[
		[
			"id":"main","label":"main",
			"capabilities":[
				["id":"execute","version":1],
				["id":"ocf","version":1],
				["id":"powerConsumptionReport","version":1],
				["id":"refresh","version":1],
				["id":"remoteControlStatus","version":1],
				["id":"dishwasherOperatingState","version":1],
				["id":"custom.dishwasherOperatingProgress","version":1],
				["id":"samsungce.driverVersion","version":1]]
			,"categories":[["name":"Dishwasher","categoryType":"manufacturer"]]]],
	"createTime":"2023-01-07T19:18:26.064Z",
	"profile":["id":"101a2940-e50c-34d4-84bc-5dd99234f260"],
	"ocf":[
		"ocfDeviceType":"oic.d.dishwasher","name":"Dishwasher","specVersion":"core.1.1.0",
		"verticalDomainSpecVersion":"res.1.1.0,sh.1.1.0","manufacturerName":"Samsung Electronics",
		"modelNumber":"TP6X_DW80M9960US|30005241|40010201001111000100000000000000",
		"vendorId":"DA-WM-DW-100001",
		"lastSignupTime":"2023-01-07T19:18:25.431970Z"],
	"type":"OCF",
	"restrictionTier":0,"allowed":null]

deviceData: [
	deviceId:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, 
	name:[dishwasher] Samsung, 
	label:Dishwasher, 
	manufacturerName:Samsung Electronics, 
	presentationId:DA-WM-DW-000001, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:f4b7b4c0-d957-4f83-b8b4-1e00e71b101b, 
	ownerId:e8685053-d886-4a82-bcff-149e263b9334, 
	roomId:f4ab9071-b494-43d8-8bd0-8e0c6927917c, 
	deviceTypeName:Samsung OCF Dishwasher, 
	components:[
		[id:main, label:main, capabilities:[
			[id:execute, version:1], 
			[id:ocf, version:1], 
			[id:powerConsumptionReport, version:1], 
			[id:refresh, version:1], 
			[id:remoteControlStatus, version:1], 
			[id:switch, version:1], 
			[id:dishwasherOperatingState, version:1], 
			[id:custom.disabledCapabilities, version:1], 
			[id:custom.dishwasherOperatingProgress, version:1], 
			[id:custom.dishwasherOperatingPercentage, version:1], 
			[id:custom.dishwasherDelayStartTime, version:1], 
			[id:custom.supportedOptions, version:1], 
			[id:custom.waterFilter, version:1], 
			[id:samsungce.deviceIdentification, version:1], 
			[id:samsungce.dishwasherJobState, version:1], 
			[id:samsungce.dishwasherWashingCourse, version:1], 
			[id:samsungce.dishwasherWashingCourseDetails, version:1], 
			[id:samsungce.dishwasherOperation, version:1], 
			[id:samsungce.dishwasherWashingOptions, version:1], 
			[id:samsungce.driverVersion, version:1], [id:samsungce.softwareUpdate, version:1], 
			[id:samsungce.kidsLock, version:1], 
			[id:sec.diagnosticsInformation, version:1]], 
		 categories:[[name:Dishwasher, categoryType:manufacturer]]]], createTime:2021-06-20T02:28:41.270Z, 
	profile:[id:83215147-9581-3e0e-acca-b4e2e1a406b2], 
	ocf:[
		ocfDeviceType:oic.d.dishwasher, 
		name:[dishwasher] Samsung, 
		specVersion:core.1.1.0, 
		verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		manufacturerName:Samsung Electronics, 
		modelNumber:DA_DW_A51_20_COMMON|30007242|40010201001311000101000000000000, 
		platformVersion:DAWIT 2.0, 
		platformOS:TizenRT 1.0 + IPv6, hwVersion:ARTIK051, 
		firmwareVersion:DA_DW_A51_20_COMMON_30220418, 
		vendorId:DA-WM-DW-000001, 
		vendorResourceClientServerVersion:ARTIK051 Release 2.210224.1, 
		lastSignupTime:2021-06-20T02:28:38.121470Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]

refreshAttributes: [
	ocf:[
		st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], 
		di:[value:5C86C108-BAEB-0000-0000-000000000000, timestamp:2023-01-07T19:18:26.339Z],
		mnsl:[value:null], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2023-01-07T19:18:26.339Z], 
		n:[value:Dishwasher, timestamp:2023-01-07T19:18:26.339Z], 
		mnmo:[value:TP6X_DW80M9960US|30005241|40010201001111000100000000000000, timestamp:2023-01-07T19:18:26.339Z], 
		vid:[value:DA-WM-DW-100001, timestamp:2023-01-07T19:18:26.339Z], 
		mnmn:[value:Samsung Electronics, timestamp:2023-01-07T19:18:26.339Z], mnml:[value:null], 
		mnpv:[value:null], mnos:[value:null], pi:[value:shp, timestamp:2023-01-08T10:14:01.183Z], 
		icv:[value:core.1.1.0, timestamp:2023-01-07T19:18:26.339Z]], 
	powerConsumptionReport:[powerConsumption:[value:null]], 
	remoteControlStatus:[remoteControlEnabled:[value:true, timestamp:2023-01-29T11:14:22.117Z]], 
	samsungce.driverVersion:[versionNumber:[value:21012901, timestamp:2023-01-07T19:18:54.812Z]], 
	refresh:[:], 
	dishwasherOperatingState:[
		completionTime:[value:2023-01-29T14:04:57Z, timestamp:2023-01-29T11:24:57.612Z], 
		machineState:[value:stop, timestamp:2023-01-29T09:21:02.481Z], 
		supportedMachineStates:[value:null], 
		dishwasherJobState:[value:unknown, timestamp:2023-01-29T09:21:02.481Z]], 
	execute:[data:[value:null]], 
	custom.dishwasherOperatingProgress:[dishwasherOperatingProgress:[value:none, timestamp:2023-01-29T09:21:02.481Z]]]


deviceStatus: [
	components:[
		main:[
			samsungce.dishwasherWashingCourse:[
				customCourseCandidates:[value:null], 
				washingCourse:[value:auto, timestamp:2022-07-31T05:25:52.494Z], 
				supportedCourses:[value:[auto, normal, heavy, delicate, express, rinseOnly, selfClean], timestamp:2021-06-20T02:28:43.163Z]], 
			switch:[switch:[value:off, timestamp:2022-08-09T23:02:37.426Z]], 
			custom.dishwasherOperatingPercentage:[dishwasherOperatingPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z]], 
			samsungce.dishwasherOperation:[
				supportedOperatingState:[value:null], 
				operatingState:[value:ready, timestamp:2022-08-09T23:02:37.497Z], 
				reservable:[value:false, timestamp:2022-07-20T02:35:28.876Z], 
				progressPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z], 
				remainingTimeStr:[value:02:16, timestamp:2022-08-09T23:02:37.716Z], 
				operationTime:[value:null], remainingTime:[value:136.0, unit:min, timestamp:2022-08-09T23:02:37.716Z], 
				timeLeftToStart:[value:0.0, unit:min, timestamp:2022-08-05T16:57:02.657Z]], 
			samsungce.dishwasherJobState:[
				scheduledJobs:[value:[[jobName:washing, timeInSec:3530], [jobName:rinsing, timeInSec:770], [jobName:drying, timeInSec:1400]], timestamp:2022-08-09T23:02:37.933Z], 
				dishwasherJobState:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-06-20T02:28:42.662Z]]]]]


AlldeviceStatus: [
	components:[
		main:[
			samsungce.dishwasherWashingCourse:[
				customCourseCandidates:[value:null], 
				washingCourse:[value:auto, timestamp:2022-07-31T05:25:52.494Z], 
				supportedCourses:[value:[auto, normal, heavy, delicate, express, rinseOnly, selfClean], timestamp:2021-06-20T02:28:43.163Z]], 
			powerConsumptionReport:[powerConsumption:[
				value:[
					energy:202600, deltaEnergy:0, power:0, powerEnergy:0.0, 
					persistedEnergy:0, energySaved:0, 
					   start:2022-08-09T22:52:45Z, end:2022-08-09T23:02:32Z], timestamp:2022-08-09T23:02:32.759Z]], 
			refresh:[:], 
			dishwasherOperatingState:[
				completionTime:[value:2022-08-10T01:18:37Z, timestamp:2022-08-09T23:02:37.716Z], 
				machineState:[value:stop, timestamp:2022-08-09T23:02:37.497Z], 
				supportedMachineStates:[value:null], 
				dishwasherJobState:[value:unknown, timestamp:2022-08-09T23:02:37.504Z]], 
			samsungce.dishwasherWashingCourseDetails:[predefinedCourses:[value:[
				[courseName:auto, energyUsage:3, waterUsage:3, temperature:[min:50, max:60, unit:C], expectedTime:[time:136, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], 
						  sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:normal, energyUsage:3, waterUsage:4, temperature:[min:45, max:62, unit:C], expectedTime:[time:148, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], 
						  speedBooster:[default:false, settable:[false, true]], zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:heavy, energyUsage:4, waterUsage:5, temperature:[min:65, max:65, unit:C], expectedTime:[time:155, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:delicate, energyUsage:2, waterUsage:3, temperature:[min:50, max:50, unit:C], expectedTime:[time:112, unit:min], 
				 options:[highTempWash:[default:false, settable:[]],sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:express, energyUsage:2, waterUsage:2, temperature:[min:52, max:52, unit:C], expectedTime:[time:60, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:rinseOnly, energyUsage:1, waterUsage:1, temperature:[min:40, max:40, unit:C], expectedTime:[time:14, unit:min], 
				 options:[highTempWash:[default:false, settable:[]], sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:selfClean, energyUsage:5, waterUsage:4, temperature:[min:70, max:70, unit:C], expectedTime:[time:139, unit:min], 
				 options:[highTempWash:[default:false, settable:[]], sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, all]]]]], timestamp:2022-07-18T20:00:32.697Z],waterUsageMax:[value:5, timestamp:2021-06-20T02:28:43.163Z], energyUsageMax:[value:5, timestamp:2021-06-20T02:28:43.163Z]], 
			samsungce.dishwasherWashingOptions:[
				dryPlus:[value:null], 
				stormWash:[value:null], 
				hotAirDry:[value:null], 
				selectedZone:[value:[value:all, settable:[none, upper, lower, all]], timestamp:2021-06-21T17:15:23.099Z], 
				speedBooster:[value:[value:false, settable:[false, true]], timestamp:2022-08-08T05:25:37.271Z], 
				highTempWash:[value:[value:false, settable:[false, true]], timestamp:2022-08-08T05:25:37.499Z], 
				sanitizingWash:[value:null], 
				zoneBooster:[value:[value:none, settable:[none, left, right, all]], timestamp:2021-06-21T17:15:22.788Z], 
				addRinse:[value:null], 
				supportedList:[value:[selectedZone, zoneBooster, speedBooster, sanitize, highTempWash], timestamp:2021-06-20T02:28:43.343Z], 
				rinsePlus:[value:null], 
				sanitize:[value:[value:false, settable:[false, true]], timestamp:2022-06-19T16:26:14.740Z], 
				steamSoak:[value:null]], 
			execute:[data:[
				value:[payload:[rt:[x.com.samsung.da.mode], 
								if:[oic.if.baseline, oic.if.a], 
								x.com.samsung.da.options:[ProgressTimeSet_420DCA820302B20578]]], data:[href:/course/vs/0], timestamp:2022-08-09T23:02:37.933Z]], 
			samsungce.deviceIdentification:[
				micomAssayCode:[value:null], 
				modelName:[value:null], 
				serialNumber:[value:null], 
				serialNumberExtra:[value:null], 
				modelClassificationCode:[value:null], 
				description:[value:null], 
				binaryId:[value:DA_DW_A51_20_COMMON, timestamp:2022-07-20T02:35:28.876Z]], 
			custom.dishwasherOperatingProgress:[
				dishwasherOperatingProgress:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			switch:[switch:[value:off, timestamp:2022-08-09T23:02:37.426Z]], 
			custom.dishwasherOperatingPercentage:[dishwasherOperatingPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z]], 
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:DA_DW_A51_20_COMMON_30220418, timestamp:2022-07-30T20:16:08.983Z], 
				 mnhw:[value:ARTIK051, timestamp:2021-06-20T02:28:43.018Z], di:[value:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, timestamp:2021-06-20T02:28:43.018Z], 
				 mnsl:[value:http:www.samsung.com, timestamp:2021-06-20T02:28:43.018Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-07-30T20:33:34.910Z], 
				 n:[value:[dishwasher] Samsung, timestamp:2021-06-20T02:28:43.018Z], mnmo:[value:DA_DW_A51_20_COMMON|30007242|40010201001311000101000000000000, timestamp:2021-06-20T02:28:43.018Z], 
				 vid:[value:DA-WM-DW-000001, timestamp:2021-06-20T02:28:43.018Z], mnmn:[value:Samsung Electronics, timestamp:2021-06-20T02:28:43.018Z], 
				 mnml:[value:http:www.samsung.com, timestamp:2021-06-20T02:28:43.018Z], mnpv:[value:DAWIT 2.0, timestamp:2021-06-20T02:28:43.018Z], 
				 mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-06-20T02:28:43.018Z], pi:[value:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, timestamp:2021-06-20T02:28:43.018Z], 
				 icv:[value:core.1.1.0, timestamp:2021-06-20T02:28:43.018Z]], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-01-23T05:05:50.482Z]], 
			custom.supportedOptions:[
				referenceTable:[value:null], 
				supportedCourses:[value:[82, 83, 84, 85, 86, 87, 88], timestamp:2021-06-20T02:28:43.163Z]], 
			custom.dishwasherDelayStartTime:[dishwasherDelayStartTime:[value:00:00:00, timestamp:2022-08-05T16:57:02.657Z]], 
			custom.disabledCapabilities:[
		disabledCapabilities:[value:[
					custom.dishwasherOperatingProgress,
					custom.dishwasherOperatingPercentage,
					custom.dishwasherDelayStartTime,
					samsungce.dishwasherWashingCourse,
					samsungce.dishwasherWashingCourseDetails,
					samsungce.dishwasherWashingOptions,
					dishwasherOperatingState,
					remoteControlStatus,
					sec.diagnosticsInformation,
					custom.waterFilter], timestamp:2022-08-09T22:37:48.055Z]], 
			samsungce.driverVersion:[versionNumber:[value:22070701, timestamp:2022-07-20T02:35:28.876Z]], 
			samsungce.softwareUpdate:[
				otnDUID:[value:MTCNQWBWKPONC, timestamp:2022-07-20T02:35:28.876Z],
				availableModules:[value:[], timestamp:2022-07-20T02:35:28.876Z],
				newVersionAvailable:[value:false, timestamp:2022-07-20T02:35:28.876Z]], 
			sec.diagnosticsInformation:[
				logType:[value:null], endpoint:[value:null], minVersion:[value:null], setupId:[value:null], protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], 
			samsungce.dishwasherOperation:[
				supportedOperatingState:[value:null], 
				operatingState:[value:ready, timestamp:2022-08-09T23:02:37.497Z], 
				reservable:[value:false, timestamp:2022-07-20T02:35:28.876Z], 
				progressPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z], 
				remainingTimeStr:[value:02:16, timestamp:2022-08-09T23:02:37.716Z], 
				operationTime:[value:null], 
				remainingTime:[value:136.0, unit:min, timestamp:2022-08-09T23:02:37.716Z], 
				timeLeftToStart:[value:0.0, unit:min, timestamp:2022-08-05T16:57:02.657Z]], 
			custom.waterFilter:[
				waterFilterUsageStep:[value:null], waterFilterResetType:[value:null], waterFilterCapacity:[value:null],
				waterFilterLastResetDate:[value:null], waterFilterUsage:[value:null], waterFilterStatus:[value:null]],
			samsungce.dishwasherJobState:[
				scheduledJobs:[value:[[jobName:washing, timeInSec:3530], [jobName:rinsing, timeInSec:770], [jobName:drying, timeInSec:1400]], timestamp:2022-08-09T23:02:37.933Z], 
				dishwasherJobState:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-06-20T02:28:42.662Z]]]]]


deviceData: [
	deviceId:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, 
	name:[dishwasher] Samsung, 
	label:Dishwasher, 
	manufacturerName:Samsung Electronics, 
	presentationId:DA-WM-DW-000001, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:f4b7b4c0-d957-4f83-b8b4-1e00e71b101b, 
	ownerId:e8685053-d886-4a82-bcff-149e263b9334, 
	roomId:f4ab9071-b494-43d8-8bd0-8e0c6927917c, 
	deviceTypeName:Samsung OCF Dishwasher, c
	omponents:[
		[id:main, label:main, capabilities:[
			[id:execute, version:1], 
			[id:ocf, version:1], 
			[id:powerConsumptionReport, version:1], 
			[id:refresh, version:1], 
			[id:remoteControlStatus, version:1], 
			[id:switch, version:1], 
			[id:dishwasherOperatingState, version:1], 
			[id:custom.disabledCapabilities, version:1], 
			[id:custom.dishwasherOperatingProgress, version:1], 
			[id:custom.dishwasherOperatingPercentage, version:1], 
			[id:custom.dishwasherDelayStartTime, version:1], 
			[id:custom.supportedOptions, version:1], 
			[id:custom.waterFilter, version:1], 
			[id:samsungce.deviceIdentification, version:1], 
			[id:samsungce.dishwasherJobState, version:1], 
			[id:samsungce.dishwasherWashingCourse, version:1], 
			[id:samsungce.dishwasherWashingCourseDetails, version:1], 
			[id:samsungce.dishwasherOperation, version:1], 
			[id:samsungce.dishwasherWashingOptions, version:1], 
			[id:samsungce.driverVersion, version:1], [id:samsungce.softwareUpdate, version:1], 
			[id:samsungce.kidsLock, version:1], 
			[id:sec.diagnosticsInformation, version:1]], 
		 categories:[[name:Dishwasher, categoryType:manufacturer]]]], createTime:2021-06-20T02:28:41.270Z, 
	profile:[id:83215147-9581-3e0e-acca-b4e2e1a406b2], 
	ocf:[
		ocfDeviceType:oic.d.dishwasher, 
		name:[dishwasher] Samsung, 
		specVersion:core.1.1.0, 
		verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		manufacturerName:Samsung Electronics, 
		modelNumber:DA_DW_A51_20_COMMON|30007242|40010201001311000101000000000000, 
		platformVersion:DAWIT 2.0, 
		platformOS:TizenRT 1.0 + IPv6, hwVersion:ARTIK051, 
		firmwareVersion:DA_DW_A51_20_COMMON_30220418, 
		vendorId:DA-WM-DW-000001, 
		vendorResourceClientServerVersion:ARTIK051 Release 2.210224.1, 
		lastSignupTime:2021-06-20T02:28:38.121470Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]






Installation and Test Procedure
Install driver code and save, per the HubiThings general instructions.
After installation, open a logging window.
In preferences, select "enabldebug logging for 30 minutes" and Save Preferences
wait 10 seconds
Do a Refresh command on the device's edit page.
Copy logs for the DEVICE (not the app) and place in a return message to me.  (used for me to validate attributes are being properly captured.)
Functional Testing can wait until you run dishwasher - or do a rinse cycle.

Functional definition:
commands 
Refresh - sends a device refresh to SmartThings
On/Off - Dishwasher panel on/off
setWashingCourse(course)- look at state.supportedDishwasherCourses for a list of courses
toggleWashingCourse - toggles through the supported courses and sets.
startWashingCourse(course)
resume, start, pause - control dishwasher operation.  May require lockState to be true.
startLater(delay) - I do not know the delay unit.  probably minutes.

attributes
switch = on or off
lockState = true or false
washingCourse = selected course
operatingState
operationTime
remainingTime
timeLeftToStart
dishwasherJobState = current cycle state (i.e., rinse, wash....)




















*/
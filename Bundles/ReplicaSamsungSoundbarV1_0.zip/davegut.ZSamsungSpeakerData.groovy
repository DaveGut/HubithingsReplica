metadata {
	definition (name: "Z Samsung Speaker Data",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
	preferences {
		}
	}

/*
Cap defs:[
	["id":"refresh","version":1,"status":"live","name":"Refresh","ephemeral":false,"attributes":[],"commands":["refresh":["name":"refresh","arguments":[]]]]
	["id":"switch","version":1,"status":"live","name":"Switch","ephemeral":false,"attributes":["switch":["schema":["type":"object","properties":["value":["title":"SwitchState","type":"string","enum":["on","off"]]],"additionalProperties":false,"required":["value"]],"enumCommands":[["command":"on","value":"on"],["command":"off","value":"off"]]]],"commands":["off":["name":"off","arguments":[]],"on":["name":"on","arguments":[]]]]
	["id":"audioVolume","version":1,"status":"live","name":"Audio Volume","ephemeral":false,"attributes":["volume":["schema":["title":"IntegerPercent","type":"object","properties":["value":["type":"integer","minimum":0,"maximum":100],"unit":["type":"string","enum":["%"],"default":"%"]],"additionalProperties":false,"required":["value"]],"setter":"setVolume","enumCommands":[]]],"commands":["volumeDown":["name":"volumeDown","arguments":[]],"volumeUp":["name":"volumeUp","arguments":[]],"setVolume":["name":"setVolume","arguments":[["name":"volume","optional":false,"schema":["type":"integer","minimum":0,"maximum":100]]]]]]
	["id":"audioMute","version":1,"status":"live","name":"Audio Mute","ephemeral":false,"attributes":["mute":["schema":["type":"object","properties":["value":["title":"MuteState","type":"string","enum":["muted","unmuted"]]],"additionalProperties":false,"required":["value"]],"setter":"setMute","enumCommands":[["command":"mute","value":"muted"],["command":"unmute","value":"unmuted"]]]],"commands":["setMute":["name":"setMute","arguments":[["name":"state","optional":false,"schema":["title":"MuteState","type":"string","enum":["muted","unmuted"]]]]],"mute":["name":"mute","arguments":[]],"unmute":["name":"unmute","arguments":[]]]]
	["id":"audioTrackData","version":1,"status":"proposed","name":"Audio Track Data","ephemeral":false,
	 "attributes":[
		 "totalTime":["schema":["type":"object","properties":["value":["title":"PositiveInteger","type":"integer","minimum":0]],"additionalProperties":false,"required":[]],"enumCommands":[]],
		 "audioTrackData":["schema":[
			 "type":"object",
			 "properties":[
				 "value":[
					 "title":"AudioTrackData","type":"object",
					 "additionalProperties":false,
					 "properties":[
						 "title":["title":"String","type":"string","maxLength":255],
						 "artist":["title":"String","type":"string","maxLength":255],
						 "album":["title":"String","type":"string","maxLength":255],
						 "albumArtUrl":["title":"String","type":"string","maxLength":255],
						 "mediaSource":["title":"String","type":"string","maxLength":255]],"required":["title"]]],
			 "additionalProperties":false,"required":["value"]],"enumCommands":[]],
		 "elapsedTime":["schema":["type":"object","properties":["value":["title":"PositiveInteger","type":"integer","minimum":0]],"additionalProperties":false,"required":[]],"enumCommands":[]]],
	 "commands":[]]

	[
		"id":"mediaInputSource","version":1,"status":"live","name":"Media Input Source","ephemeral":false,
		"attributes":[
			"supportedInputSources":["schema":["type":"object",
											   "properties":["value":["items":["title":"MediaSource","enum":[
												   "AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB",
												   "YouTube","aux","bluetooth","digital","melon","wifi"],"type":"string"],"type":"array"]]
											   ,"additionalProperties":false,"required":["value"]],"enumCommands":[]],
			"inputSource":["schema":["type":"object",
									 "properties":["value":["title":"MediaSource","enum":[
										 "AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube",
										 "aux","bluetooth","digital","melon","wifi"],"type":"string"]],
									 "additionalProperties":false,"required":["value"]],"setter":"setInputSource","enumCommands":[]]],
		"commands":[
			"setInputSource":["name":"setInputSource","arguments":[["name":"mode","optional":false,"schema":["title":"MediaSource","enum":["AM","CD","FM","HDMI","HDMI1","HDMI2","HDMI3","HDMI4","HDMI5","HDMI6","digitalTv","USB","YouTube","aux","bluetooth","digital","melon","wifi"],"type":"string"]]]]]]

	[
		"id":"audioNotification","version":1,"status":"live","name":"Audio Notification","ephemeral":false,
		"attributes":[],
		"commands":[
			"playTrackAndResume":[
				"name":"playTrackAndResume",
				"arguments":[
					["name":"uri","optional":false,"schema":["title":"URI","type":"string","format":"uri"]],
					["name":"level","optional":true,"schema":["type":"integer","minimum":0,"maximum":100]]]],
			"playTrackAndRestore":["name":"playTrackAndRestore","arguments":[["name":"uri","optional":false,"schema":["title":"URI","type":"string","format":"uri"]],["name":"level","optional":true,"schema":["type":"integer","minimum":0,"maximum":100]]]],"playTrack":["name":"playTrack","arguments":[["name":"uri","optional":false,"schema":["title":"URI","type":"string","format":"uri"]],["name":"level","optional":true,"schema":["type":"integer","minimum":0,"maximum":100]]]]]]

	["id":"samsungvd.soundFrom","version":1,"status":"proposed","name":"Sound From","ephemeral":false,"attributes":["mode":["schema":["type":"object","properties":["value":["type":"integer"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]],"detailName":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]]],"commands":["setSoundFrom":["name":"setSoundFrom","arguments":[["name":"mode","optional":false,"schema":["type":"integer"]],["name":"detailName","optional":true,"schema":["type":"string"]]]]]]
	["id":"samsungvd.groupInfo","version":1,"status":"proposed","name":"Group Info","ephemeral":false,"attributes":["role":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]],"channel":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]],"masterName":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]],"status":["schema":["type":"object","properties":["value":["type":"string"]],"additionalProperties":false,"required":["value"]],"enumCommands":[]]],"commands":[]
	{
		"id":"mediaPlayback","version":1,"status":"live","name":"Media Playback","ephemeral":false,
			"attributes":{
				"supportedPlaybackCommands":{"schema":{"type":"object","properties":{
					"value":{"items":{"title":"MediaPlaybackCommands","enum":["pause","play","stop","fastForward","rewind"],"type":"string"},"type":"array"}},
					"additionalProperties":false,"required":[]},"enumCommands":[]},
					"playbackStatus":{"schema":{"type":"object","properties":{"value":{"enum":["paused","playing","stopped","fast forwarding","rewinding","buffering"],
						"type":"string"}},"additionalProperties":false,"required":[]},"setter":"setPlaybackStatus",
						"enumCommands":[{"command":"play","value":"playing"},{"command":"pause","value":"paused"},{"command":"stop","value":"stopped"},
										{"command":"fastForward","value":"fast forwarding"},{"command":"rewind","value":"rewinding"}]}},
				"commands":{
					"play":{"name":"play","arguments":[]},
						"stop":{"name":"stop","arguments":[]},
							"rewind":{"name":"rewind","arguments":[]},
								"fastForward":{"name":"fastForward","arguments":[]},
									"setPlaybackStatus":{"name":"setPlaybackStatus","arguments":[{"name":"status","optional":false,"schema":{"enum":["paused","playing","stopped","fast forwarding","rewinding"],"type":"string"}}]},"pause":{"name":"pause","arguments":[]}}}
	]
	
	
Q950A_description: [
	deviceId:4e53a5c6-c6bf-6fd1-91a7-0d61dad1434d, 
	name:Living Room Soundbar, 
	label:Living Room Soundbar, 
	manufacturerName:Samsung Electronics, 
	presentationId:VD-NetworkAudio-002S, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:94382dc1-4072-43a0-89d6-bdb647fe987a, 
	ownerId:c54d0000-2eaf-0992-d300-5a5f376802cc, 
	roomId:de3043c5-149a-48c5-8f63-a5d3dbb7f427, 
	deviceTypeName:Samsung OCF Network Audio Player, 
	components:[
		[
			id:main, label:main,
			capabilities:[
				[id:ocf, version:1],
				[id:execute, version:1],
				[id:refresh, version:1],
				[id:switch, version:1],
				[id:audioVolume, version:1],
				[id:audioMute, version:1],
				[id:audioTrackData, version:1],
				[id:mediaInputSource, version:1],
				[id:audioNotification, version:1],
				[id:samsungvd.soundFrom, verion:1],	//	not in Q90R
				[id:samsungvd.groupInfo, version:1]],
categories:[[name:NetworkAudio, categoryType:manufacturer]]]],
	createTime:2022-05-14T17:06:27.175Z, 
	profile:[id:d63d5864-40b7-392b-a5ca-18460598b547], 
	ocf:[
		ocfDeviceType:oic.d.networkaudio, name:Living Room Soundbar, specVersion:core.1.1.0, verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		manufacturerName:Samsung Electronics, modelNumber:HW-Q950A, platformVersion:5.5, platformOS:Tizen, hwVersion:, firmwareVersion:HW-Q950AWWB-1010.1, 
		vendorId:VD-NetworkAudio-002S, vendorResourceClientServerVersion:2.0.49, locale:, lastSignupTime:2022-05-14T17:06:19.436029Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]]

Q90R_description: [
	deviceId:1b595934-fce1-40be-9b87-176d347c1998, 
	name:[AV] Samsung Soundbar Q90R, 
	label:Soundbar, 
	manufacturerName:Samsung Electronics, 
	presentationId:VD-NetworkAudio-001S, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:2394712d-ac4c-4593-a9e8-8bf328a6eee9, 
	ownerId:fbdd684b-1593-d6f5-bc07-1dee46e8ba8e, 
	roomId:84f1507a-a061-4aa7-9bf4-ea7a7e9709ad, 
	deviceTypeName:Samsung OCF Network Audio Player, 
	components:[
		[
			id:main, label:Soundbar, 
			capabilities:[
				[id:ocf, version:1],
				[id:execute, version:1],
				[id:refresh, version:1],
				[id:switch, version:1],
				[id:audioVolume, version:1],
				[id:audioMute, version:1],
				[id:audioTrackData, version:1],		//	Not in MS650
				[id:mediaInputSource, version:1],	//	Not in MS650
				[id:mediaPlayback, version:1], 		//  Not in Q950
				[id:audioNotification, version:1],
				[id:samsungvd.groupInfo, version:1]],
			categories:[
				[name:NetworkAudio, categoryType:manufacturer]]]],
	createTime:2019-10-31T12:28:35Z, 
	profile:[id:d4639d48-e626-3a72-a6af-bbf136b29494], 
	ocf:[
		ocfDeviceType:oic.d.networkaudio,name:[AV] Samsung Soundbar Q90R, specVersion:core.1.1.0, verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		 manufacturerName:Samsung Electronics, modelNumber:Q90R,platformVersion:Tizen 4.0, platformOS:4.1.10,hwVersion:0-0, firmwareVersion:HW-Q90RWWB-1012.6, 
		 vendorId:VD-NetworkAudio-001S, vendorResourceClientServerVersion:1.2, locale:KO, lastSignupTime:2021-01-16T05:57:38.962238Z], 
	type:OCF, restrictionTier:0, 
	allowed:[]]

MS650_description: [
	deviceId:bb6a194e-d190-4e8f-9304-d9e9d228c2ce, 
	name:[AV] Samsung Soundbar MS650, 
	label:[AV] Soundbar, 
	manufacturerName:Samsung Electronics, 
	presentationId:VD-NetworkAudio-2017, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:3194e04d-4739-44dc-b21b-fa4094c7945c, 
	ownerId:8e3c430a-9e98-4730-96e4-eb63f59720da, 
	roomId:9ed45669-5439-4619-af16-19befaaa8049, 
	deviceTypeName:Samsung OCF Network Audio Player, 
	components:[
		[
			id:main, 
			label:main, 
			capabilities:[
				[id:ocf, version:1], 
				[id:execute, version:1], 
				[id:refresh, version:1], 
				[id:switch, version:1], 
				[id:audioVolume, version:1], 
				[id:audioMute, version:1], 
				[id:mediaPlayback, version:1], 
				[id:audioNotification, version:1]], 
			categories:[[name:NetworkAudio, categoryType:manufacturer]]]], 
	createTime:2022-10-07T11:35:35.824Z, 
	profile:[id:e97dfd0f-15de-3c31-a3b4-f5c6db248a48], 
	ocf:[
		ocfDeviceType:oic.d.networkaudio, name:[AV] Samsung Soundbar MS650, specVersion:core.1.1.0, verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		manufacturerName:Samsung Electronics, modelNumber:MS650, platformVersion:Tizen , platformOS:4.1.10, hwVersion:0-0, firmwareVersion:HW-MS650WWB-1147.2, 
		vendorId:VD-NetworkAudio-2017, vendorResourceClientServerVersion:1.2, locale:KO, lastSignupTime:2022-10-07T11:35:33.566523Z], 
	type:OCF, restrictionTier:0, 
	allowed:null]

Q90R_status: [
	components:[
		main:[
			mediaPlayback:[
				supportedPlaybackCommands:[value:[play, pause, stop], timestamp:2021-01-16T05:57:39.864Z], 
				playbackStatus:[value:stopped, timestamp:2022-08-07T09:12:54.279Z]], 
			samsungvd.groupInfo:[
				role:[value:none, timestamp:2022-08-06T12:38:18.675Z], 
				masterName:[value:, timestamp:2021-01-16T05:57:39.892Z], 
				status:[value:single, timestamp:2022-08-06T12:38:18.675Z]], 
			audioVolume:[
				volume:[value:9, unit:%, timestamp:2022-08-08T11:40:48.486Z]], 
			ocf:[
				st:[value:NONE, timestamp:2019-09-13T04:29:09.666Z], mndt:[value:2018-01-01, timestamp:2019-09-13T04:29:09.748Z], 
				mnfv:[value:HW-Q90RWWB-1012.6, timestamp:2021-01-16T05:57:39.069Z], mnhw:[value:0-0, timestamp:2019-09-13T04:29:09.708Z], 
				di:[value:1b595934-fce1-40be-9b87-176d347c1998, timestamp:2019-09-13T04:29:09.819Z], 
				mnsl:[value:http:www.samsung.com/sec/audio-video/, timestamp:2019-09-13T04:29:09.680Z], 
				dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2019-09-13T04:29:09.832Z], n:[value:[AV] Samsung Soundbar Q90R, timestamp:2019-09-13T04:29:09.856Z], 
				mnmo:[value:Q90R, timestamp:2019-09-13T04:29:09.761Z], 
				
				vid:[value:VD-NetworkAudio-001S, timestamp:2019-09-13T04:29:09.651Z], 

				mnmn:[value:Samsung Electronics, timestamp:2019-09-13T04:29:09.785Z], mnml:[value:http:www.samsung.com, timestamp:2019-09-13T04:29:09.772Z], 
				mnpv:[value:Tizen 4.0, timestamp:2019-09-13T04:29:09.735Z], mnos:[value:4.1.10, timestamp:2019-09-13T04:29:09.721Z], 
				pi:[value:1b595934-fce1-40be-9b87-176d347c1998, timestamp:2019-09-13T04:29:09.798Z], icv:[value:core.1.1.0, timestamp:2019-09-13T04:29:09.844Z]], 
			mediaInputSource:[
				supportedInputSources:[value:[wifi, bluetooth, HDMI1, HDMI2, digital], timestamp:2021-01-16T09:15:30.863Z], 
				inputSource:[value:HDMI1, timestamp:2022-08-08T07:04:33.622Z]], 
			refresh:[:], 
			audioMute:[
				mute:[value:muted, timestamp:2022-08-08T13:21:16.874Z]], 
			audioNotification:[:], 
			execute:[
				data:[value:[
					payload:[
						x.com.samsung.networkaudio.updateVersion:noValue, 
						if:[oic.if.rw, oic.if.baseline], 
						x.com.samsung.networkaudio.updateStatus:noupdate, 
						x.com.samsung.networkaudio.updateErrorEvent:CURL35, 
						x.com.samsung.networkaudio.updateProgress:-1, 
						rt:[x.com.samsung.networkaudio.swUpdate]]], 
					  data:[:], timestamp:2021-01-15T18:55:54.102Z]], 
			switch:[
				switch:[value:off, timestamp:2022-08-08T13:21:16.837Z]], 
			audioTrackData:[
				totalTime:[value:null, timestamp:2020-06-03T11:19:59.291Z],
				audioTrackData:[value:[title:, artist:], timestamp:2022-07-24T11:11:49.207Z],
				elapsedTime:[value:null, timestamp:2020-06-03T11:19:59.291Z]]]]]

Q950A_status: [
	components:[
		main:[
			mediaPlayback:[
				supportedPlaybackCommands:[value:[play, pause, stop], timestamp:2022-05-14T17:06:28.765Z],
				playbackStatus:[value:stopped, timestamp:2022-05-14T17:06:28.765Z]], 
			samsungvd.groupInfo:[
				role:[value:null], 
				masterName:[value:null], 
				status:[value:null]], 
			samsungvd.soundFrom:[
				mode:[value:3, timestamp:2022-06-08T12:37:37.278Z],
				detailName:[value:External Device, timestamp:2022-06-08T12:37:35.775Z]],
			audioVolume:[
				volume:[value:12, unit:%, timestamp:2022-06-08T12:49:14.338Z]], 
			ocf:[
				st:[value:1970-01-01T00:00:34Z, timestamp:2022-05-14T17:06:27.503Z], mndt:[value:2021-01-01, timestamp:2022-05-14T17:06:27.503Z], 
				 mnfv:[value:HW-Q950AWWB-1010.1, timestamp:2022-05-14T17:06:27.503Z], mnhw:[value:, timestamp:2022-05-14T17:06:27.503Z], 
				 di:[value:4e53a5c6-c6bf-6fd1-91a7-0d61dad1434d, timestamp:2022-05-14T17:06:27.503Z], mnsl:[value:, timestamp:2022-05-14T17:06:27.503Z], 
				 dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-05-14T17:06:27.503Z], n:[value:Living Room Soundbar, timestamp:2022-05-14T17:06:27.503Z], 
				 mnmo:[value:HW-Q950A, timestamp:2022-05-14T17:06:27.503Z], 
				 vid:[value:VD-NetworkAudio-002S, timestamp:2022-05-14T17:06:27.503Z], 
				 mnmn:[value:Samsung Electronics, timestamp:2022-05-14T17:06:27.503Z], mnml:[value:, timestamp:2022-05-14T17:06:27.503Z], 
				 mnpv:[value:5.5, timestamp:2022-05-14T17:06:27.503Z], mnos:[value:Tizen, timestamp:2022-05-14T17:06:27.503Z], 
				 pi:[value:4e53a5c6-c6bf-6fd1-91a7-0d61dad1434d, timestamp:2022-05-14T17:06:27.503Z], icv:[value:core.1.1.0, timestamp:2022-05-14T17:06:27.503Z]], 
			mediaInputSource:[
				supportedInputSources:[value:[digital, HDMI1, bluetooth, HDMI2, wifi], timestamp:2022-05-14T17:06:28.735Z], 
				inputSource:[value:HDMI1, timestamp:2022-06-08T12:37:36.923Z]], 
			refresh:[:], 
			audioMute:[
				mute:[value:unmuted, timestamp:2022-06-08T17:13:49.737Z]], 
			audioNotification:[:], 
			execute:[data:[value:null]], 
			switch:[
				switch:[value:on, timestamp:2022-06-08T17:13:48.591Z]], 
			audioTrackData:[
				totalTime:[value:0, timestamp:2022-05-14T17:06:28.778Z], 
				audioTrackData:[value:[title:, artist:, album:], timestamp:2022-05-14T17:06:28.778Z], 
				elapsedTime:[value:0, timestamp:2022-05-14T17:06:28.793Z]]]]]]

MS650_status: [
	components:[main:[
		mediaPlayback:[
			supportedPlaybackCommands:[value:[play, pause, stop], timestamp:2022-10-07T11:35:37.700Z], 
			playbackStatus:[value:playing, timestamp:2022-10-27T11:38:00.048Z]], 
		audioVolume:[volume:[value:14, unit:%, timestamp:2023-01-07T04:06:03.894Z]], 
		ocf:[
			st:[value:NONE, timestamp:2022-10-07T11:35:37.772Z], mndt:[value:2017-01-01, timestamp:2022-10-07T11:35:37.772Z], mnfv:[value:HW-MS650WWB-1147.2, timestamp:2022-10-07T11:35:37.772Z], 
			mnhw:[value:0-0, timestamp:2022-10-07T11:35:37.772Z], di:[value:bb6a194e-d190-4e8f-9304-d9e9d228c2ce, timestamp:2022-10-07T11:35:37.772Z], 
			mnsl:[value:http:www.samsung.com/sec/audio-video/, timestamp:2022-10-07T11:35:37.772Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-10-07T11:35:37.772Z], 
			n:[value:[AV] Samsung Soundbar MS650, timestamp:2022-10-07T11:35:37.772Z], mnmo:[value:MS650, timestamp:2022-10-07T11:35:37.772Z], 
			vid:[value:VD-NetworkAudio-2017, timestamp:2022-10-07T11:35:37.772Z], mnmn:[value:Samsung Electronics, timestamp:2022-10-07T11:35:37.772Z], 
			mnml:[value:http:www.samsung.com, timestamp:2022-10-07T11:35:37.772Z], mnpv:[value:Tizen , timestamp:2022-10-07T11:35:37.772Z], mnos:[value:4.1.10, timestamp:2022-10-07T11:35:37.772Z], 
			pi:[value:bb6a194e-d190-4e8f-9304-d9e9d228c2ce, timestamp:2022-10-07T11:35:37.772Z], icv:[value:core.1.1.0, timestamp:2022-10-07T11:35:37.772Z]], 
		refresh:[:], 
		audioMute:[mute:[value:unmuted, timestamp:2023-01-07T12:13:15.281Z]], 
		audioNotification:[:], 
		execute:[data:[value:null]], 
		switch:[switch:[value:on, timestamp:2023-01-07T10:06:40.410Z]]]]]



*/
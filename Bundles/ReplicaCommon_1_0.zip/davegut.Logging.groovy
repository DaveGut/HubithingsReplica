library (
	name: "Logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging Methods",
	category: "utilities",
	documentationLink: ""
)

//	Logging during development
def listAttributes(trace = false) {
	def attrs = device.getSupportedAttributes()
	def attrList = [:]
	attrs.each {
		def val = device.currentValue("${it}")
		attrList << ["${it}": val]
	}
	if (trace == true) {
		logInfo("Attributes: ${attrList}")
	} else {
		logDebug("Attributes: ${attrList}")
	}
}

def logTrace(msg){
	if (traceLog == true) {
		log.trace "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def traceLogOff() {
	device.updateSetting("traceLog", [type:"bool", value: false])
	logInfo("traceLogOff")
}

def logInfo(msg) { 
	if (textEnable || infoLog) {
		log.info "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def debugLogOff() {
	device.updateSetting("logEnable", [type:"bool", value: false])
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable || debugLog) {
		log.debug "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def logWarn(msg) { log.warn "${device.displayName}-${driverVer()}: ${msg}" }

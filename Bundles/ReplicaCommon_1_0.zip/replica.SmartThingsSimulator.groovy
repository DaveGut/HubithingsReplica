library (
	name: "SmartThingsSimulator",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "ST Replica Simulator",
	category: "utilities",
	documentationLink: ""
)
//def simulatedDevice() { return "range" }
//def simulatedDevice() { return "washer" }
def simulatedDevice() { return "dryer" }
//ovenCavityStatus
def simulateSmartDeviceDescription(String deviceId) {
	def description = null
	if (simulatedDevice() == "range") {
		description = simulatedRangeDesc()
	} else if (simulatedDevice() == "washer") {
		description = simulatedWasherDesc()
	} else if (simulatedDevice() == "dryer") {
		description = simulatedDryerDesc()
	}
		
	getReplicaDevices(deviceId)?.each { replicaDevice -> smartDescriptionHandler(replicaDevice, description); }
	description = null
}

def simulatedDryerDesc() {
Map description = [
	name:"[dryer] Samsung", 
	label:"Dryer", 
	deviceId:"3047d02b-c0aa-48be-ae09-9d0f6afee091",
	deviceTypeName:"Samsung OCF Dryer", 
	components:[
		[id:"main", label:"main",
		 capabilities:[
			 [id:"ocf", version:1],
			 [id:"execute", version:1], 
			 [id:"refresh", version:1], 
			 [id:"switch", version:1], 
			 [id:"remoteControlStatus", version:1], 
			 [id:"dryerOperatingState", version:1], 
			 [id:"powerConsumptionReport", version:1], 
			 [id:"custom.disabledCapabilities", version:1], 
			 [id:"custom.dryerDryLevel", version:1], 
			 [id:"custom.dryerWrinklePrevent", version:1], 
			 [id:"custom.jobBeginningStatus", version:1], 
			 [id:"custom.supportedOptions", version:1], 
			 [id:"samsungce.detergentOrder", version:1], 
			 [id:"samsungce.detergentState", version:1], 
			 [id:"samsungce.deviceIdentification", version:1], 
			 [id:"samsungce.driverVersion", version:1], 
			 [id:"samsungce.dryerAutoCycleLink", version:1], 
			 [id:"samsungce.dryerCycle", version:1], 
			 [id:"samsungce.dryerCyclePreset", version:1], 
			 [id:"samsungce.dryerDelayEnd", version:1], 
			 [id:"samsungce.dryerDryingTemperature", version:1], 
			 [id:"samsungce.dryerDryingTime", version:1], 
			 [id:"samsungce.dryerFreezePrevent", version:1], 
			 [id:"samsungce.kidsLock", version:1], 
			 [id:"samsungce.welcomeMessage", version:1]],
		 categories:[[name:"Dryer", categoryType:"manufacturer"]]]], 
	createTime:"2022-03-28T19:39:24.986Z", 
	profile:[id:"c89de99f-2730-3a8f-882f-49a2c488be46"], 
	type:"OCF", restrictionTier:0, allowed:[]
]
	return description
}

def simulatedWasherDesc() {
Map description = [
	name:"[washer] Samsung", label:"Washer",
	deviceId:"3047d02b-c0aa-48be-ae09-9d0f6afee091",
	deviceTypeName:"Samsung OCF Washer", 
	components:[
		[id:"main", label:"main", 
		 capabilities:[
			 [id:"execute", version:1], [id:"ocf", version:1], [id:"powerConsumptionReport", version:1], 
			 [id:"refresh", version:1], [id:"remoteControlStatus", version:1], [id:"switch", version:1], 
			 [id:"washerOperatingState", version:1], [id:"custom.disabledCapabilities", version:1], 
			 [id:"custom.dryerDryLevel", version:1], [id:"custom.jobBeginningStatus", version:1], 
			 [id:"custom.supportedOptions", version:1], [id:"custom.washerAutoDetergent", version:1], 
			 [id:"custom.washerAutoSoftener", version:1], [id:"custom.washerRinseCycles", version:1], 
			 [id:"custom.washerSoilLevel", version:1], [id:"custom.washerSpinLevel", version:1], 
			 [id:"custom.washerWaterTemperature", version:1], [id:"samsungce.autoDispenseDetergent", version:1], 
			 [id:"samsungce.autoDispenseSoftener", version:1], [id:"samsungce.detergentOrder", version:1], 
			 [id:"samsungce.detergentState", version:1], [id:"samsungce.deviceIdentification", version:1], 
			 [id:"samsungce.driverVersion", version:1], [id:"samsungce.kidsLock", version:1], 
			 [id:"samsungce.softenerOrder", version:1], [id:"samsungce.softenerState", version:1], 
			 [id:"samsungce.washerBubbleSoak", version:1], [id:"samsungce.washerCycle", version:1], 
			 [id:"samsungce.washerCyclePreset", version:1], [id:"samsungce.washerDelayEnd", version:1], 
			 [id:"samsungce.washerFreezePrevent", version:1], [id:"samsungce.washerWashingTime", version:1], 
			 [id:"samsungce.washerWaterLevel", version:1], [id:"samsungce.washerWaterValve", version:1], 
			 [id:"samsungce.welcomeMessage", version:1], [id:"samsungce.waterConsumptionReport", version:1]], 
		 categories:[[name:"Washer", categoryType:"manufacturer"]]]
	], 
	createTime:"2022-03-28T19:35:56.255Z", profile:[id:"b2c7d635-7f8a-3f3f-b431-36d81ac62eee"], 
	type:OCF, restrictionTier:0, allowed:[]]
	return description
}

def simulatedRangeDesc() {
	Map description = [
	name:"[Range] Samsung", 
	label:"Range", 
	deviceId:"3047d02b-c0aa-48be-ae09-9d0f6afee091",
	components:[
		[
			id:"main", label:"Range", 
			capabilities:[
				[id:"ocf", version:1], 
				[id:"execute", version:1], 
				[id:"refresh", version:1], 
				[id:"remoteControlStatus", version:1], 
				[id:"ovenSetpoint", version:1], 
				[id:"ovenMode", version:1], 
				[id:"ovenOperatingState", version:1], 
				[id:"temperatureMeasurement", version:1], 
				[id:"samsungce.driverVersion", version:1], 
				[id:"samsungce.kitchenDeviceIdentification", version:1], 
				[id:"samsungce.kitchenDeviceDefaults", version:1], 
				[id:"samsungce.doorState", version:1], 
				[id:"samsungce.customRecipe", version:1], 
				[id:"samsungce.ovenMode", version:1], 
				[id:"samsungce.ovenOperatingState", version:1], 
				[id:"samsungce.meatProbe", version:1], 
				[id:"samsungce.lamp", version:1], 
				[id:"samsungce.kitchenModeSpecification", version:1], 
				[id:"samsungce.kidsLock", version:1], 
				[id:"custom.cooktopOperatingState", version:1], 
				[id:"custom.disabledCapabilities", version:1]], 
			categories:[[name:"Range", categoryType:"manufacturer"]]], 
		[
			id:"cavity-01", label:"1", 
			capabilities:[
				[id:"ovenSetpoint", version:1], 
				[id:"ovenMode", version:1], 
				[id:"ovenOperatingState", version:1], 
				[id:"temperatureMeasurement", version:1], 
				[id:"samsungce.ovenMode", version:1], 
				[id:"samsungce.ovenOperatingState", version:1], 
				[id:"samsungce.kitchenDeviceDefaults", version:1], 
				[id:"custom.ovenCavityStatus", version:1], 
				[id:"custom.disabledCapabilities", version:1]], 
			categories:[[name:"Other", categoryType:"manufacturer"]]]
	]
	]
	return description
}

//	operation Testing
def simulateSmartDeviceStatus(String deviceId) {
	def status = null
	if (simulatedDevice() == "range") {
		status = simulatedRangeStatus()
	} else if (simulatedDevice() == "washer") {
		status = simulatedWasherStatus()
	} else if (simulatedDevice() == "dryer") {
		status = simulatedDryerStatus()
	}

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartStatusHandler(replicaDevice, deviceId, status); }
	status = null
}

def simulatedDryerStatus() {
Map status = [
	components:[
		main:[
			"custom.dryerWrinklePrevent":[
				operatingState:[value:null], 
				dryerWrinklePrevent:[value:"off"]], 
			"samsungce.dryerDryingTemperature":[
				dryingTemperature:[value:"medium"],
				supportedDryingTemperature:[value:["none", "extraLow", "low", "mediumLow", "medium", "high"]]], 
			"samsungce.dryerCyclePreset":[
				maxNumberOfPresets:[value:10], 
				presets:[value:null]], 
			"samsungce.deviceIdentification":[:], 
			switch:[
				switch:[value:"off"]], 
			"samsungce.dryerFreezePrevent":[
				operatingState:[value:null]], 
			ocf:[:], 
			"custom.dryerDryLevel":[
				dryerDryLevel:[value:"normal",], 
				supportedDryerDryLevel:[value:["none", "damp", "less", "normal", "more", "very"]]], 
			"samsungce.dryerAutoCycleLink":[
				dryerAutoCycleLink:[value:null]], 
			"samsungce.dryerCycle":[
				dryerCycle:[value:"Table_00_Course_01"],
				supportedCycles:[:], 
				referenceTable:[:]], 
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:[
					"samsungce.dryerCyclePreset", "samsungce.detergentOrder", "samsungce.detergentState", 
					"samsungce.dryerFreezePrevent", "samsungce.welcomeMessage"]]], 
			"samsungce.driverVersion":[
				versionNumber:[value:"21082401"]], 
			"samsungce.kidsLock":[
				lockState:[value:"unlocked"]], 
			powerConsumptionReport:[
				powerConsumption:[value:[energy:626400, deltaEnergy:200, power:0, powerEnergy:0.0, persistedEnergy:0, 
										 energySaved:0, start:"2022-04-09T19:52:23Z", end:"2022-04-09T19:57:57Z"]]], 
			dryerOperatingState:[
				completionTime:[value:"2023-04-06T16:00:00Z"], 
//				machineState:[value:"stop"], 
				machineState:[value:"run"], 
				supportedMachineStates:[value:null], dryerJobState:[value:"none"]], 
			"samsungce.dryerDelayEnd":[
				remainingTime:[value:null]], 
			refresh:[:], 
			"custom.jobBeginningStatus":[
				jobBeginningStatus:[value:"ready"]], 
			execute:[], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false]], 
			"custom.supportedOptions":[
				referenceTable:[value:[id:"Table_00"]], 
				supportedCourses:[value:["01", "81"]]], 
			"samsungce.dryerDryingTime":[
				supportedDryingTime:[value:[0, 20, 30, 40, 50, 60]], 
				dryingTime:[value:0, unit:"min"]]
			]
	]
]
	return status
}

def simulatedWasherStatus() {
Map status = [
	components:[
		main:[
			"samsungce.washerDelayEnd":[
				remainingTime:[value:null],
				minimumReservableTime:[value:null]], 
			"samsungce.washerWaterLevel":[
				supportedWaterLevel:[value:null], 
				waterLevel:[value:null]], 
			"samsungce.welcomeMessage":[
				welcomeMessage:[value:null]], 
			"custom.washerWaterTemperature":[
				supportedWasherWaterTemperature:[value:["none", "tapCold", "cold", "warm", "hot", "extraHot"], timestamp:"2022-03-28T19:35:57.777Z"],
				washerWaterTemperature:[value:"warm", timestamp:"2022-04-09T13:01:33.658Z"]],
			"samsungce.autoDispenseSoftener":[
				remainingAmount:[value:null]], 
			"samsungce.autoDispenseDetergent":[
				remainingAmount:[value:null]], 
			washerOperatingState:[
//				completionTime:[value:"2023-04-03T20:00:00Z", timestamp:"2023-04-01T17:55:26.575Z"], 
				completionTime:[value:"2023-04-06T17:00:00Z", timestamp:"2023-04-01T17:55:26.575Z"], 
//				machineState:[value:"stop", timestamp:"2022-04-09T17:55:26.555Z"], 
				machineState:[value:"run", timestamp:"2022-04-09T17:55:26.555Z"], 
				washerJobState:[value:"none", timestamp:"2022-04-09T17:55:26.566Z"], 
				supportedMachineStates:[value:null]], 
			switch:[
				switch:[value:"off", timestamp:"2022-04-09T17:55:26.399Z"]], 
			"custom.disabledCapabilities":[
				disabledCapabilities:[
					value:[
						"samsungce.autoDispenseDetergent", "samsungce.autoDispenseSoftener", "samsungce.washerCyclePreset",
						"samsungce.waterConsumptionReport", "demandResponseLoadControl", "samsungce.softenerOrder",
						"samsungce.softenerState", "samsungce.washerBubbleSoak", "samsungce.washerFreezePrevent",
						"custom.dryerDryLevel", "custom.washerRinseCycles", "custom.washerSoilLevel",
						"custom.washerSpinLevel", "samsungce.washerWaterLevel", "samsungce.washerWaterValve",
						"samsungce.washerWashingTime", "custom.washerAutoDetergent", "custom.washerAutoSoftener"], 
					timestamp:"2022-06-14T21:09:10.516Z"]], 
			"custom.washerRinseCycles":[
				supportedWasherRinseCycles:[value:null], 
				washerRinseCycles:[value:null]], 
			"samsungce.kidsLock":[
				lockState:[value:"unlocked", timestamp:"2022-03-28T19:35:57.523Z"]], 
			powerConsumptionReport:[
				powerConsumption:[
					value:[
						energy:39800,
						deltaEnergy:0,
						power:0,
						powerEnergy:0.0,
						persistedEnergy:0,
						energySaved:0,
						start:"2022-04-09T17:42:42Z",
						end:"2022-04-09T17:54:58Z"],
					timestamp:"2022-04-09T17:54:58.541Z"]],
			"custom.washerSoilLevel":[
				supportedWasherSoilLevel:[value:["none", "light", "down", "normal", "up", "heavy"], timestamp:"2022-03-28T19:35:57.777Z"], 
				washerSoilLevel:[value:"normal", timestamp:"2022-03-28T19:35:57.777Z"]], 
			"samsungce.washerBubbleSoak":[
				status:[value:null]], 
			"samsungce.detergentState":[
				remainingAmount:[value:null], 
				dosage:[value:null], 
				initialAmount:[value:null], 
				detergentType:[value:null]], 
			refresh:[:], 
			"custom.jobBeginningStatus":[
				jobBeginningStatus:[value:null]], 
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:"2022-03-29T19:43:22.494Z"]], 
			"custom.washerSpinLevel":[
				washerSpinLevel:[value:"low", timestamp:"2022-04-09T16:57:37.941Z"], 
				supportedWasherSpinLevel:[value:["rinseHold", "noSpin", "low", "medium", "high", "extraHigh"], timestamp:"2022-03-28T19:35:57.777Z"]]
		]
	]
]
	return status
}

def simulatedRangeStatus() {
	Map status = [
	components:[
		"cavity-01":[
			ovenSetpoint:[
				ovenSetpoint:[value:400]],
			temperatureMeasurement:[
				temperature:[value:400, unit:"F"]],
			"custom.ovenCavityStatus":[
				ovenCavityStatus:[value:"on"]],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			ovenMode:[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "Others"]], 
				ovenMode:[value:"Bake"]],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "SteamClean", "SelfClean", "NoOperation"]], 
				ovenMode:[value:"ConvectionBake"]],
			ovenOperatingState:[
				completionTime:[value:"2021-04-12T20:03:35.698Z"],
				machineState:[value:"running"],
				progress:[value:5, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:1800]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2024-04-12T20:03:35.698Z"],
				operatingState:[value:"ready"],	
				progress:[value:55], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:"01:00:00"]],
		],
		main:[
			ovenSetpoint:[
				ovenSetpoint:[value:400]],
			temperatureMeasurement:[
				temperature:[value:400, unit:"F"]],
			"samsungce.kidsLock":[
				lockState:[value:"locked"]],
			"samsungce.lamp":[
				brightnessLevel:[value:"off"], 
				supportedBrightnessLevel:[value:["off", "high"]]],
			refresh:[:],
			remoteControlStatus:[
				remoteControlEnabled:[value:true]],
			"samsungce.doorState":[
				doorState:[value:"closed"]],
			"custom.cooktopOperatingState":[
				supportedCooktopOperatingState:[value:["BURNBABYBURN", "run", "ready"]], 
				cooktopOperatingState:[value:"ready"]],
			"samsungce.meatProbe":[
				temperatureSetpoint:[value:400, unit:"F"],
				temperature:[value:400, unit:"F"],
//				status:[value:"disconnected"]],
				status:[value:"connected"]],
			"samsungce.kitchenDeviceDefaults":[:],
			execute:[:],
			ocf:[:],
			"samsungce.customRecipe":[:], 
			"samsungce.kitchenDeviceIdentification":[:],
			"samsungce.kitchenModeSpecification":[:],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			"samsungce.driverVersion":[:],
			ovenMode:[
				supportedOvenModes:[value:["Bake", "Broil", "KeepWarm", "BreadProof", "Dehydrate"]], 
				ovenMode:[value:"Broil"]],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Bake", "Broil", "ConvectionBake", "ConvectionRoast", "KeepWarm", "BreadProof", "Dehydrate", "AirFryer"]], 
				ovenMode:[value:"ConvectionRoast"]],
			ovenOperatingState:[
				completionTime:[value:"2021-04-12T19:55:34.605Z"], 
				machineState:[value:"ready"], 
				progress:[value:5, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"ready"], 
				operationTime:[value:7200]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2024-04-12T19:55:34.605Z"], 
				operatingState:[value:"ready"], 
				progress:[value:55], 
				ovenJobState:[value:"ready"], 
				operationTime:[value:"01:50:00"]]
		]
	]]
	return status
}


//////////////////////////////////////////////
/*	===== HubiThings Replica App Changes =====
The below changes work with both live and development devices.
Issue Solved: Samsung appliances implement the capabilities based on model.
My method:	Appliance driver that is model independent using a superset of commands and attributes in the definition. 
1.	Replica Commands and Triggers.  Develop based on the superset of capabilities.
2.	Device Commands.  Normal except that where two capabilities handle the same function, design a single command for both with a priority for the samsungce.CAPABILITIES (these are the later ones for the more capable devices).
3.	Device attributes: For capabilities handling the same (essential) state, combine the attributes into a single attribute to absolutely avoid user confusion on similar states.
4.	deviceConfigure.  This new function will use the Description data and the Status data from the app to generate the deviceCapabilities list.
	1.	status.disabledCapabilities (if it esists) will filter out the description capabilities not used in the device.

//	===== new code =====
def developer() { return true }
//	Remove "//" from below.  library catches the # as live code.
//#include replica.SmartThingsSimulator
//	===== end new code =====

Map getSmartDeviceDescription(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceDescription(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceDescription($deviceId)'"
    	Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}", deviceId: deviceId, method: "getSmartDeviceDescription" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
		return response
//	===== new code =====
	}
//	===== end new code =====
}

Map getSmartDeviceStatus(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceStatus(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceStatus($deviceId)'"
	    Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}/status", deviceId: deviceId, method: "getSmartDeviceStatus" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
	    return response
//	===== new code =====
	}
//	===== end new code =====
}

*/
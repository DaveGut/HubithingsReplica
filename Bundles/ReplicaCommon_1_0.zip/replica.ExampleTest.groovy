library (
	name: "ExampleTest",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "Test Methods for replica Samsung Oven parent/children",
	category: "utilities",
	documentationLink: ""
)

def developer() { return true }
//def developer() { return false }
command "aSetAttribute", [
	[name: "attribute", type: "STRING"],
	[name: "value", type: "STRING"],
	[name: "dataType", constraints: ["int", "str"], type: "ENUM"]]
def aSetAttribute(attr, value, dataType = "str") {
	if (dataType == "int") {
		value = value.toInteger()
	}
	setEvent([attribute: attr, value: value, unit: null])
}

command "aSetRunning"
def aSetRunning() {
	setEvents([ovenMode: "Bake", ovenSetpoint: 400, operationTime: "02:00:00", operatingState: "running"])
}

command "aSetReady"
def aSetReady() {
	setEvents([ovenMode: "NoOperation", ovenSetpoint: 0, operationTime: "00:00:00", operatingState: "ready"])
}

command "aSetBasic"
def aSetBasic() {
	state.deviceCapabilities = ["refresh", "remoteControlStatus", "ovenSetpoint", 
								"ovenMode", "ovenOperatingState", "temperatureMeasurement", 
								"samsungce.doorState", "samsungce.meatProbe", 
								"samsungce.lamp", "samsungce.kidsLock", 
								"custom.cooktopOperatingState"]
}
	
command "aSetAdvanced"
def aSetAdvanced() {
	state.deviceCapabilities = ["refresh", "remoteControlStatus", "ovenSetpoint", 
								"ovenMode", "ovenOperatingState", "temperatureMeasurement", 
								"samsungce.doorState", "samsungce.ovenMode", 
								"samsungce.ovenOperatingState", "samsungce.meatProbe", 
								"samsungce.lamp", "samsungce.kidsLock", 
								"custom.cooktopOperatingState"] 
}
	

command "a1OpTime"
def a1OpTime() {
	log.info "\n\r\n\r "
	log.info "===== setOptime: ${getTestAttrs()}, ====="
	setOperationTime("01:23:44")
	setEvents([operationTime: "01:23:44"])
}

command "a2Pause"
def a2Pause() {
	log.info "\n\r\n\r "
	log.info "===== Pause: ${getTestAttrs()}, ====="
	pause()
	setEvents([operatingState: "paused"])
}

command "a3Start"
def a3Start() {
	log.info "\n\r\n\r "
	log.info "===== Start: ${getTestAttrs()}, ====="
	start()
	setEvents([operatingState: "running"])
}

//	Test Utilities
def getTestAttrs() {
	def attrs = [
		mode: device.currentValue("ovenMode"),
		setpoint: device.currentValue("ovenSetpoint"),
		opTime: device.currentValue("operationTime"),
		opState: device.currentValue("operatingState"),
		jobState: device.currentValue("ovenJobState"),
		remoteControl: device.currentValue("remoteControlEnabled"),
		lockState: device.currentValue("lockState"),
		door: device.currentValue("doorState")
		]
	return attrs
}

def getCavityStatus() {
	Map childrenStatus = [:]
	getChildDevices().each { child ->
		childrenStatus << ["${child}_DIVIDER": child.device.currentValue("ovenCavityStatus")]
	}
	return childrenStatus
}

def setEvents(eventData) {
	if (developer() == true) {
		eventData.each {
			setEvent([attribute: it.key, value: it.value, unit: null])
		}
	}
}

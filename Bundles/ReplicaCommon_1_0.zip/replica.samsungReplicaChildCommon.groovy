library (
	name: "samsungReplicaChildCommon",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "Common Methods for replica Samsung Appliances children",
	category: "utilities",
	documentationLink: ""
)
//	Version 1.0
import groovy.json.JsonSlurper

def checkCapabilities(components) {
	def componentId = getDataValue("componentId")
	def disabledCapabilities = []
	try {
		disabledCapabilities << components[componentId]["custom.disabledCapabilities"].disabledCapabilities.value
	} catch (e) { }
	def enabledCapabilities = []
	Map description = new JsonSlurper().parseText(parent.getDataValue("description"))
	def descComponent = description.components.find { it.id == componentId }
	descComponent.capabilities.each { capability ->
		if (designCapabilities().contains(capability.id) &&
			!disabledCapabilities.contains(capability.id)) {
			enabledCapabilities << capability.id
		}
	}
	state.deviceCapabilities = enabledCapabilities
	runIn(1, refreshAttributes, [data: components])
	logInfo("checkCapabilities: [disabled: ${disabledCapabilities}, enabled: ${enabledCapabilities}]")
}

def refreshAttributes(components) {
	logDebug("refreshAttributes: ${component}")
	def component = components."${getDataValue("componentId")}"
	component.each { capability ->
		capability.value.each { attribute ->
			parseEvent([capability: capability.key,
						attribute: attribute.key,
						value: attribute.value.value,
						unit: attribute.value.unit])
			pauseExecution(100)
		}
	}
	listAttributes(false)
}

void parentEvent(Map event) {
	if (event.deviceEvent.componentId == getDataValue("componentId")) {
		try {
			parseEvent(event.deviceEvent)
		} catch (err) {
			logWarn("replicaEvent: [event = ${event}, error: ${err}")
		}
	}
}

//	===== Device Commands =====
def refresh() { parent.refresh() }

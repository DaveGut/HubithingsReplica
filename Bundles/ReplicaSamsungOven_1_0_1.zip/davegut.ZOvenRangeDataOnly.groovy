metadata {
	definition (name: "Z Oven-Range Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

/*

3/25 Testing


dev:47642023-03-25 05:45:05.422 PMtrace===================== END basic Control Test =========================
dev:47642023-03-25 05:45:05.418 PMtracebasicFinalAttrs: [
	mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
	 jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed]
dev:47642023-03-25 05:45:05.415 PMwarnbasic START Failed. TEST Aborted.
dev:47642023-03-25 05:45:05.406 PMtracebasicStart: [
	FinishStartTest: [
		mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
		jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed]]
dev:47642023-03-25 05:44:35.323 PMwarnbasic START with opTime Failed. Try full start command.
dev:47642023-03-25 05:44:35.305 PMtracebasicStart: [
	FinishStartTest: [
		mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
		jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed]]
dev:47642023-03-25 05:44:28.023 PMtracesetEvent: [
	attribute:ovenMode, capability:samsungce.ovenMode, componentId:main, 
	value:NoOperation, valueType:string]
dev:47642023-03-25 05:44:27.765 PMtracesetEvent: [
	attribute:ovenSetpoint, capability:ovenSetpoint, componentId:main, 
	value:0, valueType:string]
dev:47642023-03-25 05:44:27.580 PMtracesetEvent: [
	attribute:completionTime, capability:samsungce.ovenOperatingState, 
	componentId:main, value:2023-03-25T22:44:25.826Z, valueType:string]
dev:47642023-03-25 05:44:05.240 PMtracebasicSetParams: [
	priorToStart: [
		mode:ConvectionBake, setpoint:355, opTime:00:00:00, 
		opState:ready, jobState:ready, remoteControl:true, 
		kidsLock:unlocked, door:closed]]
dev:47642023-03-25 05:43:57.599 PMtracesetEvent: [
	attribute:ovenSetpoint, capability:ovenSetpoint, componentId:main, 
	value:355, valueType:string]
dev:47642023-03-25 05:43:48.863 PMtracesetEvent: [
	attribute:ovenMode, capability:samsungce.ovenMode, componentId:main, 
	value:ConvectionBake, valueType:string]
dev:47642023-03-25 05:43:48.556 PMtracesetEvent: [
	attribute:completionTime, capability:samsungce.ovenOperatingState, 
	componentId:main, value:2023-03-25T22:43:46.764Z, valueType:string]
dev:47642023-03-25 05:43:37.021 PMtrace===== start basic ControlTest: [
	mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
	jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed] =====



dev:47642023-03-25 05:42:44.047 PMtrace===================== END samsungce Control Test =========================
dev:47642023-03-25 05:42:44.042 PMtracesamsungceFinalAttrs: [
	mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
	jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed]
dev:47642023-03-25 05:42:44.038 PMwarnsamsungce START Failed. TEST Aborted.
dev:47642023-03-25 05:42:44.033 PMtracesamsungceStart: [
	FinishStartTest: [
		mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
		jobState:ready, remoteControl:true,  kidsLock:unlocked, door:closed]]
dev:47642023-03-25 05:42:27.435 PMtracesetEvent: [
	attribute:ovenMode, capability:samsungce.ovenMode, componentId:main, 
	value:NoOperation, valueType:string]
dev:47642023-03-25 05:42:27.391 PMtracesetEvent: [
	attribute:completionTime, capability:samsungce.ovenOperatingState, 
	componentId:main, value:2023-03-25T22:42:25.474Z, valueType:string]
dev:47642023-03-25 05:42:27.334 PMtracesetEvent: [
	attribute:ovenSetpoint, capability:ovenSetpoint, componentId:main, 
	value:0, valueType:string]
dev:47642023-03-25 05:42:13.967 PMtracesamsungceSetParams: [
	priorToStart: [
		mode:Bake, setpoint:333, opTime:00:00:00, opState:ready, 
		jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed]]
dev:47642023-03-25 05:41:57.485 PMtracesetEvent: [
	attribute:ovenSetpoint, capability:ovenSetpoint, componentId:main, 
	value:333, valueType:string]
dev:47642023-03-25 05:41:48.539 PMtracesetEvent: [
	attribute:ovenMode, capability:samsungce.ovenMode, componentId:main, 
	value:Bake, valueType:string]
dev:47642023-03-25 05:41:48.349 PMtracesetEvent: [
	attribute:completionTime, capability:samsungce.ovenOperatingState, 
	componentId:main, value:2023-03-25T22:41:46.568Z, valueType:string]
dev:47642023-03-25 05:41:36.817 PMtrace===== start samsungce ControlTest: [
	mode:NoOperation, setpoint:0, opTime:00:00:00, opState:ready, 
	jobState:ready, remoteControl:true, kidsLock:unlocked, door:closed] =====




---------------- TEST 1/2/3 ---------------------------
Makes the ding noice when it started, I think its just from sending in the stop. Makes the same noise if I stop it from the ST app.
Set to Bake Mode worked, could see on oven display and in driver.
Could not visually see temp being set.
Once Test 3 started going the Bake mode was canceled and nothing happend.
I tried to quickly set bake mode and temp, then run test 3 again but same thing happened.
--------------------------------------------
	
Test 1. Both ovenMode capability tests worked as evidenced by the setEvent logging.
Test 2, ovenSetpoint capability worked.  Evidenced by setEvent logging.  Note: It is taking nearly 10 seconds for Hubitat to update attributes!!!!!
Test 3A. capability samsungce.ovenOeratingState - setOvenSetpoint caused the oven to reset to noOperation state.  (will not use again). Evidence setEvent logs.
Test 3B. capability ovenOperatingState - start (with time only) did not work.  Probably because mode was noOperation.
Test 3C. logs not captured.
Test 4A. did not work.  no logging errors (accepted w/o error but did not impact operations.
Test 4B. ovenOperatingTime start with mode, time, setpoint was unprocessable entry.
Test 4C. ovenOperating time with time only was unprocessable entry.
Test 5A: did not work.
Test 5B: did not work.
Test 5C: caused unprocessable entity error.
Test 6A. Start starts at last state.
Test 6B. Start with parameters failes (already started!)

//////////////////////////////
def mainCapabilities () {
//	Capabilities in design
	def ovenSetpoint = [
		id:ovenSetpoint, version:1, 
		status:proposed, name:Oven Setpoint, ephemeral:false, 
		attributes:[
			ovenSetpoint:[
				schema:[type:object, properties:[value:[title:PositiveInteger, type:integer, minimum:0]], 
						additionalProperties:false, required:[value]], 
				setter:setOvenSetpoint, enumCommands:[]]], 
		commands:[
			setOvenSetpoint:[name:setOvenSetpoint, 
							 arguments:[[name:setpoint, optional:false, 
										 schema:[title:PositiveInteger, type:integer, minimum:0]]]]]
	]

	def ovenMode = [
		id:ovenMode, version:1, status:proposed, name:Oven Mode, ephemeral:false, 
		attributes:[
			supportedOvenModes:[
				schema:[type:object, 
						properties:[value:[
							type:array,
							items:[title:OvenMode, type:string, 
								   enum:[heating, grill, warming, defrosting, Conventional, Bake, BottomHeat,
										 ConvectionBake, ConvectionRoast, Broil, ConvectionBroil, SteamCook, 
										 SteamBake, SteamRoast, SteamBottomHeatplusConvection, Microwave, 
										 MWplusGrill, MWplusConvection, MWplusHotBlast, MWplusHotBlast2, 
										 SlimMiddle, SlimStrong, SlowCook, Proof, Dehydrate, Others]]]], 
						additionalProperties:false, required:[]], enumCommands:[]], 
			ovenMode:[
				schema:[type:object, 
						properties:[
							value:[title:OvenMode, type:string,
								   enum:[heating, grill, warming, defrosting, Conventional, Bake, BottomHeat, 
										 ConvectionBake, ConvectionRoast, Broil, ConvectionBroil, SteamCook, 
										 SteamBake, SteamRoast, SteamBottomHeatplusConvection, Microwave, 
										 MWplusGrill, MWplusConvection, MWplusHotBlast, MWplusHotBlast2, SlimMiddle, 
										 SlimStrong, SlowCook, Proof, Dehydrate, Others]]], 
						additionalProperties:false, required:[value]], 
				setter:setOvenMode, enumCommands:[]]], 
		commands:[
			setOvenMode:[
				name:setOvenMode, 
				arguments:[
					[name:mode, optional:false,
					 schema:[title:OvenMode, 
							 type:string, enum:[heating, grill, warming, defrosting, Conventional, Bake, 
												BottomHeat, ConvectionBake, ConvectionRoast, Broil, ConvectionBroil, 
												SteamCook, SteamBake, SteamRoast, SteamBottomHeatplusConvection, 
												Microwave, MWplusGrill, MWplusConvection, MWplusHotBlast, 
												MWplusHotBlast2, SlimMiddle, SlimStrong, SlowCook, Proof, 
												Dehydrate, Others]]]]]]]

	def samsungce.ovenMode = [
		id:samsungce.ovenMode, version:1, status:proposed, name:Oven Mode, ephemeral:false, 
		attributes:[
			supportedOvenModes:[
				schema:[title:Supported Oven Modes, type:object, properties:[value:[type:array, items:[type:string, enum:[AirFry, AirFryer, AirSousvide, Autocook, AutocookCustom, Bake, Bottom, BottomConvection, BottomHeat, BottomHeatPluseConvection, BreadProof, Broil, BroilCombi, BroilConvection, BroilS, CatalyticClean, ChefBake, ChefBroil, ChefProof, CleanAirPyro, Convection, ConvectionBake, ConvectionBroil, ConvectionCombi, ConvectionRoast, ConvectionSear, ConvectionVegetable, Conventional, Cookie, Defrost, DefrostA, Dehydrate, Deodorization, Descale, Drain, Drying, Easycook1, Easycook2, Easycook3, EcoConvection, EcoGrill, FanConventional, FanGrill, FavoriteCook, FavoriteRecipes, Fermentation, FineSteam, FourPartPureConvection, FourPartPureConvectionSingle, FrozenFood, FrozenMode, GreenClean, GreenCleanReal, Grill, GrillConvection, HOMECARE_WIZARD_V2, Healthycook1, Healthycook2, Healthycook3, Healthycook4, Healthycook5, Healthycook6, HotBlast, IntensiveCook, InternalClean, KeepWarm, LargeGrill, MW+HotBlast2, MemoryCook, MicroWave, MicroWaveConvection, MicroWaveFanGrill, MicroWaveGrill, MicroWaveHotBlast, MicroWaveRoast, MoistSteam, MultiGrill, MultiLevelCook, NaturalSteam, NoOperation, PizzaCook, PlateWarm, PowerBake, PowerConvection, PowerConvectionCombi, Preheat, ProConvection, ProRoasting, Proof, ProveDough, PureConvection, PureConvectionSear, PureSteam, PyroFree, Roast, Roasting, SelfClean, SlimfryMiddle, SlimfryStrong, SlowCook, SlowCookBeef, SlowCookPoultry, SlowCookStew, SmallGrill, SpeedBake, SpeedBroil, SpeedBrown, SpeedConvSear, SpeedConvection, SpeedGrill, SpeedPowerConvection, SpeedRoast, SteamAssist, SteamAutocook, SteamBake, SteamBottomConvection, SteamBreadProof, SteamClean, SteamCleanReal, SteamConvection, SteamCook, SteamProof, SteamReheat, SteamRoast, SteamTopConvection, StoneMode, ThreePartPureConvection, ToastBagle, ToastCroissant, ToastSlicedBread, TopConvection, TopHeatPluseConvection, VaporBottomHeatPluseConvection, VaporCleaning, VaporConvection, VaporGRILL, VaporMWO, VaporTopHeatPluseConvection, WarmHold]]]], additionalProperties:false, required:[value]], enumCommands:[]], 
			ovenMode:[
				schema:[title:Oven Mode, type:object, properties:[value:[type:string, enum:[AirFry, AirFryer, AirSousvide, Autocook, AutocookCustom, Bake, Bottom, BottomConvection, BottomHeat, BottomHeatPluseConvection, BreadProof, Broil, BroilCombi, BroilConvection, BroilS, CatalyticClean, ChefBake, ChefBroil, ChefProof, CleanAirPyro, Convection, ConvectionBake, ConvectionBroil, ConvectionCombi, ConvectionRoast, ConvectionSear, ConvectionVegetable, Conventional, Cookie, Defrost, DefrostA, Dehydrate, Deodorization, Descale, Drain, Drying, Easycook1, Easycook2, Easycook3, EcoConvection, EcoGrill, FanConventional, FanGrill, FavoriteCook, FavoriteRecipes, Fermentation, FineSteam, FourPartPureConvection, FourPartPureConvectionSingle, FrozenFood, FrozenMode, GreenClean, GreenCleanReal, Grill, GrillConvection, HOMECARE_WIZARD_V2, Healthycook1, Healthycook2, Healthycook3, Healthycook4, Healthycook5, Healthycook6, HotBlast, IntensiveCook, InternalClean, KeepWarm, LargeGrill, MW+HotBlast2, MemoryCook, MicroWave, MicroWaveConvection, MicroWaveFanGrill, MicroWaveGrill, MicroWaveHotBlast, MicroWaveRoast, MoistSteam, MultiGrill, MultiLevelCook, NaturalSteam, NoOperation, PizzaCook, PlateWarm, PowerBake, PowerConvection, PowerConvectionCombi, Preheat, ProConvection, ProRoasting, Proof, ProveDough, PureConvection, PureConvectionSear, PureSteam, PyroFree, Roast, Roasting, SelfClean, SlimfryMiddle, SlimfryStrong, SlowCook, SlowCookBeef, SlowCookPoultry, SlowCookStew, SmallGrill, SpeedBake, SpeedBroil, SpeedBrown, SpeedConvSear, SpeedConvection, SpeedGrill, SpeedPowerConvection, SpeedRoast, SteamAssist, SteamAutocook, SteamBake, SteamBottomConvection, SteamBreadProof, SteamClean, SteamCleanReal, SteamConvection, SteamCook, SteamProof, SteamReheat, SteamRoast, SteamTopConvection, StoneMode, ThreePartPureConvection, ToastBagle, ToastCroissant, ToastSlicedBread, TopConvection, TopHeatPluseConvection, VaporBottomHeatPluseConvection, VaporCleaning, VaporConvection, VaporGRILL, VaporMWO, VaporTopHeatPluseConvection, WarmHold]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			setOvenMode:[
				name:setOvenMode, 
				arguments:[
					[name:mode, optional:false, 
					 schema:[type:string, 
							 enum:[AirFry, AirFryer, AirSousvide, Autocook, AutocookCustom, Bake, Bottom, BottomConvection, 
								   BottomHeat, BottomHeatPluseConvection, BreadProof, Broil, BroilCombi, BroilConvection, 
								   BroilS, CatalyticClean, ChefBake, ChefBroil, ChefProof, CleanAirPyro, Convection, 
								   ConvectionBake, ConvectionBroil, ConvectionCombi, ConvectionRoast, ConvectionSear, 
								   ConvectionVegetable, Conventional, Cookie, Defrost, DefrostA, Dehydrate, Deodorization, 
								   Descale, Drain, Drying, Easycook1, Easycook2, Easycook3, EcoConvection, EcoGrill, 
								   FanConventional, FanGrill, FavoriteCook, FavoriteRecipes, Fermentation, FineSteam, 
								   FourPartPureConvection, FourPartPureConvectionSingle, FrozenFood, FrozenMode, GreenClean, 
								   GreenCleanReal, Grill, GrillConvection, HOMECARE_WIZARD_V2, Healthycook1, Healthycook2, 
								   Healthycook3, Healthycook4, Healthycook5, Healthycook6, HotBlast, IntensiveCook, 
								   InternalClean, KeepWarm, LargeGrill, MW+HotBlast2, MemoryCook, MicroWave, 
								   MicroWaveConvection, MicroWaveFanGrill, MicroWaveGrill, MicroWaveHotBlast, 
								   MicroWaveRoast, MoistSteam, MultiGrill, MultiLevelCook, NaturalSteam, NoOperation, 
								   PizzaCook, PlateWarm, PowerBake, PowerConvection, PowerConvectionCombi, Preheat, 
								   ProConvection, ProRoasting, Proof, ProveDough, PureConvection, PureConvectionSear, 
								   PureSteam, PyroFree, Roast, Roasting, SelfClean, SlimfryMiddle, SlimfryStrong, SlowCook, 
								   SlowCookBeef, SlowCookPoultry, SlowCookStew, SmallGrill, SpeedBake, SpeedBroil, SpeedBrown, 
								   SpeedConvSear, SpeedConvection, SpeedGrill, SpeedPowerConvection, SpeedRoast, SteamAssist, 
								   SteamAutocook, SteamBake, SteamBottomConvection, SteamBreadProof, SteamClean, SteamCleanReal, 
								   SteamConvection, SteamCook, SteamProof, SteamReheat, SteamRoast, SteamTopConvection, 
								   StoneMode, ThreePartPureConvection, ToastBagle, ToastCroissant, ToastSlicedBread, 
								   TopConvection, TopHeatPluseConvection, VaporBottomHeatPluseConvection, VaporCleaning, 
								   VaporConvection, VaporGRILL, VaporMWO, VaporTopHeatPluseConvection, WarmHold]]]]]]]

	def samsungce.ovenOperatingState = [
		id:samsungce.ovenOperatingState, version:1, status:proposed, name:Oven Operating State, ephemeral:false, 
		attributes:[
			completionTime:[schema:[title:ISO8601Date, type:object, properties:[value:[type:string, pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$]], additionalProperties:false, required:[value]], enumCommands:[]], 
			operatingState:[
				schema:[title:Operating State, type:object, 
						properties:[value:[type:string, enum:[ready, running, paused]]], additionalProperties:false, required:[value]], enumCommands:[]], 
			progress:[schema:[title:Progress Percentage, type:object, properties:[value:[type:integer, minimum:0]], additionalProperties:false, required:[value]], enumCommands:[]], 
			ovenJobState:[schema:[title:Oven Job State, type:object, properties:[value:[type:string, enum:[cleaning, cooking, cooling, draining, preheat, ready, rinsing, finished, scheduledStart, warming, defrosting, sensing, searing, fastPreheat, scheduledEnd, stoneHeating, timeHoldPreheat]]], additionalProperties:false, required:[value]], enumCommands:[]], 
			operationTime:[schema:[title:HH..:MM:SS, type:object, properties:[value:[type:string, 
																					 pattern:^\d\d+:[0-5]\d:[0-5]\d$]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			setOperationTime:[
				name:setOperationTime, 
				arguments:[
					[
						name:operationTime, optional:false, 
						schema:[type:string, pattern:^\d\d+:[0-5]\d:[0-5]\d$]]]], 
			stop:[name:stop, arguments:[]], 
			start:[name:start, arguments:[]], 
			pause:[name:pause, arguments:[]]]]

	def ovenOperatingState = [
		id:ovenOperatingState, version:1, status:proposed, name:Oven Operating State, ephemeral:false, 
		attributes:[
			completionTime:[
				schema:[
					type:object, 
					properties:[
						value:[
							title:Iso8601Date,
							type:string, pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)T(?:[01]\d|2[0-3]):?[0-5]\d:?[0-5]\d(?:\.\d{3})?(?:Z|[+-][01]\d(?::?[0-5]\d)?)$]], 
					additionalProperties:false, 
					required:[value]], 
				enumCommands:[]], 
			machineState:[
				schema:[
					type:object, 
					properties:[
						value:[
							type:string, 
							enum:[ready, running, paused]]], 
					additionalProperties:false, 
					required:[]], 
				setter:setMachineState, 
				enumCommands:[]], 
			progress:[
				schema:[
					title:IntegerPercent, 
					type:object, 
					properties:[
						value:[
							type:integer, 
							minimum:0, 
							maximum:100], 
						unit:[
							type:string, 
							enum:[%], 
							default:%]], 
					additionalProperties:false, 
					required:[value]], 
				enumCommands:[]], 
			supportedMachineStates:[
				schema:[
					type:object,
					properties:[
						value:[
							type:array, 
							items:[
								type:string, 
								enum:[ready, running, paused]]]], 
					additionalProperties:false, 
					required:[]], 
				enumCommands:[]], 
			ovenJobState:[
				schema:[
					type:object, 
					properties:[
						value:[
							type:string, 
							enum:[
								cleaning, cooking, cooling, draining, preheat, 
								ready, rinsing, finished, scheduledStart, warming, 
								defrosting, sensing, searing, fastPreheat, 
								scheduledEnd, stoneHeating, timeHoldPreheat]]], 
					additionalProperties:false, 
					required:[]], 
				enumCommands:[]], 
			operationTime:[
				schema:[
					type:object, 
					properties:[
						value:[
							title:PositiveInteger, 
							type:integer, 
							minimum:0]], 
					additionalProperties:false, 
					required:[]], 
				enumCommands:[]]], 
		commands:[
			stop:[
				name:stop,
				arguments:[]], 
			setMachineState:[
				name:setMachineState, 
				arguments:[
					[
						name:state, 
						optional:false, 
						schema:[
							type:string, 
							enum:[stop]]]]], 
			start:[
				name:start, 
				arguments:[
					[
						name:mode,
						optional:true,
						schema:[
							title:OvenMode, 
							type:string,
							enum:[
								heating, grill, warming, defrosting, Conventional, Bake,
								BottomHeat, ConvectionBake, ConvectionRoast, Broil,
								ConvectionBroil, SteamCook, SteamBake, SteamRoast,
								SteamBottomHeatplusConvection, Microwave, MWplusGrill,
								MWplusConvection, MWplusHotBlast, MWplusHotBlast2,
								Others]]], 
					[
						name:time, 
						optional:true,
						schema:[
							title:PositiveInteger,
							type:integer,
							minimum:0]], 
					[
						name:setpoint,
						optional:true, 
						schema:[
							title:PositiveInteger, 
							type:integer, 
							minimum:0]]]]]]

	def temperatureMeasurement = [
		id:temperatureMeasurement, version:1, status:live, name:Temperature Measurement, ephemeral:false, 
		attributes:[
			temperature:[schema:[type:object, properties:[value:[title:TemperatureValue, type:number, minimum:-460, maximum:10000], unit:[type:string, enum:[F, C]]],
								 additionalProperties:false, required:[value, unit]], enumCommands:[]]], 
		commands:[:]]
	
	//	main only
	def refresh = [
		id:refresh, version:1, status:live, name:Refresh, ephemeral:false, attributes:[:], 
		commands:[refresh:[name:refresh, arguments:[]]]]

	def custom_cooktopOperatingState = [
		id:custom.cooktopOperatingState, version:1, status:proposed, name:Cooktop Operating State, ephemeral:false, 
		attributes:[
			supportedCooktopOperatingState:[
				schema:[type:object, properties:[value:[items:[enum:[ready, run, paused, finished], type:string], type:array]], 
						additionalProperties:false, required:[value]], enumCommands:[]], 
			cooktopOperatingState:
			[schema:[type:object, properties:[value:[enum:[ready, run, paused, finished], type:string]], 
					 additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]

	def samsungce.meatProbe = [
		id:samsungce.meatProbe, version:1, status:proposed, name:Meat Probe, ephemeral:false, 
		attributes:[
			temperatureSetpoint:[
				schema:[type:object, properties:[value:[type:number, minimum:-460, maximum:10000], 
												 unit:[type:string, enum:[F, C]]], 
						additionalProperties:false, required:[value, unit]], enumCommands:[]], 
			temperature:[
				schema:[type:object, properties:[value:[type:number, minimum:-460, maximum:10000], 
												 unit:[type:string, enum:[F, C]]], 
						additionalProperties:false, required:[value, unit]], enumCommands:[]], 
			status:[
				schema:[type:object, properties:[value:[type:string, eum:[connected, disconnected]]], 
						additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			setTemperatureSetpoint:[name:setTemperatureSetpoint, 
									arguments:[[name:temperature, optional:false, 
												schema:[type:number, minimum:0]]]]]]

	def samsungce.lamp = [
		id:samsungce.lamp, version:1, status:proposed, name:Lamp, ephemeral:false, 
		attributes:[
			brightnessLevel:[
				schema:[
					type:object, 
					properties:[value:[oneOf:[
						[type:string, enum:[off, low, mid, high]], 
						[type:integer, minimum:0, maximum:100]]]], 
					additionalProperties:false, required:[value]], enumCommands:[]], 
			supportedBrightnessLevel:[
				schema:[
					type:object, 
					properties:[value:[items:[oneOf:[
						[type:string, enum:[off, low, mid, high]], 
						[type:integer, minimum:0, maximum:100]]], type:array]], 
					additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			setBrightnessLevel:[
				name:setBrightnessLevel,
				arguments:[[
					name:level, optional:false, schema:[oneOf:[
						[type:string, enum:[off, low, mid, high]], [type:integer, minimum:0, maximum:100]]]]]]]]

	def remoteControlStatus = [
		id:remoteControlStatus, version:1, status:live, name:Remote Control Status, ephemeral:false, 
		attributes:[
			remoteControlEnabled:[schema:[type:object, properties:[value:[type:string, enum:[false, true]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]

	def samsungce.doorState = [
		id:samsungce.doorState, version:1, status:proposed, name:Door State, ephemeral:false, 
		attributes:[
			doorState:[schema:[type:object, properties:[value:[type:string, enum:[closed, open]]], 
							   additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]
	
	def samsungce.kidsLock = [
		id:samsungce.kidsLock, version:1, status:proposed, name:Kids Lock, ephemeral:false, 
		attributes:[lockState:[schema:[type:object, properties:[value:[type:string, enum:[locked, unlocked, paused]]], 
									   additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]
	
	//	cavity only
	def custom.ovenCavityStatus = [
		id:custom.ovenCavityStatus, version:1, status:proposed, name:Oven Cavity Status, ephemeral:false, 
		attributes:[ovenCavityStatus:[schema:[type:object, properties:[value:[values:[on, off], default:off, type:string]], 
											  additionalProperties:false, required:[]], enumCommands:[]]], 
		commands:[:]]
	

//	Not implemented Capabilities
	//	note: disabledCapabilities is used during configuration only.
	//	No attributes nor disabledCapabilities commands are implemented.
	def custom.disabledCapabilities = [
		id:custom.disabledCapabilities, version:1, status:proposed, name:Disabled Capabilities, ephemeral:false, 
		attributes:[
			disabledCapabilities:[schema:[type:object, properties:[value:[type:array, items:[type:string]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]

	def execute = [
		id:execute, version:1, status:live, name:Execute, ephemeral:false, 
		attributes:[data:[schema:[type:object, properties:[value:[title:JsonObject, type:object], data:[type:object, additionalProperties:true, required:[]]], 
								  additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			execute:[name:execute, arguments:[
				[name:command, optional:false, schema:[title:String, type:string, maxLength:255]], 
				[name:args, optional:true, schema:[title:JsonObject, type:object]]]]]]
	
	def samsungce.customRecipe = [
		id:samsungce.customRecipe, version:1, status:proposed, name:Custom Recipe, ephemeral:false, 
		attributes:[:], 
		commands:[
			cookCustomRecipe:[name:cookCustomRecipe, arguments:[[name:payload, optional:false, schema:[type:string]]]]]]

	def samsungce.deviceIdentification = [
		id:samsungce.deviceIdentification, version:1, status:proposed, name:Device Identification, ephemeral:false, 
		attributes:[
			micomAssayCode:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			modelName:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			serialNumber:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			serialNumberExtra:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			modelClassificationCode:[schema:[type:object, properties:[value:[type:string, pattern:^([0-9a-fA-F]){32}$]], additionalProperties:false, required:[value]], enumCommands:[]], 
			description:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			binaryId:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]

	def samsungce.kitchenModeSpecification = [
		id:samsungce.kitchenModeSpecification, version:1, status:proposed, name:Kitchen Mode Specification, ephemeral:false, 
		attributes:[specification:[schema:[type:object, properties:[value:[type:object, additionalProperties:false, patternProperties:[^(single|lower|upper)$:[type:array, items:[type:object, required:[mode],properties:[mode:[type:string], supportedOperations:[type:array, items:[type:string, enum:[start, set]]], supportedOptions:[type:object, patternProperties:[^(temperature|probeTemperature)$:[type:object, additionalProperties:false, patternProperties:[^[CF]$:[type:object, additionalProperties:false, patternProperties:[^(min|max|resolution|default)$:[type:number]], properties:[supportedValues:[type:array, items:[type:number]]]]]]], properties:[powerLevel:[type:object, additionalProperties:false, properties:[supportedValues:[type:array, items:[type:string]], default:[type:string]]], operationTime:[type:object, additionalProperties:false, patternProperties:[^(min|max|resolution|default)$:[type:string, pattern:^\d\d+:[0-5]\d:[0-5]\d$]]]]]]]]], examples:[[single:[[mode:Convection, supportedOperations:[set], supportedOptions:[temperature:[F:[min:300, max:500, default:350, resolution:5], C:[min:100, max:250, default:180, supportedValues:[100, 180, 250]]], operationTime:[min:00:00:01, max:11:59:59, default:00:30:00, resolution:00:00:01], probeTemperature:[C:[min:30, max:90, default:50, resolution:5]]]]]]]]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]

	def samsungce.softwareUpdate = [
		id:samsungce.softwareUpdate, version:1, status:proposed, name:Software Update, ephemeral:false, 
		attributes:[targetModule:[schema:[type:object, properties:[value:[type:object, properties:[newVersion:[type:string], currentVersion:[type:string], moduleType:[type:string, enum:[mainController, display, inverter, indoorUnit, outdoorUnit]]]]], additionalProperties:false, required:[value]], enumCommands:[]], otnDUID:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], lastUpdatedDate:[schema:[type:object, properties:[value:[type:string, pattern:^(?:[1-9]\d{3}-?(?:(?:0[1-9]|1[0-2])-?(?:0[1-9]|1\d|2[0-8])|(?:0[13-9]|1[0-2])-?(?:29|30)|(?:0[13578]|1[02])-?31)|(?:[1-9]\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-?02-?29)]], additionalProperties:false, required:[value]], enumCommands:[]], availableModules:[schema:[type:object, properties:[value:[type:array, items:[type:string]]], additionalProperties:false, required:[value]], enumCommands:[]], newVersionAvailable:[schema:[type:object, properties:[value:[type:boolean]], additionalProperties:false, required:[value]], enumCommands:[]], operatingState:[schema:[type:object, properties:[value:[type:string, enum:[none, available, preparing, delayed, inprogress, completed]]], additionalProperties:false, required:[value]], enumCommands:[]], progress:[schema:[type:object, properties:[value:[type:integer, minimum:0, maximum:100], unit:[type:string, enum:[%], default:%]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[
			agreeUpdate:[name:agreeUpdate, arguments:[[name:module, optional:true, schema:[type:string]]]], 
			disagreeUpdate:[name:disagreeUpdate, arguments:[[name:module, optional:true, schema:[type:string]]]]]]
	
	def samsungce.kitchenDeviceDefaults = [
		id:samsungce.kitchenDeviceDefaults, version:1, status:proposed, name:Kitchen Device Defaults, ephemeral:false, 
		attributes:[
			defaultOperationTime:[schema:[type:object, properties:[value:[type:integer, minimum:0]], additionalProperties:false, required:[]], enumCommands:[]], 
			defaultOvenMode:[schema:[type:object, properties:[value:[type:string]], additionalProperties:false, required:[value]], enumCommands:[]], 
			defaultOvenSetpoint:[schema:[type:object, properties:[value:[type:integer, minimum:0]], additionalProperties:false, required:[value]], enumCommands:[]]], 
		commands:[:]]
	
}





def SimulatedStatus = [
	components:[
		cavity-01:[
			ovenSetpoint:[
				ovenSetpoint:[value:325]],
			temperatureMeasurement:[
				temperature:[value:325, unit:"F"]],
			ovenMode:[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "Others"]], 
				ovenMode:[value:"Bake"]]
			ovenOperatingState:[
				completionTime:[value:"2022-04-12T20:03:35.698Z"],
				machineState:[value:"running"]
				progress:[value:5, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:3600]],
			"custom.ovenCavityStatus":[
				ovenCavityStatus:[value:"on",]],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "SteamClean", "SelfClean", "NoOperation"]], 
				ovenMode:[value:"Bake"]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2022-04-12T20:03:35.698Z"],
				operatingState:[value:"running"],	
				progress:[value:5], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:"01:00:00"]],
		],
		main:[
			ovenSetpoint:[
				ovenSetpoint:[value:"325"]],
			temperatureMeasurement:[
				temperature:[value:"325", unit:"F"]],
			ovenMode:[
				supportedOvenModes:[value:["Broil", "ConvectionBake", "ConvectionRoast"]],
				ovenMode:[value:"ConvectionBake"]]
			ovenOperatingState:[
				completionTime:[value:"2022-04-12T19:55:34.605Z"], 
				machineState:[value:"running"], 
				progress:[value:6, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"cooking"], 
				operationTime:[value:3120]],
			"samsungce.kidsLock":[
				lockState:[value:"unlocked"]],
			"samsungce.lamp":[
				brightnessLevel:[value:"off"], 
				supportedBrightnessLevel:[value:["off", "high"]]],
			refresh:[:],
			remoteControlStatus:[
				remoteControlEnabled:[value:false]],
			"samsungce.doorState":[
				doorState:[value:"closed"]],
			"custom.cooktopOperatingState":[
				supportedCooktopOperatingState:[value:["run", "ready"]], 
				cooktopOperatingState:[value:"ready"]],
			"samsungce.meatProbe":[
				temperatureSetpoint:[value:0, unit:"F"],
				temperature:[value:0, unit:"F"],
				status:[value:"disconnected"]],
			"samsungce.kitchenDeviceDefaults":[:],
			execute:[:],
			ocf:[:],
			"samsungce.customRecipe":[:], 
			"samsungce.kitchenDeviceIdentification":[:],
			"samsungce.kitchenModeSpecification":[:],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			"samsungce.driverVersion":[:],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Broil", "ConvectionBake", "ConvectionRoast"]], 
				ovenMode:[value:"ConvectionBake"]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2022-04-12T19:55:34.605Z"], 
				operatingState:[value:"running"], 
				progress:[value:6], 
				ovenJobState:[value:"cooking"], 
				operationTime:[value:"00:52:00"]],
		]
	]
]

	


//	JTP10181 Status Data (MAIN ONLY)

def main = [
	custom.cooktopOperatingState:[
		cooktopOperatingState:[timestamp:2023-02-24T15:44:53.181Z, value:ready], 
		supportedCooktopOperatingState:[timestamp:2022-09-07T05:08:46.144Z, value:[run, ready]]], 
	custom.disabledCapabilities:[disabledCapabilities:[timestamp:2021-07-05T01:15:09.933Z, value:[]]], 
	execute:[
		data:[
			data:[href:/mode/vs/0], timestamp:2023-02-24T16:13:04.242Z, 
			value:[
				payload:[
					if:[oic.if.baseline, oic.if.a], rt:[x.com.samsung.da.mode], x.com.samsung.da.defaultMode:ConvectionBake, 
					x.com.samsung.da.modeSpec:[
						{"mode":"Bake","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"80","tempMaxC":"285",
							"tempDefaultC":"175","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"350","tempListLengthF":"0",
							"timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported",
							"probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported",
							"powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"Broil","version":"0000","default":"Normal","control":"Setting",
							"cavity":"Single","tempMinC":"61442","tempMaxC":"61441","tempDefaultC":"61441","tempListLengthC":"0","tempMinF":"61442",
							"tempMaxF":"61441","tempDefaultF":"61441","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported",
							"timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported",
							"probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported",
							"powerListLength":"0"},
						{"mode":"ConvectionBake","version":"0000","default":"Default","control":"Start&Setting","cavity":"Single",
							"tempMinC":"80","tempMaxC":"285","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"325",
							"tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported",
							"probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported",
							"probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"ConvectionRoast","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"80",
							"tempMaxC":"285","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"325",
							"tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported",
							"probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported",
							"probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"KeepWarm","version":"0000","default":"Normal","control":"NotSupported","cavity":"Single","tempMinC":"80","tempMaxC":"80",
							"tempDefaultC":"80","tempListLengthC":"0","tempMinF":"175","tempMaxF":"175","tempDefaultF":"175","tempListLengthF":"0",
							"timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported",
							"probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported",
							"powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"BreadProof","version":"0000","default":"Normal","control":"NotSupported",
							"cavity":"Single","tempMinC":"35","tempMaxC":"35","tempDefaultC":"35","tempListLengthC":"0","tempMinF":"95","tempMaxF":"95",
							"tempDefaultF":"95","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported",
							"probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported",
							"probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"Dehydrate","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"40","tempMaxC":"105",
							"tempDefaultC":"65","tempListLengthC":"0","tempMinF":"100","tempMaxF":"225","tempDefaultF":"150","tempListLengthF":"0",
							"timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported",
							"probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported",
								"powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"AirFryer","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"175","tempMaxC":"260",
							"tempDefaultC":"220","tempListLengthC":"0","tempMinF":"350","tempMaxF":"500","tempDefaultF":"425","tempListLengthF":"0",
							"timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported",
							"probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported",
							"powerDefault":"NotSupported","powerListLength":"0"},
						{"mode":"SteamClean","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0",
							"tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0",
							"tempListLengthF":"0","timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0",
							"probeDefaultC":"0","probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"},
						{"mode":"SelfClean","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0",
							"tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0","tempListLengthF":"0",
							"timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0","probeDefaultC":"0",
							"probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"},
						{"mode":"NoOperation","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0",
							"tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0","tempListLengthF":"0",
							"timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0","probeDefaultC":"0",
							"probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"}], 
					x.com.samsung.da.modes:[NoOperation], 
					x.com.samsung.da.options:[
						DeviceType_NE9103T-AA0, SettingPossible_0, keepWarmReservation_Off, meatprobe_disconnected, fastpreheat_Not_Supported, 
						UpperTimerCurrent_0, UpperTimerSet_0, UpperTimerState_Ready, UpperLamp_Off, waterInlet_NotSupported, drain_NotSupported, 
						ShowerLighting_NotSupported, ScreenTimeOut_NotSupported, Sound_On, RecipeConversion_Off, AdjustingTemp_0, 
						VirtualFlame_NotSupported, Sabbath_Off, EnergySaving_On, WarmingCenter_Off, Lamp_NotSupported, ShutOffTimerState_Ready], 
					x.com.samsung.da.supportedModes:[
						HOMECARE_WIZARD_V2, Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer, SteamClean, 
						SelfClean, NoOperation]]]]], 
	ocf:[
		di:[timestamp:2020-11-29T02:35:18.943Z, value:b440aa23-9f34-bfb4-eef2-5c0d0bfdf4e8], dmv:[timestamp:2022-05-16T17:46:39.602Z, value:res.1.1.0,sh.1.1.0], 
		icv:[timestamp:2020-11-29T02:35:19.012Z, value:core.1.1.0], mndt:[timestamp:2020-11-29T02:40:31.653Z, value:null], 
		mnfv:[timestamp:2021-11-05T02:59:05.745Z, value:A-RG-WW-TP2-21-COMM_40210802], mnhw:[timestamp:2021-07-26T04:43:26.333Z, value:MediaTek], 
		mnml:[timestamp:2020-11-29T02:35:18.751Z, value:"http://www.samsung.com"], mnmn:[timestamp:2020-11-29T02:35:18.762Z, value:Samsung Electronics], 
		mnmo:[timestamp:2021-07-26T04:43:26.333Z, value:TP2X_DA-KS-RANGE-0101X|40433941|5001011E03141101020000000000000], 
		mnos:[timestamp:2021-07-26T04:43:26.333Z, value:TizenRT 1.0 + IPv6], mnpv:[timestamp:2021-07-26T04:43:26.333Z, value:DAWIT 2.0], 
		mnsl:[timestamp:2021-10-26T05:43:04.977Z, value:"http://www.samsung.com"], n:[timestamp:2021-07-26T04:43:26.333Z, value:[Range] Samsung], 
		pi:[timestamp:2020-11-29T02:35:18.802Z, value:b440aa23-9f34-bfb4-eef2-5c0d0bfdf4e8], st:[timestamp:2020-11-29T02:43:32.303Z, value:null], 
		vid:[timestamp:2020-11-29T02:35:18.815Z, value:DA-KS-RANGE-0101X]], 
	ovenMode:[
		ovenMode:[timestamp:2023-02-24T16:13:04.242Z, value:Others],
		supportedOvenModes:[timestamp:2022-09-07T05:08:46.629Z, value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate]]], 
	ovenOperatingState:[
		completionTime:[timestamp:2023-02-24T16:13:04.192Z, value:2023-02-24T16:13:04.182Z], 
		machineState:[timestamp:2023-02-22T23:36:43.638Z, value:ready], 
		operationTime:[timestamp:2022-09-05T20:47:03.680Z, value:0], 
		ovenJobState:[timestamp:2023-02-22T23:36:43.494Z, value:ready], 
		progress:[timestamp:2022-09-07T05:08:46.629Z, unit:%, value:1], 
		supportedMachineStates:[timestamp:2020-11-29T02:39:28.212Z, value:null]], 
	ovenSetpoint:[
		ovenSetpoint:[timestamp:2023-02-24T02:47:15.970Z, value:0]], 
	refresh:[:], 
	remoteControlStatus:[
		remoteControlEnabled:[timestamp:2023-02-24T02:38:03.966Z, value:true]], 
	samsungce.customRecipe:[:], 
	samsungce.deviceIdentification:[
		binaryId:[timestamp:2023-02-24T08:35:01.351Z, value:TP2X_DA-KS-RANGE-0101X], description:[value:null], micomAssayCode:[value:null], 
		modelClassificationCode:[value:null], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null]], 
	samsungce.doorState:[
		doorState:[timestamp:2023-02-22T23:36:52.383Z, value:closed]], 
	samsungce.driverVersion:[
		versionNumber:[timestamp:2022-11-01T10:03:33.875Z, value:22100101]], 
	samsungce.kidsLock:[
		lockState:[timestamp:2023-02-24T02:37:40.707Z, value:unlocked]], 
	samsungce.kitchenDeviceDefaults:[
		defaultOperationTime:[timestamp:2021-01-16T07:47:02.729Z, value:3600], 
		defaultOvenMode:[timestamp:2021-07-26T04:43:08.166Z, value:ConvectionBake], 
		defaultOvenSetpoint:[timestamp:2021-01-16T07:47:02.729Z, value:350]], 
	samsungce.kitchenDeviceIdentification:[
		fuel:[value:null], modelCode:[timestamp:2020-11-29T02:35:25.131Z, value:"NE9103T-/AA0"], regionCode:[timestamp:2020-11-29T02:35:25.201Z, value:US], 
		representativeComponent:[value:null], type:[timestamp:2020-11-29T02:35:18.902Z, value:range]], 
	samsungce.kitchenModeSpecification:[
		specification:[
			timestamp:2021-07-26T05:01:09.707Z, value:[
				lower:[
					[
						mode:SteamClean, supportedOperations:[],supportedOptions:[
						operationTime:[default:00:00:00, max:00:00:00, min:00:00:00, resolution:00:00:00],
						probeTemperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]], 
						temperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]]]], 
					[
						mode:SelfClean, supportedOperations:[], supportedOptions:[
						operationTime:[default:00:00:00, max:00:00:00, min:00:00:00, resolution:00:00:00], 
						probeTemperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]], 
						temperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]]]], 
					[
						mode:NoOperation, supportedOperations:[], supportedOptions:[
						operationTime:[default:00:00:00, max:00:00:00, min:00:00:00, resolution:00:00:00], 
						probeTemperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]], 
						temperature:[C:[default:0, max:0, min:0, resolution:5], F:[default:0, max:0, min:0, resolution:5]]]]], 
				single:[
					[
						mode:Bake, supportedOperations:[start, set], supportedOptions:[
							operationTime:[default:01:00:00, max:09:59:00, min:00:01:00, resolution:00:01:00], 
							temperature:[C:[default:175, max:285, min:80, resolution:5], F:[default:350, max:550, min:175, resolution:5]]]], 
					[
						mode:Broil, supportedOperations:[set], supportedOptions:[
							temperature:[C:[default:61441, max:61441, min:61442, resolution:5], F:[default:61441, max:61441, min:61442, resolution:5]]]], 
					[
						mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[
							operationTime:[default:01:00:00, max:09:59:00, min:00:01:00, resolution:00:01:00], 
							temperature:[C:[default:160, max:285, min:80, resolution:5], F:[default:325, max:550, min:175, resolution:5]]]], 
					[
						mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[
							operationTime:[default:01:00:00, max:09:59:00, min:00:01:00, resolution:00:01:00], 
							temperature:[C:[default:160, max:285, min:80, resolution:5], F:[default:325, max:550, min:175, resolution:5]]]], 
					[
						mode:KeepWarm, supportedOperations:[], supportedOptions:[
							temperature:[C:[default:80, max:80, min:80, resolution:5], F:[default:175, max:175, min:175, resolution:5]]]], 
					[
						mode:BreadProof, supportedOperations:[], supportedOptions:[
							temperature:[C:[default:35, max:35, min:35, resolution:5], F:[default:95, max:95, min:95, resolution:5]]]], 
					[
						mode:Dehydrate, supportedOperations:[start, set], supportedOptions:[
							operationTime:[default:01:00:00, max:09:59:00, min:00:01:00, resolution:00:01:00], 
							temperature:[C:[default:65, max:105, min:40, resolution:5], F:[default:150, max:225, min:100, resolution:5]]]], 
					[
						mode:AirFryer, supportedOperations:[start, set], supportedOptions:[
							operationTime:[default:01:00:00, max:09:59:00, min:00:01:00, resolution:00:01:00], 
							temperature:[C:[default:220, max:260, min:175, resolution:5], F:[default:425, max:500, min:350, resolution:5]]]]]]]], 
	samsungce.lamp:[
		brightnessLevel:[timestamp:2023-02-22T23:36:52.506Z, value:off], 
		supportedBrightnessLevel:[timestamp:2021-07-05T01:15:09.933Z, value:[off, high]]], 
	samsungce.meatProbe:[
		status:[timestamp:2021-01-16T07:47:02.729Z, value:disconnected], 
		temperature:[timestamp:2022-09-07T05:08:46.629Z, unit:F, value:0], 
		temperatureSetpoint:[timestamp:2021-07-05T23:01:20.610Z, unit:F, value:0]], 
	samsungce.ovenMode:[
		ovenMode:[timestamp:2023-02-24T16:13:04.242Z, value:NoOperation], 
		supportedOvenModes:[timestamp:2022-09-07T05:08:46.629Z, value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer]]], 
	samsungce.ovenOperatingState:[
		completionTime:[timestamp:2023-02-24T16:13:04.192Z, value:2023-02-24T16:13:04.182Z], 
		operatingState:[timestamp:2023-02-22T23:36:43.638Z, value:ready], 
		operationTime:[timestamp:2022-09-05T20:47:03.680Z, value:00:00:00], 
		ovenJobState:[timestamp:2023-02-22T23:36:43.494Z, value:ready], 
		progress:[timestamp:2021-01-16T07:47:01.589Z, value:1]], 
	samsungce.softwareUpdate:[
		availableModules:[timestamp:2022-09-07T05:08:45.087Z, value:[]], lastUpdatedDate:[value:null], newVersionAvailable:[timestamp:2022-09-07T05:08:45.087Z, value:false], 
		operatingState:[value:null], otnDUID:[timestamp:2022-09-07T05:08:45.087Z, value:2DCNQWBWAYBXU], progress:[value:null], targetModule:[value:null]], 
	temperatureMeasurement:[
		temperature:[timestamp:2023-02-22T23:36:43.680Z, unit:F, value:175]]]






//	===== Oven =====
//def ovenNoDevider: [
data: [
	components:[
			cavity-01:[
				ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2021-12-14T19:25:30.534Z]], 
				custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
				temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2021-12-14T19:25:30.534Z]], 
				samsungce.ovenOperatingState:[
					completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z],
					operatingState:[value:ready, timestamp:2021-12-14T19:25:30.821Z],
					progress:[value:1, timestamp:2021-12-14T19:25:30.821Z],
					ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z],
					operationTime:[value:00:00:00, timestamp:2021-12-14T19:25:30.821Z]], 
				samsungce.kitchenDeviceDefaults:[
					defaultOperationTime:[value:null], 
												 defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], 
												 defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]], 
				custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2022-04-08T20:09:37.891Z]], 
				ovenMode:[
					supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], 
						  ovenMode:[value:Others, timestamp:2021-12-14T19:25:30.779Z]], 
				ovenOperatingState:[
					completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z], 
									machineState:[value:ready, timestamp:2021-12-14T19:25:30.821Z], 
									progress:[value:1, unit:%, timestamp:2021-12-14T19:25:30.821Z], 
									supportedMachineStates:[value:null], 
									ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z], 
									operationTime:[value:0, timestamp:2021-12-14T19:25:30.821Z]], 
				samsungce.ovenMode:[
					supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], 
									ovenMode:[value:NoOperation, timestamp:2021-12-14T19:25:30.779Z]]], 
			main:[
				samsungce.kitchenDeviceDefaults:[
					defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], 
												 defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z], 
												 defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]],		//	no
				execute:[VARIOUS],						//	no
				ocf:[VARIOUS], 							//	no
				
				remoteControlStatus:[
					remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]], 	//	(bool) ATTR ONLY
				
				samsungce.customRecipe:[:], 			//	no
				samsungce.kitchenDeviceIdentification:[
					regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], 
													   modelCode:[value:NY9803T-AA0, timestamp:2021-12-14T19:25:29.505Z], 
													   type:[value:range, timestamp:2021-12-14T19:25:29.505Z]], 	//	no
				samsungce.kitchenModeSpecification:[
					specification:[
						value:[
							single:[
								[
									mode:Bake,
									supportedOperations:[start, set],
									supportedOptions:[temperature:[C:[min:80, max:285, default:175, resolution:5], F:[min:175, max:550, default:350, resolution:5]], 
												   operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]],
								[
									mode:Broil,
									supportedOperations:[set],
									supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]],
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionRoast, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:KeepWarm, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:80, max:80, default:80, resolution:5], F:[min:175, max:175, default:175, resolution:5]]]], 
								[
									mode:BreadProof, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:35, max:35, default:35, resolution:5], F:[min:95, max:95, default:95, resolution:5]]]], 
								[
									mode:Dehydrate, supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:40, max:105, default:65, resolution:5], F:[min:100, max:225, default:150, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:AirFryer, supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:175, max:260, default:220, resolution:5], F:[min:350, max:500, default:425, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], 
							upper:[
								[
									mode:Broil, 
									supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], 
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionRoast, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], 
							lower:[
								[mode:Bake, 
								 supportedOperations:[start, set], 
								 supportedOptions:[temperature:[C:[min:80, max:250, default:175, resolution:5], F:[min:175, max:480, default:350, resolution:5]], 
												   operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:SteamClean, 
									supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
													  operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
													  probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], 
								[
									mode:SelfClean, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
													  operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
													  probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], 
								[mode:NoOperation, 
								 supportedOperations:[], 
								 supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
												   operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
												   probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]]]], 
						timestamp:2021-12-14T19:25:32.622Z]], 		//	no
				
				custom.cooktopOperatingState:[
					supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z],
					cooktopOperatingState:[value:ready, timestamp:2022-04-09T02:56:27.073Z]], 			//	ATTR ONLY
				
				custom.disabledCapabilities:[disabledCapabilities:[value:null]], 	//	no
				samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]], //	no
				
				temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-09T16:35:22.265Z]], 	//	ATTR ONLY
				samsungce.ovenOperatingState:[
					completionTime:[value:2022-04-09T23:09:07.647Z, timestamp:2022-04-09T23:09:07.656Z],
					operatingState:[value:ready, timestamp:2022-04-09T21:15:23.919Z],
					progress:[value:1, timestamp:2022-03-25T19:17:36.737Z],
					ovenJobState:[value:ready, timestamp:2022-04-09T21:15:23.806Z],
					operationTime:[value:00:00:00, timestamp:2022-03-25T19:17:36.737Z]],		//	SEE CAPS, See ovenOperatingState
				ovenMode:[
					supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2022-04-08T20:09:37.891Z], 
					ovenMode:[value:Others, timestamp:2022-04-09T21:15:24.902Z]], 							//	SEE CAPS, See samsungce...
				ovenOperatingState:[
					completionTime:[value:2022-04-09T23:09:07.647Z, timestamp:2022-04-09T23:09:07.656Z],
					machineState:[value:ready, timestamp:2022-04-09T21:15:23.919Z],
					progress:[value:1, unit:%, timestamp:2022-03-25T19:17:36.737Z],
					supportedMachineStates:[value:null],
					ovenJobState:[value:ready, timestamp:2022-04-09T21:15:23.806Z],
					operationTime:[value:0, timestamp:2022-03-25T19:17:36.737Z]], 					//	SEE CAPS, See samsungce...
				samsungce.ovenMode:[
					supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2022-04-08T20:09:37.891Z], 
					ovenMode:[value:NoOperation, timestamp:2022-04-09T21:15:24.902Z]], 					//	SEE CAPS. See OvenMode
				samsungce.lamp:[
					brightnessLevel:[value:off, timestamp:2022-04-09T21:15:28.582Z],
					supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]], 						//	SEE CAPS
				ovenSetpoint:[
					ovenSetpoint:[value:0, timestamp:2022-04-09T21:15:24.901Z]], 						//	SEE CAPS
				samsungce.meatProbe:[
					temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],
					temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],
					status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]], 				//	SEE CAPS
				refresh:[:], 							
				samsungce.doorState:[
					doorState:[value:closed, timestamp:2022-04-09T21:15:28.309Z]], 				//	ATTR ONLY
				samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]]		//	ATTR ONLY
			]]]]

//def ovenWithDivider: 
data:[
	components:[
		cavity-01:[
			ovenSetpoint:[
				ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:30.751Z]],	//	ThermostatHeatingSetpoint
			temperatureMeasurement:[
				temperature:[value:325, unit:F, timestamp:2022-04-12T19:05:13.717Z]],	//	TemperatureSetpoint
			ovenMode:[
				supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], 
				ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]]	//	Custom
			ovenOperatingState:[
				completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z], //xx
				machineState:[value:running, timestamp:2022-04-12T19:02:30.481Z]
				progress:[value:5, unit:%, timestamp:2022-04-12T19:05:36.707Z], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z],
				operationTime:[value:3600, timestamp:2022-04-12T19:03:12.976Z]],	//	Custom
			custom.ovenCavityStatus:[
				ovenCavityStatus:[value:on, timestamp:2022-04-12T19:02:09.437Z]],	//	PresenceSensor
			custom.disabledCapabilities:[
				disabledCapabilities:[value:null]],
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], 
				defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]],
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], 
				ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]],
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z],
				operatingState:[value:running, timestamp:2022-04-12T19:02:30.481Z],	
				progress:[value:5, timestamp:2022-04-12T19:05:36.707Z], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z], //xx
				operationTime:[value:01:00:00, timestamp:2022-04-12T19:03:12.976Z]],
		],
		main:[
			ovenSetpoint:[
				ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:18.947Z]],	//	ThermostatHeatingSetpoint
			temperatureMeasurement:[
				temperature:[value:325, unit:F, timestamp:2022-04-12T19:04:38.829Z]],	//	TemperatureSetpoint
			ovenMode:[
				supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z],
				ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]]		//	Custom
			ovenOperatingState:[
				completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], 
				machineState:[value:running, timestamp:2022-04-12T19:02:18.824Z], 
				progress:[value:6, unit:%, timestamp:2022-04-12T19:05:35.614Z], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], 
				operationTime:[value:3120, timestamp:2022-04-12T19:02:59.160Z]],		//	Custom
			samsungce.kidsLock:[
				lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]],	//	Custom
			samsungce.lamp:[
				brightnessLevel:[value:off, timestamp:2022-04-12T19:02:11.975Z], 
				supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]],	//	Custom
			refresh:[:],	//	Refresh
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]],		//	Custom
			samsungce.doorState:[
				doorState:[value:closed, timestamp:2022-04-12T19:02:11.728Z]],		//	Contact Sensor
			custom.cooktopOperatingState:[
				supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z], 
				cooktopOperatingState:[value:ready, timestamp:2022-04-12T19:01:54.389Z]],		//	Custom
			samsungce.meatProbe:[
				temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],	//	ThermostatHeatingSetpoint
				temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],	//	TemperatureSetpoint
				status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]		//	PresenceSensor
			],	//	Child
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], 
				defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z],
				defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]],
			execute:[
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.operation], 
							if:[oic.if.baseline, oic.if.a], 
							x.com.samsung.da.state:Run, 
							x.com.samsung.da.operationTime:01:00:00, 
							x.com.samsung.da.remainingTime:00:57:59, 
							x.com.samsung.da.progressPercentage:5, 
							x.com.samsung.da.defaultTime:01:00:00]], 
					data:[href:/operational/state/vs/1], 
					timestamp:2022-04-12T19:05:36.707Z]],
			ocf:[VARIOUS],
			samsungce.customRecipe:[:], 
			samsungce.kitchenDeviceIdentification:[
				regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], 
				modelCode:[value:NY9803T-AA0, timestamp:2021-12-14T19:25:29.505Z], 
				type:[value:range, timestamp:2021-12-14T19:25:29.505Z]],
			samsungce.kitchenModeSpecification:[VARIOUS],
			custom.disabledCapabilities:[
				disabledCapabilities:[value:null]],
			samsungce.driverVersion:[
				versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]],
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], 
				ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]],
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], 
				operatingState:[value:running, timestamp:2022-04-12T19:02:18.824Z], 
				progress:[value:6, timestamp:2022-04-12T19:05:35.614Z], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], 
				operationTime:[value:00:52:00, timestamp:2022-04-12T19:02:59.160Z]],
		]
	]
]


===== Range

Range: [
	deviceId:b440aa23-9f34-bfb4-eef2-5c0d0bfdf4e8, 
	name:[Range] Samsung, label:Range, 
	manufacturerName:Samsung Electronics, presentationId:DA-KS-RANGE-0101X, 
	deviceManufacturerCode:Samsung Electronics, locationId:55d80aa6-11a6-4456-9aed-c13e2c76fb93, 
	roomId:564192d9-95ba-4518-8577-45b11f27de5a, 
	deviceTypeName:Samsung OCF Range, 
	components:[
		[
			id:main, label:Range, 
			capabilities:[
				[id:ocf, version:1], 
				[id:execute, version:1], 
				[id:refresh, version:1], 
				[id:remoteControlStatus, version:1], 
				[id:ovenSetpoint, version:1], 
				[id:ovenMode, version:1], 
				[id:ovenOperatingState, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:samsungce.driverVersion, version:1], 
				[id:samsungce.kitchenDeviceIdentification, version:1], 
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:samsungce.doorState, version:1], 
				[id:samsungce.customRecipe, version:1], 
				[id:samsungce.ovenMode, version:1], 
				[id:samsungce.ovenOperatingState, version:1], 
				[id:samsungce.meatProbe, version:1], 
				[id:samsungce.lamp, version:1], 
				[id:samsungce.kitchenModeSpecification, version:1], 
				[id:samsungce.kidsLock, version:1], 
				[id:custom.cooktopOperatingState, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Range, categoryType:manufacturer]]], 
		[
			id:cavity-01, label:1, 
			capabilities:[
				[id:ovenSetpoint, version:1], //
				[id:ovenMode, version:1], //
				[id:ovenOperatingState, version:1], //
				[id:temperatureMeasurement, version:1], //
				[id:samsungce.ovenMode, version:1],// 
				[id:samsungce.ovenOperatingState, version:1], //
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:custom.ovenCavityStatus, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Other, categoryType:manufacturer]]]], 
	createTime:2020-11-29T02:34:41Z, 
	profile:[id:00eef220-8a5d-3f6a-be53-69823e28e5cc], 
	ocf:[ocfDeviceType:oic.d.range, name:[Range] Samsung, specVersion:core.1.1.0, verticalDomainSpecVersion:1.2.1, 
		 manufacturerName:Samsung Electronics, modelNumber:TP2X_DA-KS-RANGE-0101X|40433941|5001011E03141101020000000000000, 
		 platformVersion:DAWIT 2.0, platformOS:TizenRT 1.0 + IPv6, hwVersion:MediaTek, firmwareVersion:A-RG-WW-TP2-21-COMM_40210802, 
		 vendorId:DA-KS-RANGE-0101X, vendorResourceClientServerVersion:MediaTek Release 2.210709.1, lastSignupTime:2022-02-06T21:41:38.344027Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]]

Status: [
	components:[
		cavity-01:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2020-11-29T02:35:20.254Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2020-11-29T02:35:20.290Z]], 
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z], 
				operatingState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				progress:[value:1, timestamp:2021-01-16T07:47:02.811Z], 
				ovenJobState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				operationTime:[value:00:00:00, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-06T20:56:23.566Z], defaultOvenSetpoint:[value:350, timestamp:2021-07-06T20:56:23.610Z]], 
			custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2020-11-29T02:35:20.385Z]], 
			ovenMode:[
				supportedOvenModes:[value:[Others], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:Others, timestamp:2021-07-26T04:43:08.029Z]], 
			ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z],
				machineState:[value:ready, timestamp:2020-11-29T02:35:20.495Z], 
				progress:[value:1, unit:%, timestamp:2021-01-16T07:47:02.811Z], 
				supportedMachineStates:[value:null, timestamp:2020-11-29T02:43:38.329Z], 
				ovenJobState:[value:ready, timestamp:2020-11-29T02:35:20.589Z], 
				operationTime:[value:0, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.ovenMode:[
				supportedOvenModes:[value:[SteamClean, SelfClean, NoOperation], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:NoOperation, timestamp:2021-07-26T04:43:08.029Z]]], 
		main:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.meatProbe:[
				temperatureSetpoint:[value:0, unit:F, timestamp:2021-07-05T23:01:20.610Z],
				temperature:[value:0, unit:F, timestamp:2021-11-06T21:59:15.685Z], 
				satus:[value:disconnected, timestamp:2021-01-16T07:47:02.729Z]], 
			refresh:[:], 
			samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-19T22:54:42.948Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:3600, timestamp:2021-01-16T07:47:02.729Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-26T04:43:08.166Z], 
				defaultOvenSetpoint:[value:350, timestamp:2021-01-16T07:47:02.729Z]], 
			execute:[], 
			ocf:[], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-02-28T01:53:04.641Z]], 
			samsungce.customRecipe:[:], 
			samsungce.kitchenDeviceIdentification:[], 
			samsungce.kitchenModeSpecification:[],
			custom.cooktopOperatingState:[
				supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-11-05T02:59:11.253Z], 
				cooktopOperatingState:[value:ready, timestamp:2022-04-26T21:44:25.086Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-11-05T12:16:33.903Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
										  operatingState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
										  progress:[value:1, timestamp:2021-01-16T07:47:01.589Z], 
										  ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
										  operationTime:[value:00:00:00, timestamp:2022-02-26T03:52:38.958Z]], 
			ovenMode:[
				supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2021-11-12T02:59:11.564Z], 
					  ovenMode:[value:Others, timestamp:2022-04-19T22:54:43.795Z]], 
			ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
								machineState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
								progress:[value:1, unit:%, timestamp:2021-11-06T21:59:01.515Z], 
								supportedMachineStates:[value:null, timestamp:2020-11-29T02:39:28.212Z], 
								ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
								operationTime:[value:0, timestamp:2022-02-26T03:52:38.958Z]], 
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2021-11-12T02:59:11.564Z], 
								ovenMode:[value:NoOperation, timestamp:2022-04-19T22:54:43.795Z]], 
			samsungce.lamp:[
				brightnessLevel:[value:off, timestamp:2022-04-19T22:54:43.120Z], 
				supportedBrightnessLevel:[value:[off, high], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-04-17T15:45:36.776Z]]]]]]
*/























